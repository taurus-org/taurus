from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_getconv = _Mock()

_is_string_like = _Mock()

_savez = _Mock()

_string_like = _Mock()

absolute_import = _Mock()

asbytes_nested = _Mock()

division = _Mock()

easy_dtype = _Mock()

flatten_dtype = _Mock()

format = _Mock()

fromregex = _Mock()

genfromtxt = _Mock()

has_nested_fields = _Mock()

itertools = _Mock()

load = _Mock()

loads = _Mock()

loadtxt = _Mock()

mafromtxt = _Mock()

ndfromtxt = _Mock()

np = _Mock()

os = _Mock()

packbits = _Mock()

pickle = _Mock()

print_function = _Mock()

re = _Mock()

recfromcsv = _Mock()

recfromtxt = _Mock()

save = _Mock()

savetxt = _Mock()

savez = _Mock()

savez_compressed = _Mock()

seek_gzip_factory = _Mock()

sys = _Mock()

unpackbits = _Mock()

warnings = _Mock()

weakref = _Mock()

zipfile_factory = _Mock()



class BagObj(_Mock):
  pass


class ConversionWarning(_Mock):
  pass


class ConverterError(_Mock):
  pass


class ConverterLockError(_Mock):
  pass


class DataSource(_Mock):
  pass


class LineSplitter(_Mock):
  pass


class NameValidator(_Mock):
  pass


class NpzFile(_Mock):
  pass


class StringConverter(_Mock):
  pass


class _bytes_to_name(_Mock):
  pass


class asbytes(_Mock):
  pass


class asstr(_Mock):
  pass


class basestring(_Mock):
  pass


class bytes(_Mock):
  pass


class itemgetter(_Mock):
  pass


class map(_Mock):
  pass


class unicode(_Mock):
  pass


