from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_check_fill_value = _Mock()

_fix_defaults = _Mock()

_fix_output = _Mock()

_is_string_like = _Mock()

_izip_fields = _Mock()

_izip_fields_flat = _Mock()

absolute_import = _Mock()

append_fields = _Mock()

division = _Mock()

drop_fields = _Mock()

find_duplicates = _Mock()

flatten_descr = _Mock()

get_fieldstructure = _Mock()

get_names = _Mock()

get_names_flat = _Mock()

itertools = _Mock()

izip_records = _Mock()

join_by = _Mock()

ma = _Mock()

merge_arrays = _Mock()

np = _Mock()

print_function = _Mock()

rec_append_fields = _Mock()

rec_drop_fields = _Mock()

rec_join = _Mock()

recursive_fill_fields = _Mock()

rename_fields = _Mock()

stack_arrays = _Mock()

sys = _Mock()

zip_descr = _Mock()



class MaskedArray(_Mock):
  pass
  _defaulthardmask = False

class MaskedRecords(_Mock):
  pass
  _defaulthardmask = False

class basestring(_Mock):
  pass


class ndarray(_Mock):
  pass


class recarray(_Mock):
  pass


class zip(_Mock):
  pass


