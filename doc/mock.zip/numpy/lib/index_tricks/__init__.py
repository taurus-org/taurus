from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


ScalarType = _Mock()

_nx = _Mock()

absolute_import = _Mock()

alltrue = _Mock()

arange = _Mock()

array = _Mock()

as_strided = _Mock()

asarray = _Mock()

c_ = _Mock()

cumprod = _Mock()

diag_indices = _Mock()

diag_indices_from = _Mock()

diff = _Mock()

division = _Mock()

fill_diagonal = _Mock()

find_common_type = _Mock()

function_base = _Mock()

index_exp = _Mock()

ix_ = _Mock()

math = _Mock()

matrix = _Mock()

mgrid = _Mock()

ogrid = _Mock()

print_function = _Mock()

r_ = _Mock()

ravel_multi_index = _Mock()

s_ = _Mock()

sys = _Mock()

unravel_index = _Mock()



class AxisConcatenator(_Mock):
  pass


class CClass(_Mock):
  pass


class IndexExpression(_Mock):
  pass


class RClass(_Mock):
  pass


class makemat(_Mock):
  pass


class nd_grid(_Mock):
  pass


class ndenumerate(_Mock):
  pass


class ndindex(_Mock):
  pass


