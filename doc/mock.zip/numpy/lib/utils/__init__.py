from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_dictlist = _Mock()

_function_signature_re = _Mock()

_getmembers = _Mock()

_lookfor_caches = _Mock()

_lookfor_generate_cache = _Mock()

_makenamedict = _Mock()

_namedict = _Mock()

_set_function_name = _Mock()

_split_line = _Mock()

absolute_import = _Mock()

asarray = _Mock()

byte_bounds = _Mock()

deprecate = _Mock()

deprecate_with_doc = _Mock()

division = _Mock()

get_include = _Mock()

get_numarray_include = _Mock()

info = _Mock()

issubclass_ = _Mock()

issubdtype = _Mock()

issubsctype = _Mock()

lookfor = _Mock()

os = _Mock()

print_function = _Mock()

product = _Mock()

re = _Mock()

safe_eval = _Mock()

source = _Mock()

sys = _Mock()

types = _Mock()

who = _Mock()



class SafeEval(_Mock):
  pass


class _Deprecate(_Mock):
  pass


class ndarray(_Mock):
  pass


class ufunc(_Mock):
  pass


