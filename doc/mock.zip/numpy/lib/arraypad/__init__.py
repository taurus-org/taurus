from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_append_const = _Mock()

_append_edge = _Mock()

_append_max = _Mock()

_append_mean = _Mock()

_append_med = _Mock()

_append_min = _Mock()

_append_ramp = _Mock()

_arange_ndarray = _Mock()

_normalize_shape = _Mock()

_pad_ref = _Mock()

_pad_sym = _Mock()

_pad_wrap = _Mock()

_prepend_const = _Mock()

_prepend_edge = _Mock()

_prepend_max = _Mock()

_prepend_mean = _Mock()

_prepend_med = _Mock()

_prepend_min = _Mock()

_prepend_ramp = _Mock()

_round_ifneeded = _Mock()

_validate_lengths = _Mock()

absolute_import = _Mock()

division = _Mock()

np = _Mock()

pad = _Mock()

print_function = _Mock()



class long(_Mock):
  pass


