from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


ScalarType = _Mock()

_chbevl = _Mock()

_compute_qth_percentile = _Mock()

_i0A = _Mock()

_i0B = _Mock()

_i0_1 = _Mock()

_i0_2 = _Mock()

_insert = _Mock()

_nx = _Mock()

absolute_import = _Mock()

add = _Mock()

add_docstring = _Mock()

add_newdoc = _Mock()

add_newdoc_ufunc = _Mock()

angle = _Mock()

append = _Mock()

arange = _Mock()

arctan2 = _Mock()

around = _Mock()

array = _Mock()

asanyarray = _Mock()

asarray = _Mock()

asarray_chkfinite = _Mock()

atleast_1d = _Mock()

atleast_2d = _Mock()

average = _Mock()

bartlett = _Mock()

bincount = _Mock()

blackman = _Mock()

choose = _Mock()

collections = _Mock()

compiled_interp = _Mock()

concatenate = _Mock()

copy = _Mock()

corrcoef = _Mock()

cos = _Mock()

cov = _Mock()

delete = _Mock()

deprecate = _Mock()

diag = _Mock()

diff = _Mock()

digitize = _Mock()

disp = _Mock()

division = _Mock()

dot = _Mock()

empty = _Mock()

empty_like = _Mock()

exp = _Mock()

extract = _Mock()

frompyfunc = _Mock()

gradient = _Mock()

hamming = _Mock()

hanning = _Mock()

histogram = _Mock()

histogramdd = _Mock()

i0 = _Mock()

insert = _Mock()

interp = _Mock()

isnan = _Mock()

isscalar = _Mock()

iterable = _Mock()

kaiser = _Mock()

less_equal = _Mock()

linspace = _Mock()

log10 = _Mock()

mean = _Mock()

median = _Mock()

meshgrid = _Mock()

mod = _Mock()

msort = _Mock()

multiply = _Mock()

newaxis = _Mock()

nonzero = _Mock()

np = _Mock()

ones = _Mock()

partition = _Mock()

percentile = _Mock()

piecewise = _Mock()

place = _Mock()

print_function = _Mock()

ravel = _Mock()

select = _Mock()

sin = _Mock()

sinc = _Mock()

sort = _Mock()

sort_complex = _Mock()

sqrt = _Mock()

sys = _Mock()

trapz = _Mock()

trim_zeros = _Mock()

typecodes = _Mock()

types = _Mock()

unique = _Mock()

unwrap = _Mock()

warnings = _Mock()

where = _Mock()

zeros = _Mock()

pi = 3.141592653589793

class integer(_Mock):
  pass


class intp(_Mock):
  pass


class long(_Mock):
  pass


class ndarray(_Mock):
  pass


class number(_Mock):
  pass


class range(_Mock):
  pass


class vectorize(_Mock):
  pass


