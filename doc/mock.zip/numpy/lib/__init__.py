from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_compiled_base = _Mock()

_datasource = _Mock()

_iotools = _Mock()

absolute_import = _Mock()

add_docstring = _Mock()

add_newdoc = _Mock()

add_newdoc_ufunc = _Mock()

angle = _Mock()

append = _Mock()

apply_along_axis = _Mock()

apply_over_axes = _Mock()

array_split = _Mock()

arraypad = _Mock()

arraysetops = _Mock()

arrayterator = _Mock()

asarray_chkfinite = _Mock()

asfarray = _Mock()

asscalar = _Mock()

average = _Mock()

bartlett = _Mock()

bench = _Mock()

bincount = _Mock()

blackman = _Mock()

broadcast_arrays = _Mock()

byte_bounds = _Mock()

c_ = _Mock()

column_stack = _Mock()

common_type = _Mock()

copy = _Mock()

corrcoef = _Mock()

cov = _Mock()

delete = _Mock()

deprecate = _Mock()

deprecate_with_doc = _Mock()

diag = _Mock()

diag_indices = _Mock()

diag_indices_from = _Mock()

diagflat = _Mock()

diff = _Mock()

digitize = _Mock()

disp = _Mock()

division = _Mock()

dsplit = _Mock()

dstack = _Mock()

ediff1d = _Mock()

emath = _Mock()

expand_dims = _Mock()

extract = _Mock()

eye = _Mock()

fill_diagonal = _Mock()

financial = _Mock()

fix = _Mock()

fliplr = _Mock()

flipud = _Mock()

format = _Mock()

fromregex = _Mock()

function_base = _Mock()

fv = _Mock()

genfromtxt = _Mock()

get_array_wrap = _Mock()

get_include = _Mock()

get_numarray_include = _Mock()

gradient = _Mock()

hamming = _Mock()

hanning = _Mock()

histogram = _Mock()

histogram2d = _Mock()

histogramdd = _Mock()

hsplit = _Mock()

i0 = _Mock()

imag = _Mock()

in1d = _Mock()

index_exp = _Mock()

index_tricks = _Mock()

info = _Mock()

insert = _Mock()

interp = _Mock()

intersect1d = _Mock()

ipmt = _Mock()

irr = _Mock()

iscomplex = _Mock()

iscomplexobj = _Mock()

isneginf = _Mock()

isposinf = _Mock()

isreal = _Mock()

isrealobj = _Mock()

issubclass_ = _Mock()

issubdtype = _Mock()

issubsctype = _Mock()

iterable = _Mock()

ix_ = _Mock()

kaiser = _Mock()

kron = _Mock()

load = _Mock()

loads = _Mock()

loadtxt = _Mock()

lookfor = _Mock()

mafromtxt = _Mock()

mask_indices = _Mock()

math = _Mock()

median = _Mock()

meshgrid = _Mock()

mgrid = _Mock()

mintypecode = _Mock()

mirr = _Mock()

msort = _Mock()

nan_to_num = _Mock()

nanargmax = _Mock()

nanargmin = _Mock()

nanfunctions = _Mock()

nanmax = _Mock()

nanmean = _Mock()

nanmin = _Mock()

nanstd = _Mock()

nansum = _Mock()

nanvar = _Mock()

ndfromtxt = _Mock()

nper = _Mock()

npv = _Mock()

npyio = _Mock()

ogrid = _Mock()

packbits = _Mock()

pad = _Mock()

percentile = _Mock()

piecewise = _Mock()

place = _Mock()

pmt = _Mock()

poly = _Mock()

polyadd = _Mock()

polyder = _Mock()

polydiv = _Mock()

polyfit = _Mock()

polyint = _Mock()

polymul = _Mock()

polynomial = _Mock()

polysub = _Mock()

polyval = _Mock()

ppmt = _Mock()

print_function = _Mock()

pv = _Mock()

r_ = _Mock()

rate = _Mock()

ravel_multi_index = _Mock()

real = _Mock()

real_if_close = _Mock()

recfromcsv = _Mock()

recfromtxt = _Mock()

roots = _Mock()

rot90 = _Mock()

row_stack = _Mock()

s_ = _Mock()

safe_eval = _Mock()

save = _Mock()

savetxt = _Mock()

savez = _Mock()

savez_compressed = _Mock()

scimath = _Mock()

select = _Mock()

setdiff1d = _Mock()

setxor1d = _Mock()

shape_base = _Mock()

sinc = _Mock()

sort_complex = _Mock()

source = _Mock()

split = _Mock()

stride_tricks = _Mock()

test = _Mock()

tile = _Mock()

trapz = _Mock()

tri = _Mock()

tril = _Mock()

tril_indices = _Mock()

tril_indices_from = _Mock()

trim_zeros = _Mock()

triu = _Mock()

triu_indices = _Mock()

triu_indices_from = _Mock()

twodim_base = _Mock()

type_check = _Mock()

typename = _Mock()

ufunclike = _Mock()

union1d = _Mock()

unique = _Mock()

unpackbits = _Mock()

unravel_index = _Mock()

unwrap = _Mock()

utils = _Mock()

vander = _Mock()

vsplit = _Mock()

who = _Mock()

__version__ = '1.8.2'

class Arrayterator(_Mock):
  pass


class DataSource(_Mock):
  pass


class RankWarning(_Mock):
  pass


class Tester(_Mock):
  pass


class ndenumerate(_Mock):
  pass


class ndindex(_Mock):
  pass


class poly1d(_Mock):
  pass


class vectorize(_Mock):
  pass


