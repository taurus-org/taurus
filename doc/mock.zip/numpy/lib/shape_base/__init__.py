from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_nx = _Mock()

_replace_zero_by_x_arrays = _Mock()

absolute_import = _Mock()

apply_along_axis = _Mock()

apply_over_axes = _Mock()

array = _Mock()

array_split = _Mock()

asanyarray = _Mock()

asarray = _Mock()

atleast_3d = _Mock()

column_stack = _Mock()

concatenate = _Mock()

division = _Mock()

dsplit = _Mock()

dstack = _Mock()

expand_dims = _Mock()

get_array_prepare = _Mock()

get_array_wrap = _Mock()

hsplit = _Mock()

hstack = _Mock()

isscalar = _Mock()

kron = _Mock()

newaxis = _Mock()

outer = _Mock()

print_function = _Mock()

product = _Mock()

reshape = _Mock()

row_stack = _Mock()

split = _Mock()

tile = _Mock()

vsplit = _Mock()

vstack = _Mock()

zeros = _Mock()





