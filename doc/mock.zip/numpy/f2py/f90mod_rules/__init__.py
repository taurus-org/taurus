from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


absolute_import = _Mock()

applyrules = _Mock()

buildhooks = _Mock()

capi_maps = _Mock()

cfuncs = _Mock()

containscommon = _Mock()

containsmodule = _Mock()

debugcapi = _Mock()

debugoptions = _Mock()

dictappend = _Mock()

division = _Mock()

errmess = _Mock()

findf90modules = _Mock()

flatlist = _Mock()

func2subr = _Mock()

gentitle = _Mock()

get_kind = _Mock()

getargs = _Mock()

getargs2 = _Mock()

getcallprotoargument = _Mock()

getcallstatement = _Mock()

getfortranname = _Mock()

getmultilineblock = _Mock()

getpymethoddef = _Mock()

getrestdoc = _Mock()

getusercode = _Mock()

getusercode1 = _Mock()

hasassumedshape = _Mock()

hasbody = _Mock()

hascallstatement = _Mock()

hascommon = _Mock()

hasexternals = _Mock()

hasinitvalue = _Mock()

hasinitvalueasstring = _Mock()

hasnote = _Mock()

hasresultnote = _Mock()

hasvariables = _Mock()

isallocatable = _Mock()

isarray = _Mock()

isarrayofstrings = _Mock()

ischaracter = _Mock()

iscomplex = _Mock()

iscomplexarray = _Mock()

iscomplexfunction = _Mock()

iscomplexfunction_warn = _Mock()

isdouble = _Mock()

isdummyroutine = _Mock()

isexternal = _Mock()

isfalse = _Mock()

isfunction = _Mock()

isfunction_wrap = _Mock()

isint1array = _Mock()

isinteger = _Mock()

isintent_aligned16 = _Mock()

isintent_aligned4 = _Mock()

isintent_aligned8 = _Mock()

isintent_aux = _Mock()

isintent_c = _Mock()

isintent_cache = _Mock()

isintent_callback = _Mock()

isintent_copy = _Mock()

isintent_dict = _Mock()

isintent_hide = _Mock()

isintent_in = _Mock()

isintent_inout = _Mock()

isintent_inplace = _Mock()

isintent_nothide = _Mock()

isintent_out = _Mock()

isintent_overwrite = _Mock()

islogical = _Mock()

islogicalfunction = _Mock()

islong_complex = _Mock()

islong_double = _Mock()

islong_doublefunction = _Mock()

islong_long = _Mock()

islong_longfunction = _Mock()

ismodule = _Mock()

ismoduleroutine = _Mock()

ismutable = _Mock()

isoptional = _Mock()

isprivate = _Mock()

isreal = _Mock()

isrequired = _Mock()

isroutine = _Mock()

isscalar = _Mock()

issigned_array = _Mock()

issigned_chararray = _Mock()

issigned_long_longarray = _Mock()

issigned_shortarray = _Mock()

isstring = _Mock()

isstringarray = _Mock()

isstringfunction = _Mock()

issubroutine = _Mock()

issubroutine_wrap = _Mock()

isthreadsafe = _Mock()

istrue = _Mock()

isunsigned = _Mock()

isunsigned_char = _Mock()

isunsigned_chararray = _Mock()

isunsigned_long_long = _Mock()

isunsigned_long_longarray = _Mock()

isunsigned_short = _Mock()

isunsigned_shortarray = _Mock()

isunsignedarray = _Mock()

l_and = _Mock()

l_not = _Mock()

l_or = _Mock()

np = _Mock()

options = _Mock()

outmess = _Mock()

pprint = _Mock()

print_function = _Mock()

reduce = _Mock()

replace = _Mock()

show = _Mock()

stripcomma = _Mock()

sys = _Mock()

types = _Mock()

undo_rmbadname = _Mock()

undo_rmbadname1 = _Mock()

__version__ = ' 1.27 '

f2py_version = '2'

fgetdims1 = '      external f2pysetdata\n      logical ns\n      integer r,i,j\n      integer(8) s(*)\n      ns = .FALSE.\n      if (allocated(d)) then\n         do i=1,r\n            if ((size(d,i).ne.s(i)).and.(s(i).ge.0)) then\n               ns = .TRUE.\n            end if\n         end do\n         if (ns) then\n            deallocate(d)\n         end if\n      end if\n      if ((.not.allocated(d)).and.(s(1).ge.1)) then'

fgetdims2 = '      end if\n      if (allocated(d)) then\n         do i=1,r\n            s(i) = size(d,i)\n         end do\n      end if\n      flag = 1\n      call f2pysetdata(d,allocated(d))'

fgetdims2_sa = '      end if\n      if (allocated(d)) then\n         do i=1,r\n            s(i) = size(d,i)\n         end do\n         !s(r) must be equal to len(d(1))\n      end if\n      flag = 2\n      call f2pysetdata(d,allocated(d))'

wrapfuncs = 1

class F2PYError(_Mock):
  pass


class throw_error(_Mock):
  pass


