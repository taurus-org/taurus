from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


__version__ = _Mock()

_calc_depend_dict = _Mock()

_ensure_exprdict = _Mock()

_eval_length = _Mock()

_eval_scalar = _Mock()

_free_f90_start = _Mock()

_get_depend_dict = _Mock()

_has_f90_header = _Mock()

_has_f_header = _Mock()

_has_fix_header = _Mock()

_intentcallbackpattern = _Mock()

_is_intent_callback = _Mock()

_is_kind_number = _Mock()

_kind_func = _Mock()

_resolvenameargspattern = _Mock()

_selected_int_kind_func = _Mock()

_selected_real_kind_func = _Mock()

_simplifyargs = _Mock()

_varname_match = _Mock()

absolute_import = _Mock()

analyzeargs = _Mock()

analyzeargs_re_1 = _Mock()

analyzebody = _Mock()

analyzecommon = _Mock()

analyzeline = _Mock()

analyzevars = _Mock()

appenddecl = _Mock()

appendmultiline = _Mock()

applyrules = _Mock()

badnames = _Mock()

beginpattern77 = _Mock()

beginpattern90 = _Mock()

buildimplicitrules = _Mock()

callfunpattern = _Mock()

callnameargspattern = _Mock()

callpattern = _Mock()

cfuncs = _Mock()

charselector = _Mock()

common2fortran = _Mock()

commonpattern = _Mock()

containscommon = _Mock()

containsmodule = _Mock()

containspattern = _Mock()

copy = _Mock()

crack2fortran = _Mock()

crack2fortrangen = _Mock()

crackfortran = _Mock()

crackline = _Mock()

crackline_re_1 = _Mock()

cracktypespec = _Mock()

cracktypespec0 = _Mock()

datapattern = _Mock()

debug = _Mock()

debugcapi = _Mock()

debugoptions = _Mock()

defaultimplicitrules = _Mock()

determineexprtype = _Mock()

determineexprtype_re_1 = _Mock()

determineexprtype_re_2 = _Mock()

determineexprtype_re_3 = _Mock()

determineexprtype_re_4 = _Mock()

determineexprtype_re_5 = _Mock()

dictappend = _Mock()

dimensionpattern = _Mock()

division = _Mock()

endifpattern = _Mock()

endpattern = _Mock()

entrypattern = _Mock()

errmess = _Mock()

expr2name = _Mock()

externalpattern = _Mock()

f2pyenhancementspattern = _Mock()

f90modulevars = _Mock()

fileinput = _Mock()

flatlist = _Mock()

formatpattern = _Mock()

functionpattern = _Mock()

gentitle = _Mock()

get_kind = _Mock()

get_parameters = _Mock()

get_sorted_names = _Mock()

get_usedict = _Mock()

get_useparameters = _Mock()

getargs = _Mock()

getargs2 = _Mock()

getarrlen = _Mock()

getblockname = _Mock()

getcallprotoargument = _Mock()

getcallstatement = _Mock()

getextension = _Mock()

getfortranname = _Mock()

getlincoef = _Mock()

getlincoef_re_1 = _Mock()

getmultilineblock = _Mock()

getpymethoddef = _Mock()

getrestdoc = _Mock()

getusercode = _Mock()

getusercode1 = _Mock()

grouplist = _Mock()

hasassumedshape = _Mock()

hasbody = _Mock()

hascallstatement = _Mock()

hascommon = _Mock()

hasexternals = _Mock()

hasinitvalue = _Mock()

hasinitvalueasstring = _Mock()

hasnote = _Mock()

hasresultnote = _Mock()

hasvariables = _Mock()

implicitpattern = _Mock()

include_paths = _Mock()

intentpattern = _Mock()

intrisicpattern = _Mock()

invbadnames = _Mock()

is_f_file = _Mock()

is_free_format = _Mock()

isallocatable = _Mock()

isarray = _Mock()

isarrayofstrings = _Mock()

ischaracter = _Mock()

iscomplex = _Mock()

iscomplexarray = _Mock()

iscomplexfunction = _Mock()

iscomplexfunction_warn = _Mock()

isdouble = _Mock()

isdummyroutine = _Mock()

isexternal = _Mock()

isfalse = _Mock()

isfunction = _Mock()

isfunction_wrap = _Mock()

isint1array = _Mock()

isinteger = _Mock()

isintent_aligned16 = _Mock()

isintent_aligned4 = _Mock()

isintent_aligned8 = _Mock()

isintent_aux = _Mock()

isintent_c = _Mock()

isintent_cache = _Mock()

isintent_callback = _Mock()

isintent_copy = _Mock()

isintent_dict = _Mock()

isintent_hide = _Mock()

isintent_in = _Mock()

isintent_inout = _Mock()

isintent_inplace = _Mock()

isintent_nothide = _Mock()

isintent_out = _Mock()

isintent_overwrite = _Mock()

islogical = _Mock()

islogicalfunction = _Mock()

islong_complex = _Mock()

islong_double = _Mock()

islong_doublefunction = _Mock()

islong_long = _Mock()

islong_longfunction = _Mock()

ismodule = _Mock()

ismoduleroutine = _Mock()

ismutable = _Mock()

isoptional = _Mock()

isprivate = _Mock()

isreal = _Mock()

isrequired = _Mock()

isroutine = _Mock()

isscalar = _Mock()

issigned_array = _Mock()

issigned_chararray = _Mock()

issigned_long_longarray = _Mock()

issigned_shortarray = _Mock()

isstring = _Mock()

isstringarray = _Mock()

isstringfunction = _Mock()

issubroutine = _Mock()

issubroutine_wrap = _Mock()

isthreadsafe = _Mock()

istrue = _Mock()

isunsigned = _Mock()

isunsigned_char = _Mock()

isunsigned_chararray = _Mock()

isunsigned_long_long = _Mock()

isunsigned_long_longarray = _Mock()

isunsigned_short = _Mock()

isunsigned_shortarray = _Mock()

isunsignedarray = _Mock()

kindselector = _Mock()

l_and = _Mock()

l_not = _Mock()

l_or = _Mock()

lenarraypattern = _Mock()

lenkindpattern = _Mock()

markinnerspaces = _Mock()

markoutercomma = _Mock()

markouterparen = _Mock()

multilinepattern = _Mock()

myeval = _Mock()

nameargspattern = _Mock()

namepattern = _Mock()

onlyfuncs = _Mock()

optionalpattern = _Mock()

options = _Mock()

os = _Mock()

outmess = _Mock()

parameterpattern = _Mock()

platform = _Mock()

postcrack = _Mock()

postcrack2 = _Mock()

pprint = _Mock()

previous_context = _Mock()

print_function = _Mock()

privatepattern = _Mock()

publicpattern = _Mock()

re = _Mock()

readfortrancode = _Mock()

real16pattern = _Mock()

real8pattern = _Mock()

reduce = _Mock()

removespaces = _Mock()

replace = _Mock()

requiredpattern = _Mock()

rmbadname = _Mock()

rmbadname1 = _Mock()

selectpattern = _Mock()

setattrspec = _Mock()

setcharselector = _Mock()

setkindselector = _Mock()

setmesstext = _Mock()

show = _Mock()

skipfuncs = _Mock()

skipfunctions = _Mock()

sortvarnames = _Mock()

string = _Mock()

stripcomma = _Mock()

subroutinepattern = _Mock()

sys = _Mock()

true_intent_list = _Mock()

types = _Mock()

typespattern = _Mock()

typespattern4implicit = _Mock()

undo_rmbadname = _Mock()

undo_rmbadname1 = _Mock()

unmarkouterparen = _Mock()

updatevars = _Mock()

use2fortran = _Mock()

usepattern = _Mock()

usermodules = _Mock()

vars2fortran = _Mock()

word_pattern = _Mock()

beforethisafter = '\\s*(?P<before>%s(?=\\s*(\\b(%s)\\b)))\\s*(?P<this>(\\b(%s)\\b))\\s*(?P<after>%s)\\s*\\Z'

currentfilename = ''

dolowercase = 1

endifs = '(end\\s*(if|do|where|select|while|forall))|(module\\s*procedure)'

expectbegin = 1

f2py_version = '2'

f77modulename = ''

filepositiontext = ''

fortrantypes = 'character|logical|integer|real|complex|double\\s*(precision\\s*(complex|)|complex)|type(?=\\s*\\([\\w\\s,=(*)]*\\))|byte'

gotnextfile = 1

groupbegins77 = 'program|block\\s*data'

groupbegins90 = 'program|block\\s*data|module(?!\\s*procedure)|python\\s*module|interface|type(?!\\s*\\()'

groupcounter = 0

groupends = 'end|endprogram|endblockdata|endmodule|endpythonmodule|endinterface'

ignorecontains = 1

n = 'default'

neededmodule = -1

pyffilename = ''

quiet = 0

skipblocksuntil = -1

skipemptyends = 0

sourcecodeform = 'fix'

strictf77 = 1

tabchar = '    '

verbose = 1

wrapfuncs = 1

class F2PYError(_Mock):
  pass


class throw_error(_Mock):
  pass


