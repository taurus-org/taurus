from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_covhelper = _Mock()

_ezclump = _Mock()

absolute_import = _Mock()

add = _Mock()

apply_along_axis = _Mock()

apply_over_axes = _Mock()

array = _Mock()

asarray = _Mock()

atleast_1d = _Mock()

atleast_2d = _Mock()

atleast_3d = _Mock()

average = _Mock()

clump_masked = _Mock()

clump_unmasked = _Mock()

column_stack = _Mock()

compress_cols = _Mock()

compress_rowcols = _Mock()

compress_rows = _Mock()

concatenate = _Mock()

corrcoef = _Mock()

count = _Mock()

count_masked = _Mock()

cov = _Mock()

diagflat = _Mock()

division = _Mock()

dot = _Mock()

dstack = _Mock()

ediff1d = _Mock()

filled = _Mock()

flatnotmasked_contiguous = _Mock()

flatnotmasked_edges = _Mock()

flatten_inplace = _Mock()

getmask = _Mock()

getmaskarray = _Mock()

hsplit = _Mock()

hstack = _Mock()

in1d = _Mock()

intersect1d = _Mock()

issequence = _Mock()

itertools = _Mock()

lstsq = _Mock()

ma = _Mock()

make_mask_descr = _Mock()

mask_cols = _Mock()

mask_or = _Mock()

mask_rowcols = _Mock()

mask_rows = _Mock()

masked = _Mock()

masked_all = _Mock()

masked_all_like = _Mock()

median = _Mock()

mr_ = _Mock()

nomask = _Mock()

notmasked_contiguous = _Mock()

notmasked_edges = _Mock()

np = _Mock()

nxarray = _Mock()

ones = _Mock()

polyfit = _Mock()

print_function = _Mock()

row_stack = _Mock()

setdiff1d = _Mock()

setxor1d = _Mock()

sort = _Mock()

umath = _Mock()

union1d = _Mock()

unique = _Mock()

vander = _Mock()

vstack = _Mock()

warnings = _Mock()

zeros = _Mock()

__version__ = '1.0'

class AxisConcatenator(_Mock):
  pass


class MAError(_Mock):
  pass


class MAxisConcatenator(_Mock):
  pass


class MaskedArray(_Mock):
  pass
  _defaulthardmask = False

class _fromnxfunction(_Mock):
  pass


class masked_array(_Mock):
  pass
  _defaulthardmask = False

class mr_class(_Mock):
  pass


class ndarray(_Mock):
  pass


