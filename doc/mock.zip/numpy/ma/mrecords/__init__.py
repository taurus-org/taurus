from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_byteorderconv = _Mock()

_check_fill_value = _Mock()

_checknames = _Mock()

_get_fieldmask = _Mock()

_getformats = _Mock()

_guessvartypes = _Mock()

_mrreconstruct = _Mock()

_typestr = _Mock()

absolute_import = _Mock()

addfield = _Mock()

division = _Mock()

filled = _Mock()

fromarrays = _Mock()

fromrecords = _Mock()

fromtextfile = _Mock()

getdata = _Mock()

getmaskarray = _Mock()

ma = _Mock()

masked = _Mock()

narray = _Mock()

nomask = _Mock()

np = _Mock()

ntypes = _Mock()

openfile = _Mock()

print_function = _Mock()

recfromarrays = _Mock()

recfromrecords = _Mock()

reserved_fields = _Mock()

sys = _Mock()

warnings = _Mock()



class MAError(_Mock):
  pass


class MaskedArray(_Mock):
  pass
  _defaulthardmask = False

class MaskedRecords(_Mock):
  pass
  _defaulthardmask = False

class basestring(_Mock):
  pass


class bool_(_Mock):
  pass


class dtype(_Mock):
  pass


class masked_array(_Mock):
  pass
  _defaulthardmask = False

class mrecarray(_Mock):
  pass
  _defaulthardmask = False

class ndarray(_Mock):
  pass


class recarray(_Mock):
  pass


