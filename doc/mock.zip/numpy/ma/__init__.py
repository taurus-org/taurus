from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


abs = _Mock()

absolute = _Mock()

absolute_import = _Mock()

add = _Mock()

all = _Mock()

allclose = _Mock()

allequal = _Mock()

alltrue = _Mock()

amax = _Mock()

amin = _Mock()

angle = _Mock()

anom = _Mock()

anomalies = _Mock()

any = _Mock()

apply_along_axis = _Mock()

apply_over_axes = _Mock()

arange = _Mock()

arccos = _Mock()

arccosh = _Mock()

arcsin = _Mock()

arcsinh = _Mock()

arctan = _Mock()

arctan2 = _Mock()

arctanh = _Mock()

argmax = _Mock()

argmin = _Mock()

argsort = _Mock()

around = _Mock()

array = _Mock()

asanyarray = _Mock()

asarray = _Mock()

atleast_1d = _Mock()

atleast_2d = _Mock()

atleast_3d = _Mock()

average = _Mock()

bench = _Mock()

bitwise_and = _Mock()

bitwise_or = _Mock()

bitwise_xor = _Mock()

ceil = _Mock()

choose = _Mock()

clip = _Mock()

clump_masked = _Mock()

clump_unmasked = _Mock()

column_stack = _Mock()

common_fill_value = _Mock()

compress = _Mock()

compress_cols = _Mock()

compress_rowcols = _Mock()

compress_rows = _Mock()

compressed = _Mock()

concatenate = _Mock()

conjugate = _Mock()

copy = _Mock()

core = _Mock()

corrcoef = _Mock()

cos = _Mock()

cosh = _Mock()

count = _Mock()

count_masked = _Mock()

cov = _Mock()

cumprod = _Mock()

cumsum = _Mock()

default_fill_value = _Mock()

diag = _Mock()

diagflat = _Mock()

diagonal = _Mock()

diff = _Mock()

divide = _Mock()

division = _Mock()

dot = _Mock()

dstack = _Mock()

dump = _Mock()

dumps = _Mock()

ediff1d = _Mock()

empty = _Mock()

empty_like = _Mock()

equal = _Mock()

exp = _Mock()

expand_dims = _Mock()

extras = _Mock()

fabs = _Mock()

filled = _Mock()

fix_invalid = _Mock()

flatnotmasked_contiguous = _Mock()

flatnotmasked_edges = _Mock()

flatten_mask = _Mock()

flatten_structured_array = _Mock()

floor = _Mock()

floor_divide = _Mock()

fmod = _Mock()

frombuffer = _Mock()

fromflex = _Mock()

fromfunction = _Mock()

getdata = _Mock()

getmask = _Mock()

getmaskarray = _Mock()

greater = _Mock()

greater_equal = _Mock()

harden_mask = _Mock()

hsplit = _Mock()

hstack = _Mock()

hypot = _Mock()

identity = _Mock()

ids = _Mock()

in1d = _Mock()

indices = _Mock()

inner = _Mock()

innerproduct = _Mock()

intersect1d = _Mock()

isMA = _Mock()

isMaskedArray = _Mock()

is_mask = _Mock()

is_masked = _Mock()

isarray = _Mock()

left_shift = _Mock()

less = _Mock()

less_equal = _Mock()

load = _Mock()

loads = _Mock()

log = _Mock()

log10 = _Mock()

log2 = _Mock()

logical_and = _Mock()

logical_not = _Mock()

logical_or = _Mock()

logical_xor = _Mock()

make_mask = _Mock()

make_mask_descr = _Mock()

make_mask_none = _Mock()

mask_cols = _Mock()

mask_or = _Mock()

mask_rowcols = _Mock()

mask_rows = _Mock()

masked = _Mock()

masked_all = _Mock()

masked_all_like = _Mock()

masked_equal = _Mock()

masked_greater = _Mock()

masked_greater_equal = _Mock()

masked_inside = _Mock()

masked_invalid = _Mock()

masked_less = _Mock()

masked_less_equal = _Mock()

masked_not_equal = _Mock()

masked_object = _Mock()

masked_outside = _Mock()

masked_print_option = _Mock()

masked_singleton = _Mock()

masked_values = _Mock()

masked_where = _Mock()

max = _Mock()

maximum = _Mock()

maximum_fill_value = _Mock()

mean = _Mock()

median = _Mock()

min = _Mock()

minimum = _Mock()

minimum_fill_value = _Mock()

mod = _Mock()

mr_ = _Mock()

mrecords = _Mock()

multiply = _Mock()

negative = _Mock()

nomask = _Mock()

nonzero = _Mock()

not_equal = _Mock()

notmasked_contiguous = _Mock()

notmasked_edges = _Mock()

ones = _Mock()

outer = _Mock()

outerproduct = _Mock()

polyfit = _Mock()

power = _Mock()

print_function = _Mock()

prod = _Mock()

product = _Mock()

ptp = _Mock()

put = _Mock()

putmask = _Mock()

rank = _Mock()

ravel = _Mock()

remainder = _Mock()

repeat = _Mock()

reshape = _Mock()

resize = _Mock()

right_shift = _Mock()

round = _Mock()

round_ = _Mock()

row_stack = _Mock()

set_fill_value = _Mock()

setdiff1d = _Mock()

setxor1d = _Mock()

shape = _Mock()

sin = _Mock()

sinh = _Mock()

size = _Mock()

soften_mask = _Mock()

sometrue = _Mock()

sort = _Mock()

sqrt = _Mock()

squeeze = _Mock()

std = _Mock()

subtract = _Mock()

sum = _Mock()

swapaxes = _Mock()

take = _Mock()

tan = _Mock()

tanh = _Mock()

test = _Mock()

trace = _Mock()

transpose = _Mock()

true_divide = _Mock()

union1d = _Mock()

unique = _Mock()

vander = _Mock()

var = _Mock()

vstack = _Mock()

where = _Mock()

zeros = _Mock()

__version__ = '1.0'

class MAError(_Mock):
  pass


class MaskError(_Mock):
  pass


class MaskType(_Mock):
  pass


class MaskedArray(_Mock):
  pass
  _defaulthardmask = False

class Tester(_Mock):
  pass


class bool_(_Mock):
  pass


class masked_array(_Mock):
  pass
  _defaulthardmask = False

class mvoid(_Mock):
  pass
  _defaulthardmask = False

