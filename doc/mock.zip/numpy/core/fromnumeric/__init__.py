from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_dt_ = _Mock()

_methods = _Mock()

_sum_ = _Mock()

_wrapit = _Mock()

absolute_import = _Mock()

alen = _Mock()

all = _Mock()

alltrue = _Mock()

amax = _Mock()

amin = _Mock()

any = _Mock()

argmax = _Mock()

argmin = _Mock()

argpartition = _Mock()

argsort = _Mock()

around = _Mock()

array = _Mock()

asanyarray = _Mock()

asarray = _Mock()

choose = _Mock()

clip = _Mock()

compress = _Mock()

concatenate = _Mock()

cumprod = _Mock()

cumproduct = _Mock()

cumsum = _Mock()

diagonal = _Mock()

division = _Mock()

mean = _Mock()

mu = _Mock()

ndim = _Mock()

nonzero = _Mock()

nt = _Mock()

partition = _Mock()

print_function = _Mock()

prod = _Mock()

product = _Mock()

ptp = _Mock()

put = _Mock()

rank = _Mock()

ravel = _Mock()

repeat = _Mock()

reshape = _Mock()

resize = _Mock()

round_ = _Mock()

searchsorted = _Mock()

shape = _Mock()

size = _Mock()

sometrue = _Mock()

sort = _Mock()

squeeze = _Mock()

std = _Mock()

sum = _Mock()

swapaxes = _Mock()

take = _Mock()

trace = _Mock()

transpose = _Mock()

types = _Mock()

um = _Mock()

var = _Mock()



class _gentype(_Mock):
  pass


