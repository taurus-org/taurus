from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_UFUNC_API = _Mock()

_arg = _Mock()

_ones_like = _Mock()

absolute = _Mock()

add = _Mock()

arccos = _Mock()

arccosh = _Mock()

arcsin = _Mock()

arcsinh = _Mock()

arctan = _Mock()

arctan2 = _Mock()

arctanh = _Mock()

bitwise_and = _Mock()

bitwise_or = _Mock()

bitwise_xor = _Mock()

ceil = _Mock()

conj = _Mock()

conjugate = _Mock()

copysign = _Mock()

cos = _Mock()

cosh = _Mock()

deg2rad = _Mock()

degrees = _Mock()

divide = _Mock()

equal = _Mock()

exp = _Mock()

exp2 = _Mock()

expm1 = _Mock()

fabs = _Mock()

floor = _Mock()

floor_divide = _Mock()

fmax = _Mock()

fmin = _Mock()

fmod = _Mock()

frexp = _Mock()

frompyfunc = _Mock()

geterrobj = _Mock()

greater = _Mock()

greater_equal = _Mock()

hypot = _Mock()

invert = _Mock()

isfinite = _Mock()

isinf = _Mock()

isnan = _Mock()

ldexp = _Mock()

left_shift = _Mock()

less = _Mock()

less_equal = _Mock()

log = _Mock()

log10 = _Mock()

log1p = _Mock()

log2 = _Mock()

logaddexp = _Mock()

logaddexp2 = _Mock()

logical_and = _Mock()

logical_not = _Mock()

logical_or = _Mock()

logical_xor = _Mock()

maximum = _Mock()

minimum = _Mock()

mod = _Mock()

modf = _Mock()

multiply = _Mock()

negative = _Mock()

nextafter = _Mock()

not_equal = _Mock()

power = _Mock()

rad2deg = _Mock()

radians = _Mock()

reciprocal = _Mock()

remainder = _Mock()

right_shift = _Mock()

rint = _Mock()

seterrobj = _Mock()

sign = _Mock()

signbit = _Mock()

sin = _Mock()

sinh = _Mock()

spacing = _Mock()

sqrt = _Mock()

square = _Mock()

subtract = _Mock()

tan = _Mock()

tanh = _Mock()

true_divide = _Mock()

trunc = _Mock()

ERR_CALL = 3

ERR_DEFAULT = 0

ERR_DEFAULT2 = 521

ERR_IGNORE = 0

ERR_LOG = 5

ERR_PRINT = 4

ERR_RAISE = 2

ERR_WARN = 1

FLOATING_POINT_SUPPORT = 1

FPE_DIVIDEBYZERO = 1

FPE_INVALID = 8

FPE_OVERFLOW = 2

FPE_UNDERFLOW = 4

NAN = float('nan')

NINF = float('-inf')

NZERO = -0.0

PINF = float('inf')

PZERO = 0.0

SHIFT_DIVIDEBYZERO = 0

SHIFT_INVALID = 9

SHIFT_OVERFLOW = 3

SHIFT_UNDERFLOW = 6

UFUNC_BUFSIZE_DEFAULT = 8192

UFUNC_PYVALS_NAME = 'UFUNC_PYVALS'

__version__ = '0.4.0'

e = 2.718281828459045

euler_gamma = 0.5772156649015329

pi = 3.141592653589793



