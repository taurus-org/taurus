from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_array2string = _Mock()

_boolFormatter = _Mock()

_convert_arrays = _Mock()

_digits = _Mock()

_extendLine = _Mock()

_formatArray = _Mock()

_formatter = _Mock()

_leading_trailing = _Mock()

_nt = _Mock()

absolute = _Mock()

absolute_import = _Mock()

array2string = _Mock()

datetime_as_string = _Mock()

datetime_data = _Mock()

division = _Mock()

format_longfloat = _Mock()

get_printoptions = _Mock()

isinf = _Mock()

isnan = _Mock()

maximum = _Mock()

minimum = _Mock()

not_equal = _Mock()

print_function = _Mock()

product = _Mock()

ravel = _Mock()

reduce = _Mock()

repr_format = _Mock()

set_printoptions = _Mock()

sys = _Mock()

_MAXINT = 9223372036854775807

_MININT = -9223372036854775808

_float_output_precision = 8

_float_output_suppress_small = _Mock()

_inf_str = 'inf'

_line_width = 75

_nan_str = 'nan'

_summaryEdgeItems = 3

_summaryThreshold = 1000

class ComplexFormat(_Mock):
  pass


class DatetimeFormat(_Mock):
  pass


class FloatFormat(_Mock):
  pass


class IntegerFormat(_Mock):
  pass


class LongComplexFormat(_Mock):
  pass


class LongFloatFormat(_Mock):
  pass


class TimedeltaFormat(_Mock):
  pass


