from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


False_ = _Mock()

ScalarType = _Mock()

True_ = _Mock()

_Unspecified = _Mock()

_errdict = _Mock()

_errdict_rev = _Mock()

_lkup = _Mock()

_maketup = _Mock()

_mode_from_name = _Mock()

_mode_from_name_dict = _Mock()

_move_axis_to_0 = _Mock()

_setdef = _Mock()

_typelessdata = _Mock()

absolute = _Mock()

absolute_import = _Mock()

add = _Mock()

alen = _Mock()

all = _Mock()

allclose = _Mock()

alltrue = _Mock()

alterdot = _Mock()

amax = _Mock()

amin = _Mock()

any = _Mock()

arange = _Mock()

arccos = _Mock()

arccosh = _Mock()

arcsin = _Mock()

arcsinh = _Mock()

arctan = _Mock()

arctan2 = _Mock()

arctanh = _Mock()

argmax = _Mock()

argmin = _Mock()

argpartition = _Mock()

argsort = _Mock()

argwhere = _Mock()

around = _Mock()

array = _Mock()

array2string = _Mock()

array_equal = _Mock()

array_equiv = _Mock()

array_repr = _Mock()

array_str = _Mock()

asanyarray = _Mock()

asarray = _Mock()

ascontiguousarray = _Mock()

asfortranarray = _Mock()

base_repr = _Mock()

binary_repr = _Mock()

bitwise_and = _Mock()

bitwise_not = _Mock()

bitwise_or = _Mock()

bitwise_xor = _Mock()

busday_count = _Mock()

busday_offset = _Mock()

can_cast = _Mock()

cast = _Mock()

ceil = _Mock()

choose = _Mock()

clip = _Mock()

collections = _Mock()

compare_chararrays = _Mock()

compress = _Mock()

concatenate = _Mock()

conj = _Mock()

conjugate = _Mock()

convolve = _Mock()

copysign = _Mock()

copyto = _Mock()

correlate = _Mock()

cos = _Mock()

cosh = _Mock()

count_nonzero = _Mock()

cross = _Mock()

cumprod = _Mock()

cumproduct = _Mock()

cumsum = _Mock()

datetime_as_string = _Mock()

datetime_data = _Mock()

deg2rad = _Mock()

degrees = _Mock()

diagonal = _Mock()

divide = _Mock()

division = _Mock()

dot = _Mock()

einsum = _Mock()

empty = _Mock()

empty_like = _Mock()

equal = _Mock()

exp = _Mock()

exp2 = _Mock()

expm1 = _Mock()

extend_all = _Mock()

fabs = _Mock()

fastCopyAndTranspose = _Mock()

find_common_type = _Mock()

flatnonzero = _Mock()

floor = _Mock()

floor_divide = _Mock()

fmax = _Mock()

fmin = _Mock()

fmod = _Mock()

frexp = _Mock()

frombuffer = _Mock()

fromfile = _Mock()

fromfunction = _Mock()

fromiter = _Mock()

fromnumeric = _Mock()

frompyfunc = _Mock()

fromstring = _Mock()

full = _Mock()

full_like = _Mock()

get_printoptions = _Mock()

getbuffer = _Mock()

getbufsize = _Mock()

geterr = _Mock()

geterrcall = _Mock()

geterrobj = _Mock()

greater = _Mock()

greater_equal = _Mock()

hypot = _Mock()

identity = _Mock()

indices = _Mock()

inner = _Mock()

int_asbuffer = _Mock()

invert = _Mock()

is_busday = _Mock()

isclose = _Mock()

isfinite = _Mock()

isfortran = _Mock()

isinf = _Mock()

isnan = _Mock()

isscalar = _Mock()

issctype = _Mock()

issubdtype = _Mock()

ldexp = _Mock()

left_shift = _Mock()

less = _Mock()

less_equal = _Mock()

lexsort = _Mock()

load = _Mock()

loads = _Mock()

log = _Mock()

log10 = _Mock()

log1p = _Mock()

log2 = _Mock()

logaddexp = _Mock()

logaddexp2 = _Mock()

logical_and = _Mock()

logical_not = _Mock()

logical_or = _Mock()

logical_xor = _Mock()

maximum = _Mock()

maximum_sctype = _Mock()

may_share_memory = _Mock()

mean = _Mock()

min_scalar_type = _Mock()

minimum = _Mock()

mod = _Mock()

modf = _Mock()

multiarray = _Mock()

multiply = _Mock()

nbytes = _Mock()

ndim = _Mock()

negative = _Mock()

nested_iters = _Mock()

newaxis = _Mock()

newbuffer = _Mock()

nextafter = _Mock()

nonzero = _Mock()

not_equal = _Mock()

numerictypes = _Mock()

obj2sctype = _Mock()

ones = _Mock()

ones_like = _Mock()

outer = _Mock()

partition = _Mock()

pickle = _Mock()

power = _Mock()

print_function = _Mock()

prod = _Mock()

product = _Mock()

promote_types = _Mock()

ptp = _Mock()

put = _Mock()

putmask = _Mock()

rad2deg = _Mock()

radians = _Mock()

rank = _Mock()

ravel = _Mock()

reciprocal = _Mock()

remainder = _Mock()

repeat = _Mock()

require = _Mock()

reshape = _Mock()

resize = _Mock()

restoredot = _Mock()

result_type = _Mock()

right_shift = _Mock()

rint = _Mock()

roll = _Mock()

rollaxis = _Mock()

round_ = _Mock()

sctype2char = _Mock()

sctypeDict = _Mock()

sctypeNA = _Mock()

sctypes = _Mock()

searchsorted = _Mock()

set_numeric_ops = _Mock()

set_printoptions = _Mock()

set_string_function = _Mock()

setbufsize = _Mock()

seterr = _Mock()

seterrcall = _Mock()

seterrobj = _Mock()

shape = _Mock()

sign = _Mock()

signbit = _Mock()

sin = _Mock()

sinh = _Mock()

size = _Mock()

sometrue = _Mock()

sort = _Mock()

spacing = _Mock()

sqrt = _Mock()

square = _Mock()

squeeze = _Mock()

std = _Mock()

subtract = _Mock()

sum = _Mock()

swapaxes = _Mock()

sys = _Mock()

take = _Mock()

tan = _Mock()

tanh = _Mock()

tensordot = _Mock()

trace = _Mock()

transpose = _Mock()

true_divide = _Mock()

trunc = _Mock()

typeDict = _Mock()

typeNA = _Mock()

typecodes = _Mock()

umath = _Mock()

var = _Mock()

vdot = _Mock()

warnings = _Mock()

where = _Mock()

zeros = _Mock()

zeros_like = _Mock()

ALLOW_THREADS = 1

BUFSIZE = 8192

CLIP = 0

ERR_CALL = 3

ERR_DEFAULT = 0

ERR_DEFAULT2 = 521

ERR_IGNORE = 0

ERR_LOG = 5

ERR_PRINT = 4

ERR_RAISE = 2

ERR_WARN = 1

FLOATING_POINT_SUPPORT = 1

FPE_DIVIDEBYZERO = 1

FPE_INVALID = 8

FPE_OVERFLOW = 2

FPE_UNDERFLOW = 4

Inf = float('inf')

Infinity = float('inf')

MAXDIMS = 32

NAN = float('nan')

NINF = float('-inf')

NZERO = -0.0

NaN = float('nan')

PINF = float('inf')

PZERO = 0.0

RAISE = 2

SHIFT_DIVIDEBYZERO = 0

SHIFT_INVALID = 9

SHIFT_OVERFLOW = 3

SHIFT_UNDERFLOW = 6

UFUNC_BUFSIZE_DEFAULT = 8192

UFUNC_PYVALS_NAME = 'UFUNC_PYVALS'

WRAP = 1

e = 2.718281828459045

euler_gamma = 0.5772156649015329

inf = float('inf')

infty = float('inf')

little_endian = _Mock()

nan = float('nan')

pi = 3.141592653589793

class ComplexWarning(_Mock):
  pass


class _unspecified(_Mock):
  pass


class bool8(_Mock):
  pass


class bool_(_Mock):
  pass


class broadcast(_Mock):
  pass


class busdaycalendar(_Mock):
  pass


class byte(_Mock):
  pass


class bytes_(_Mock):
  pass


class cdouble(_Mock):
  pass


class cfloat(_Mock):
  pass


class character(_Mock):
  pass


class clongdouble(_Mock):
  pass


class clongfloat(_Mock):
  pass


class complex128(_Mock):
  pass


class complex256(_Mock):
  pass


class complex64(_Mock):
  pass


class complex_(_Mock):
  pass


class complexfloating(_Mock):
  pass


class csingle(_Mock):
  pass


class datetime64(_Mock):
  pass


class double(_Mock):
  pass


class dtype(_Mock):
  pass


class errstate(_Mock):
  pass


class flatiter(_Mock):
  pass


class flexible(_Mock):
  pass


class float128(_Mock):
  pass


class float16(_Mock):
  pass


class float32(_Mock):
  pass


class float64(_Mock):
  pass


class float_(_Mock):
  pass


class floating(_Mock):
  pass


class generic(_Mock):
  pass


class half(_Mock):
  pass


class inexact(_Mock):
  pass


class int0(_Mock):
  pass


class int16(_Mock):
  pass


class int32(_Mock):
  pass


class int64(_Mock):
  pass


class int8(_Mock):
  pass


class int_(_Mock):
  pass


class intc(_Mock):
  pass


class integer(_Mock):
  pass


class intp(_Mock):
  pass


class longcomplex(_Mock):
  pass


class longdouble(_Mock):
  pass


class longfloat(_Mock):
  pass


class longlong(_Mock):
  pass


class ndarray(_Mock):
  pass


class nditer(_Mock):
  pass


class number(_Mock):
  pass


class object0(_Mock):
  pass


class object_(_Mock):
  pass


class short(_Mock):
  pass


class signedinteger(_Mock):
  pass


class single(_Mock):
  pass


class singlecomplex(_Mock):
  pass


class str_(_Mock):
  pass


class string0(_Mock):
  pass


class string_(_Mock):
  pass


class timedelta64(_Mock):
  pass


class ubyte(_Mock):
  pass


class ufunc(_Mock):
  pass


class uint(_Mock):
  pass


class uint0(_Mock):
  pass


class uint16(_Mock):
  pass


class uint32(_Mock):
  pass


class uint64(_Mock):
  pass


class uint8(_Mock):
  pass


class uintc(_Mock):
  pass


class uintp(_Mock):
  pass


class ulonglong(_Mock):
  pass


class unicode0(_Mock):
  pass


class unicode_(_Mock):
  pass


class unsignedinteger(_Mock):
  pass


class ushort(_Mock):
  pass


class void(_Mock):
  pass


class void0(_Mock):
  pass


