from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


DATETIMEUNITS = _Mock()

_ARRAY_API = _Mock()

_fastCopyAndTranspose = _Mock()

_flagdict = _Mock()

_get_ndarray_c_version = _Mock()

_reconstruct = _Mock()

_vec_string = _Mock()

arange = _Mock()

array = _Mock()

busday_count = _Mock()

busday_offset = _Mock()

can_cast = _Mock()

compare_chararrays = _Mock()

concatenate = _Mock()

copyto = _Mock()

correlate = _Mock()

correlate2 = _Mock()

count_nonzero = _Mock()

datetime_as_string = _Mock()

datetime_data = _Mock()

dot = _Mock()

einsum = _Mock()

empty = _Mock()

empty_like = _Mock()

format_longfloat = _Mock()

frombuffer = _Mock()

fromfile = _Mock()

fromiter = _Mock()

fromstring = _Mock()

getbuffer = _Mock()

inner = _Mock()

int_asbuffer = _Mock()

is_busday = _Mock()

lexsort = _Mock()

may_share_memory = _Mock()

min_scalar_type = _Mock()

nested_iters = _Mock()

newbuffer = _Mock()

promote_types = _Mock()

putmask = _Mock()

result_type = _Mock()

scalar = _Mock()

set_datetimeparse_function = _Mock()

set_numeric_ops = _Mock()

set_string_function = _Mock()

set_typeDict = _Mock()

test_interrupt = _Mock()

typeinfo = _Mock()

where = _Mock()

zeros = _Mock()

ALLOW_THREADS = 1

BUFSIZE = 8192

CLIP = 0

ITEM_HASOBJECT = 1

ITEM_IS_POINTER = 4

LIST_PICKLE = 2

MAXDIMS = 32

NEEDS_INIT = 8

NEEDS_PYAPI = 16

RAISE = 2

USE_GETITEM = 32

USE_SETITEM = 64

WRAP = 1

__version__ = '3.1'

class broadcast(_Mock):
  pass


class busdaycalendar(_Mock):
  pass


class dtype(_Mock):
  pass


class error(_Mock):
  pass


class flagsobj(_Mock):
  pass


class flatiter(_Mock):
  pass


class ndarray(_Mock):
  pass


class nditer(_Mock):
  pass


