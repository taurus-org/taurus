from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


ScalarType = _Mock()

_add_aliases = _Mock()

_add_array_type = _Mock()

_add_integer_aliases = _Mock()

_add_types = _Mock()

_alignment = _Mock()

_all_chars = _Mock()

_ascii_lower = _Mock()

_ascii_upper = _Mock()

_can_coerce_all = _Mock()

_construct_char_code_lookup = _Mock()

_construct_lookups = _Mock()

_evalname = _Mock()

_find_common_coerce = _Mock()

_kind_list = _Mock()

_maxvals = _Mock()

_minvals = _Mock()

_python_type = _Mock()

_python_types = _Mock()

_sctype2char_dict = _Mock()

_set_array_types = _Mock()

_set_up_aliases = _Mock()

_types = _Mock()

_typestr = _Mock()

absolute_import = _Mock()

allTypes = _Mock()

array = _Mock()

bitname = _Mock()

busday_count = _Mock()

busday_offset = _Mock()

cast = _Mock()

datetime_as_string = _Mock()

datetime_data = _Mock()

division = _Mock()

empty = _Mock()

english_capitalize = _Mock()

english_lower = _Mock()

english_upper = _Mock()

find_common_type = _Mock()

genericTypeRank = _Mock()

is_busday = _Mock()

issctype = _Mock()

issubclass_ = _Mock()

issubdtype = _Mock()

issubsctype = _Mock()

maximum_sctype = _Mock()

nbytes = _Mock()

obj2sctype = _Mock()

print_function = _Mock()

sctype2char = _Mock()

sctypeDict = _Mock()

sctypeNA = _Mock()

sctypes = _Mock()

sys = _Mock()

typeDict = _Mock()

typeNA = _Mock()

typecodes = _Mock()

typeinfo = _Mock()

LOWER_TABLE = '\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f !"#$%&\'()*+,-./0123456789:;<=>?@abcdefghijklmnopqrstuvwxyz[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~\x7f\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8a\x8b\x8c\x8d\x8e\x8f\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9a\x9b\x9c\x9d\x9e\x9f\xa0\xa1\xa2\xa3\xa4\xa5\xa6\xa7\xa8\xa9\xaa\xab\xac\xad\xae\xaf\xb0\xb1\xb2\xb3\xb4\xb5\xb6\xb7\xb8\xb9\xba\xbb\xbc\xbd\xbe\xbf\xc0\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xca\xcb\xcc\xcd\xce\xcf\xd0\xd1\xd2\xd3\xd4\xd5\xd6\xd7\xd8\xd9\xda\xdb\xdc\xdd\xde\xdf\xe0\xe1\xe2\xe3\xe4\xe5\xe6\xe7\xe8\xe9\xea\xeb\xec\xed\xee\xef\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf7\xf8\xf9\xfa\xfb\xfc\xfd\xfe\xff'

UPPER_TABLE = '\x00\x01\x02\x03\x04\x05\x06\x07\x08\t\n\x0b\x0c\r\x0e\x0f\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`ABCDEFGHIJKLMNOPQRSTUVWXYZ{|}~\x7f\x80\x81\x82\x83\x84\x85\x86\x87\x88\x89\x8a\x8b\x8c\x8d\x8e\x8f\x90\x91\x92\x93\x94\x95\x96\x97\x98\x99\x9a\x9b\x9c\x9d\x9e\x9f\xa0\xa1\xa2\xa3\xa4\xa5\xa6\xa7\xa8\xa9\xaa\xab\xac\xad\xae\xaf\xb0\xb1\xb2\xb3\xb4\xb5\xb6\xb7\xb8\xb9\xba\xbb\xbc\xbd\xbe\xbf\xc0\xc1\xc2\xc3\xc4\xc5\xc6\xc7\xc8\xc9\xca\xcb\xcc\xcd\xce\xcf\xd0\xd1\xd2\xd3\xd4\xd5\xd6\xd7\xd8\xd9\xda\xdb\xdc\xdd\xde\xdf\xe0\xe1\xe2\xe3\xe4\xe5\xe6\xe7\xe8\xe9\xea\xeb\xec\xed\xee\xef\xf0\xf1\xf2\xf3\xf4\xf5\xf6\xf7\xf8\xf9\xfa\xfb\xfc\xfd\xfe\xff'

_m = 255

val = 'c8'

class _typedict(_Mock):
  pass


class bool(_Mock):
  pass


class bool8(_Mock):
  pass


class bool_(_Mock):
  pass


class buffer_type(_Mock):
  pass


class busdaycalendar(_Mock):
  pass


class byte(_Mock):
  pass


class bytes(_Mock):
  pass


class bytes_(_Mock):
  pass


class cdouble(_Mock):
  pass


class cfloat(_Mock):
  pass


class character(_Mock):
  pass


class clongdouble(_Mock):
  pass


class clongfloat(_Mock):
  pass


class complex(_Mock):
  pass


class complex128(_Mock):
  pass


class complex256(_Mock):
  pass


class complex64(_Mock):
  pass


class complex_(_Mock):
  pass


class complexfloating(_Mock):
  pass


class csingle(_Mock):
  pass


class datetime64(_Mock):
  pass


class double(_Mock):
  pass


class dtype(_Mock):
  pass


class flexible(_Mock):
  pass


class float(_Mock):
  pass


class float128(_Mock):
  pass


class float16(_Mock):
  pass


class float32(_Mock):
  pass


class float64(_Mock):
  pass


class float_(_Mock):
  pass


class floating(_Mock):
  pass


class generic(_Mock):
  pass


class half(_Mock):
  pass


class inexact(_Mock):
  pass


class int(_Mock):
  pass


class int0(_Mock):
  pass


class int16(_Mock):
  pass


class int32(_Mock):
  pass


class int64(_Mock):
  pass


class int8(_Mock):
  pass


class int_(_Mock):
  pass


class intc(_Mock):
  pass


class integer(_Mock):
  pass


class intp(_Mock):
  pass


class long(_Mock):
  pass


class longcomplex(_Mock):
  pass


class longdouble(_Mock):
  pass


class longfloat(_Mock):
  pass


class longlong(_Mock):
  pass


class ndarray(_Mock):
  pass


class number(_Mock):
  pass


class object(_Mock):
  pass


class object0(_Mock):
  pass


class object_(_Mock):
  pass


class short(_Mock):
  pass


class signedinteger(_Mock):
  pass


class single(_Mock):
  pass


class singlecomplex(_Mock):
  pass


class str(_Mock):
  pass


class str_(_Mock):
  pass


class string0(_Mock):
  pass


class string_(_Mock):
  pass


class timedelta64(_Mock):
  pass


class ubyte(_Mock):
  pass


class uint(_Mock):
  pass


class uint0(_Mock):
  pass


class uint16(_Mock):
  pass


class uint32(_Mock):
  pass


class uint64(_Mock):
  pass


class uint8(_Mock):
  pass


class uintc(_Mock):
  pass


class uintp(_Mock):
  pass


class ulonglong(_Mock):
  pass


class unicode(_Mock):
  pass


class unicode0(_Mock):
  pass


class unicode_(_Mock):
  pass


class unsignedinteger(_Mock):
  pass


class ushort(_Mock):
  pass


class void(_Mock):
  pass


class void0(_Mock):
  pass


