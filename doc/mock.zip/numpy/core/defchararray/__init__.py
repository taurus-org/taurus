from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_clean_args = _Mock()

_get_num_chars = _Mock()

_len = _Mock()

_to_string_or_unicode_array = _Mock()

_use_unicode = _Mock()

_vec_string = _Mock()

absolute_import = _Mock()

add = _Mock()

array = _Mock()

asarray = _Mock()

capitalize = _Mock()

center = _Mock()

compare_chararrays = _Mock()

count = _Mock()

decode = _Mock()

division = _Mock()

encode = _Mock()

endswith = _Mock()

equal = _Mock()

expandtabs = _Mock()

find = _Mock()

greater = _Mock()

greater_equal = _Mock()

index = _Mock()

isalnum = _Mock()

isalpha = _Mock()

isdecimal = _Mock()

isdigit = _Mock()

islower = _Mock()

isnumeric = _Mock()

isspace = _Mock()

istitle = _Mock()

isupper = _Mock()

join = _Mock()

less = _Mock()

less_equal = _Mock()

ljust = _Mock()

lower = _Mock()

lstrip = _Mock()

mod = _Mock()

multiply = _Mock()

narray = _Mock()

not_equal = _Mock()

numpy = _Mock()

partition = _Mock()

print_function = _Mock()

replace = _Mock()

rfind = _Mock()

rindex = _Mock()

rjust = _Mock()

rpartition = _Mock()

rsplit = _Mock()

rstrip = _Mock()

split = _Mock()

splitlines = _Mock()

startswith = _Mock()

str_len = _Mock()

strip = _Mock()

swapcase = _Mock()

sys = _Mock()

title = _Mock()

translate = _Mock()

upper = _Mock()

zfill = _Mock()

_globalvar = 0

class _bytes(_Mock):
  pass


class _unicode(_Mock):
  pass


class asbytes(_Mock):
  pass


class bool_(_Mock):
  pass


class character(_Mock):
  pass


class chararray(_Mock):
  pass


class integer(_Mock):
  pass


class long(_Mock):
  pass


class ndarray(_Mock):
  pass


class object_(_Mock):
  pass


class string_(_Mock):
  pass


class unicode_(_Mock):
  pass


