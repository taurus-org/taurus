from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


C99_COMPLEX_FUNCS = _Mock()

C99_COMPLEX_TYPES = _Mock()

C99_FUNCS = _Mock()

C99_FUNCS_EXTENDED = _Mock()

C99_FUNCS_SINGLE = _Mock()

MANDATORY_FUNCS = _Mock()

OPTIONAL_GCC_ATTRIBUTES = _Mock()

OPTIONAL_HEADERS = _Mock()

OPTIONAL_INTRINSICS = _Mock()

OPTIONAL_STDFUNCS = _Mock()

OPTIONAL_STDFUNCS_MAYBE = _Mock()

_AFTER_SEQ = _Mock()

_BEFORE_SEQ = _Mock()

_DOUBLE_DOUBLE_BE = _Mock()

_DOUBLE_DOUBLE_LE = _Mock()

_IEEE_DOUBLE_BE = _Mock()

_IEEE_DOUBLE_LE = _Mock()

_IEEE_QUAD_PREC_BE = _Mock()

_IEEE_QUAD_PREC_LE = _Mock()

_INTEL_EXTENDED_12B = _Mock()

_INTEL_EXTENDED_16B = _Mock()

_MOTOROLA_EXTENDED_12B = _Mock()

absolute_import = _Mock()

binascii = _Mock()

check_api_version = _Mock()

check_long_double_representation = _Mock()

copy = _Mock()

division = _Mock()

fname2def = _Mock()

get_api_versions = _Mock()

is_released = _Mock()

join = _Mock()

long_double_representation = _Mock()

print_function = _Mock()

pyod = _Mock()

sym2def = _Mock()

sys = _Mock()

type2def = _Mock()

warnings = _Mock()

C_ABI_VERSION = 16777225

C_API_VERSION = 9

LONG_DOUBLE_REPRESENTATION_SRC = '\n/* "before" is 16 bytes to ensure there\'s no padding between it and "x".\n *    We\'re not expecting any "long double" bigger than 16 bytes or with\n *       alignment requirements stricter than 16 bytes.  */\ntypedef %(type)s test_type;\n\nstruct {\n        char         before[16];\n        test_type    x;\n        char         after[8];\n} foo = {\n        { \'\\0\', \'\\0\', \'\\0\', \'\\0\', \'\\0\', \'\\0\', \'\\0\', \'\\0\',\n          \'\\001\', \'\\043\', \'\\105\', \'\\147\', \'\\211\', \'\\253\', \'\\315\', \'\\357\' },\n        -123456789.0,\n        { \'\\376\', \'\\334\', \'\\272\', \'\\230\', \'\\166\', \'\\124\', \'\\062\', \'\\020\' }\n};\n'

f = 'nextafter'

class CompileError(_Mock):
  pass


class MismatchCAPIWarning(_Mock):
  pass


