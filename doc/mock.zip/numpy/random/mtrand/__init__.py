from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_rand = _Mock()

_shape_from_size = _Mock()

beta = _Mock()

binomial = _Mock()

bytes = _Mock()

chisquare = _Mock()

choice = _Mock()

dirichlet = _Mock()

exponential = _Mock()

f = _Mock()

gamma = _Mock()

geometric = _Mock()

get_state = _Mock()

gumbel = _Mock()

hypergeometric = _Mock()

laplace = _Mock()

logistic = _Mock()

lognormal = _Mock()

logseries = _Mock()

multinomial = _Mock()

multivariate_normal = _Mock()

negative_binomial = _Mock()

noncentral_chisquare = _Mock()

noncentral_f = _Mock()

normal = _Mock()

np = _Mock()

operator = _Mock()

pareto = _Mock()

permutation = _Mock()

poisson = _Mock()

power = _Mock()

rand = _Mock()

randint = _Mock()

randn = _Mock()

random_integers = _Mock()

random_sample = _Mock()

rayleigh = _Mock()

seed = _Mock()

set_state = _Mock()

shuffle = _Mock()

standard_cauchy = _Mock()

standard_exponential = _Mock()

standard_gamma = _Mock()

standard_normal = _Mock()

standard_t = _Mock()

triangular = _Mock()

uniform = _Mock()

vonmises = _Mock()

wald = _Mock()

weibull = _Mock()

zipf = _Mock()



class RandomState(_Mock):
  pass
  poisson_lam_max = 9.2233720064847708e+18

