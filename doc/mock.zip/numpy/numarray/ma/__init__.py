from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


absolute = _Mock()

absolute_import = _Mock()

add = _Mock()

allclose = _Mock()

allequal = _Mock()

alltrue = _Mock()

amax = _Mock()

amin = _Mock()

arange = _Mock()

arccos = _Mock()

arccosh = _Mock()

arcsin = _Mock()

arcsinh = _Mock()

arctan = _Mock()

arctan2 = _Mock()

arctanh = _Mock()

argmax = _Mock()

argmin = _Mock()

argsort = _Mock()

around = _Mock()

arrayrange = _Mock()

asarray = _Mock()

average = _Mock()

bitwise_and = _Mock()

bitwise_or = _Mock()

bitwise_xor = _Mock()

ceil = _Mock()

choose = _Mock()

common_fill_value = _Mock()

compress = _Mock()

concatenate = _Mock()

conjugate = _Mock()

cos = _Mock()

cosh = _Mock()

count = _Mock()

default_complex_fill_value = _Mock()

default_fill_value = _Mock()

diagonal = _Mock()

divide = _Mock()

division = _Mock()

dot = _Mock()

equal = _Mock()

exp = _Mock()

fabs = _Mock()

filled = _Mock()

floor = _Mock()

floor_divide = _Mock()

fmod = _Mock()

fromfunction = _Mock()

fromnumeric = _Mock()

fromstring = _Mock()

get_fill_value = _Mock()

getmask = _Mock()

getmaskarray = _Mock()

greater = _Mock()

greater_equal = _Mock()

hypot = _Mock()

identity = _Mock()

indices = _Mock()

inner = _Mock()

innerproduct = _Mock()

isMA = _Mock()

isMaskedArray = _Mock()

is_mask = _Mock()

isarray = _Mock()

left_shift = _Mock()

less = _Mock()

less_equal = _Mock()

log = _Mock()

log10 = _Mock()

logical_and = _Mock()

logical_not = _Mock()

logical_or = _Mock()

logical_xor = _Mock()

make_mask = _Mock()

make_mask_none = _Mock()

mask_or = _Mock()

masked = _Mock()

masked_array = _Mock()

masked_equal = _Mock()

masked_greater = _Mock()

masked_greater_equal = _Mock()

masked_inside = _Mock()

masked_less = _Mock()

masked_less_equal = _Mock()

masked_not_equal = _Mock()

masked_object = _Mock()

masked_outside = _Mock()

masked_print_option = _Mock()

masked_values = _Mock()

masked_where = _Mock()

maximum = _Mock()

maximum_fill_value = _Mock()

minimum = _Mock()

minimum_fill_value = _Mock()

multiply = _Mock()

negative = _Mock()

new_average = _Mock()

new_repeat = _Mock()

new_take = _Mock()

newaxis = _Mock()

nomask = _Mock()

nonzero = _Mock()

not_equal = _Mock()

numeric = _Mock()

ones = _Mock()

outer = _Mock()

outerproduct = _Mock()

power = _Mock()

print_function = _Mock()

product = _Mock()

put = _Mock()

putmask = _Mock()

rank = _Mock()

ravel = _Mock()

reduce = _Mock()

remainder = _Mock()

repeat = _Mock()

reshape = _Mock()

resize = _Mock()

right_shift = _Mock()

set_fill_value = _Mock()

shape = _Mock()

sin = _Mock()

sinh = _Mock()

size = _Mock()

sometrue = _Mock()

sort = _Mock()

sqrt = _Mock()

subtract = _Mock()

sum = _Mock()

swapaxes = _Mock()

sys = _Mock()

take = _Mock()

tan = _Mock()

tanh = _Mock()

trace = _Mock()

transpose = _Mock()

true_divide = _Mock()

typecodes = _Mock()

types = _Mock()

ufunc_domain = _Mock()

ufunc_fills = _Mock()

umath = _Mock()

warnings = _Mock()

where = _Mock()

zeros = _Mock()

default_character_fill_value = '-'

default_integer_fill_value = 999999

default_object_fill_value = '?'

default_real_fill_value = 1e+20

divide_tolerance = 1e-35

inf = float('inf')

class MAError(_Mock):
  pass


class MaskType(_Mock):
  pass


class MaskedArray(_Mock):
  pass


class array(_Mock):
  pass


class bool_(_Mock):
  pass


class bytes(_Mock):
  pass


class domain_check_interval(_Mock):
  pass


class domain_greater(_Mock):
  pass


class domain_greater_equal(_Mock):
  pass


class domain_safe_divide(_Mock):
  pass


class domain_tan(_Mock):
  pass


class domained_binary_operation(_Mock):
  pass


class long(_Mock):
  pass


class masked_binary_operation(_Mock):
  pass


class masked_unary_operation(_Mock):
  pass


class ndarray(_Mock):
  pass


