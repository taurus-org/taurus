from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_resizebuf = _Mock()

_warnings = _Mock()

absolute_import = _Mock()

all = _Mock()

allclose = _Mock()

alltrue = _Mock()

and_ = _Mock()

any = _Mock()

arange = _Mock()

argmax = _Mock()

argmin = _Mock()

argsort = _Mock()

around = _Mock()

array = _Mock()

array2list = _Mock()

array_equal = _Mock()

array_equiv = _Mock()

array_repr = _Mock()

array_str = _Mock()

arrayrange = _Mock()

asarray = _Mock()

average = _Mock()

choose = _Mock()

clip = _Mock()

compress = _Mock()

concatenate = _Mock()

copy = _Mock()

copy_reg = _Mock()

cumproduct = _Mock()

cumsum = _Mock()

diagonal = _Mock()

divide_remainder = _Mock()

division = _Mock()

dot = _Mock()

explicit_type = _Mock()

flush_caches = _Mock()

fromfile = _Mock()

fromfunction = _Mock()

fromlist = _Mock()

fromstring = _Mock()

getShape = _Mock()

getTypeObject = _Mock()

identity = _Mock()

indices = _Mock()

info = _Mock()

innerproduct = _Mock()

inputarray = _Mock()

kroneckerproduct = _Mock()

lexsort = _Mock()

math = _Mock()

matrixmultiply = _Mock()

newobj = _Mock()

nonzero = _Mock()

np = _Mock()

ones = _Mock()

operator = _Mock()

os = _Mock()

outerproduct = _Mock()

print_function = _Mock()

put = _Mock()

putmask = _Mock()

rank = _Mock()

ravel = _Mock()

repeat = _Mock()

reshape = _Mock()

resize = _Mock()

round = _Mock()

searchsorted = _Mock()

shape = _Mock()

size = _Mock()

sometrue = _Mock()

sort = _Mock()

swapaxes = _Mock()

sys = _Mock()

take = _Mock()

tensormultiply = _Mock()

togglebyteorder = _Mock()

trace = _Mock()

transpose = _Mock()

type2dtype = _Mock()

typefrom = _Mock()

types = _Mock()

vdot = _Mock()

where = _Mock()

zeros = _Mock()

CLIP = 0

RAISE = 2

SLOPPY = 1

STRICT = 0

WARN = 2

WRAP = 1

_BLOCKSIZE = 1024

e = 2.718281828459045

isBigEndian = _Mock()

pi = 3.141592653589793

tcode = 'f'

tname = 'Float32'

value = 'f'

class EarlyEOFError(_Mock):
  pass


class FileSeekWarning(_Mock):
  pass


class SizeMismatchError(_Mock):
  pass


class SizeMismatchWarning(_Mock):
  pass


class long(_Mock):
  pass


