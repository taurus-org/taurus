from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


Any = _Mock()

Bool = _Mock()

Byte = _Mock()

Complex = _Mock()

Complex32 = _Mock()

Complex64 = _Mock()

Float = _Mock()

Float32 = _Mock()

Float64 = _Mock()

Int = _Mock()

Int16 = _Mock()

Int32 = _Mock()

Int64 = _Mock()

Int8 = _Mock()

IsType = _Mock()

Long = _Mock()

MaximumType = _Mock()

MaybeLong = _Mock()

Object = _Mock()

Short = _Mock()

UInt16 = _Mock()

UInt32 = _Mock()

UInt64 = _Mock()

UInt8 = _Mock()

_MaximumType = _Mock()

_initGenericCoercions = _Mock()

_register = _Mock()

_scipy_alias = _Mock()

_scipy_dtypechar = _Mock()

_scipy_dtypechar_inverse = _Mock()

absolute_import = _Mock()

bool8 = _Mock()

bool_ = _Mock()

complex128 = _Mock()

complex64 = _Mock()

division = _Mock()

float32 = _Mock()

float64 = _Mock()

genericCoercions = _Mock()

genericPromotionExclusions = _Mock()

genericTypeRank = _Mock()

getType = _Mock()

int16 = _Mock()

int32 = _Mock()

int64 = _Mock()

int8 = _Mock()

key = _Mock()

numpy = _Mock()

print_function = _Mock()

pythonTypeMap = _Mock()

pythonTypeRank = _Mock()

scalarTypeMap = _Mock()

scalarTypes = _Mock()

typeDict = _Mock()

typecodes = _Mock()

typefrom = _Mock()

uint16 = _Mock()

uint32 = _Mock()

uint64 = _Mock()

uint8 = _Mock()

HasUInt64 = 1

LP64 = _Mock()

MAX_ALIGN = 8

MAX_INT_SIZE = 8

_tAny = 0

_tBool = 1

_tComplex32 = 12

_tComplex64 = 13

_tFloat32 = 10

_tFloat64 = 11

_tInt16 = 4

_tInt32 = 6

_tInt64 = 8

_tInt8 = 2

_tObject = 14

_tUInt16 = 5

_tUInt32 = 7

_tUInt64 = 9

_tUInt8 = 3

value = 'f'

class AnyType(_Mock):
  pass


class BooleanType(_Mock):
  pass


class ComplexType(_Mock):
  pass


class FloatingType(_Mock):
  pass


class IntegralType(_Mock):
  pass


class NumericType(_Mock):
  pass


class ObjectType(_Mock):
  pass


class SignedIntegralType(_Mock):
  pass


class SignedType(_Mock):
  pass


class UnsignedIntegralType(_Mock):
  pass


class UnsignedType(_Mock):
  pass


class long(_Mock):
  pass


