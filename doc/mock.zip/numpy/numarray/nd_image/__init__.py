from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


absolute_import = _Mock()

affine_transform = _Mock()

binary_closing = _Mock()

binary_dilation = _Mock()

binary_erosion = _Mock()

binary_fill_holes = _Mock()

binary_hit_or_miss = _Mock()

binary_opening = _Mock()

binary_propagation = _Mock()

black_tophat = _Mock()

center_of_mass = _Mock()

convolve = _Mock()

convolve1d = _Mock()

correlate = _Mock()

correlate1d = _Mock()

distance_transform_bf = _Mock()

distance_transform_cdt = _Mock()

distance_transform_edt = _Mock()

division = _Mock()

extrema = _Mock()

filters = _Mock()

find_objects = _Mock()

fourier = _Mock()

fourier_ellipsoid = _Mock()

fourier_gaussian = _Mock()

fourier_shift = _Mock()

fourier_uniform = _Mock()

gaussian_filter = _Mock()

gaussian_filter1d = _Mock()

gaussian_gradient_magnitude = _Mock()

gaussian_laplace = _Mock()

generate_binary_structure = _Mock()

generic_filter = _Mock()

generic_filter1d = _Mock()

generic_gradient_magnitude = _Mock()

generic_laplace = _Mock()

geometric_transform = _Mock()

grey_closing = _Mock()

grey_dilation = _Mock()

grey_erosion = _Mock()

grey_opening = _Mock()

histogram = _Mock()

imread = _Mock()

interpolation = _Mock()

io = _Mock()

iterate_structure = _Mock()

label = _Mock()

labeled_comprehension = _Mock()

laplace = _Mock()

map_coordinates = _Mock()

maximum = _Mock()

maximum_filter = _Mock()

maximum_filter1d = _Mock()

maximum_position = _Mock()

mean = _Mock()

measurements = _Mock()

median = _Mock()

median_filter = _Mock()

minimum = _Mock()

minimum_filter = _Mock()

minimum_filter1d = _Mock()

minimum_position = _Mock()

morphological_gradient = _Mock()

morphological_laplace = _Mock()

morphology = _Mock()

percentile_filter = _Mock()

prewitt = _Mock()

print_function = _Mock()

rank_filter = _Mock()

rotate = _Mock()

shift = _Mock()

sobel = _Mock()

spline_filter = _Mock()

spline_filter1d = _Mock()

standard_deviation = _Mock()

sum = _Mock()

uniform_filter = _Mock()

uniform_filter1d = _Mock()

variance = _Mock()

watershed_ift = _Mock()

white_tophat = _Mock()

zoom = _Mock()





