from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


Any = _Mock()

Bool = _Mock()

Byte = _Mock()

Complex = _Mock()

Complex32 = _Mock()

Complex64 = _Mock()

Float = _Mock()

Float32 = _Mock()

Float64 = _Mock()

Int = _Mock()

Int16 = _Mock()

Int32 = _Mock()

Int64 = _Mock()

Int8 = _Mock()

IsType = _Mock()

Long = _Mock()

MaximumType = _Mock()

MaybeLong = _Mock()

NewAxis = _Mock()

Object = _Mock()

Short = _Mock()

UInt16 = _Mock()

UInt32 = _Mock()

UInt64 = _Mock()

UInt8 = _Mock()

abs = _Mock()

absolute = _Mock()

absolute_import = _Mock()

add = _Mock()

all = _Mock()

allclose = _Mock()

alltrue = _Mock()

and_ = _Mock()

any = _Mock()

arange = _Mock()

arccos = _Mock()

arccosh = _Mock()

arcsin = _Mock()

arcsinh = _Mock()

arctan = _Mock()

arctan2 = _Mock()

arctanh = _Mock()

argmax = _Mock()

argmin = _Mock()

argsort = _Mock()

around = _Mock()

array = _Mock()

array2list = _Mock()

array_equal = _Mock()

array_equiv = _Mock()

array_repr = _Mock()

array_str = _Mock()

arrayrange = _Mock()

asarray = _Mock()

average = _Mock()

bench = _Mock()

bitwise_and = _Mock()

bitwise_not = _Mock()

bitwise_or = _Mock()

bitwise_xor = _Mock()

ceil = _Mock()

choose = _Mock()

clip = _Mock()

compress = _Mock()

concatenate = _Mock()

conjugate = _Mock()

copy = _Mock()

copy_reg = _Mock()

cos = _Mock()

cosh = _Mock()

cumproduct = _Mock()

cumsum = _Mock()

diagonal = _Mock()

divide = _Mock()

divide_remainder = _Mock()

division = _Mock()

dot = _Mock()

equal = _Mock()

exp = _Mock()

explicit_type = _Mock()

fabs = _Mock()

floor = _Mock()

floor_divide = _Mock()

flush_caches = _Mock()

fmod = _Mock()

fromfile = _Mock()

fromfunction = _Mock()

fromlist = _Mock()

fromstring = _Mock()

genericCoercions = _Mock()

genericPromotionExclusions = _Mock()

genericTypeRank = _Mock()

getShape = _Mock()

getType = _Mock()

getTypeObject = _Mock()

get_numarray_include_dirs = _Mock()

greater = _Mock()

greater_equal = _Mock()

handleError = _Mock()

hypot = _Mock()

identity = _Mock()

indices = _Mock()

info = _Mock()

innerproduct = _Mock()

inputarray = _Mock()

isnan = _Mock()

kroneckerproduct = _Mock()

less = _Mock()

less_equal = _Mock()

lexsort = _Mock()

load = _Mock()

log = _Mock()

log10 = _Mock()

logical_and = _Mock()

logical_not = _Mock()

logical_or = _Mock()

logical_xor = _Mock()

lshift = _Mock()

math = _Mock()

matrixmultiply = _Mock()

maximum = _Mock()

minimum = _Mock()

minus = _Mock()

multiply = _Mock()

negative = _Mock()

newobj = _Mock()

nonzero = _Mock()

not_equal = _Mock()

numerictypes = _Mock()

ones = _Mock()

operator = _Mock()

os = _Mock()

outerproduct = _Mock()

power = _Mock()

print_function = _Mock()

product = _Mock()

put = _Mock()

putmask = _Mock()

pythonTypeMap = _Mock()

pythonTypeRank = _Mock()

rank = _Mock()

ravel = _Mock()

remainder = _Mock()

repeat = _Mock()

reshape = _Mock()

resize = _Mock()

round = _Mock()

rshift = _Mock()

save = _Mock()

scalarTypeMap = _Mock()

scalarTypes = _Mock()

searchsorted = _Mock()

session = _Mock()

shape = _Mock()

sign = _Mock()

sin = _Mock()

sinh = _Mock()

size = _Mock()

sometrue = _Mock()

sort = _Mock()

sqrt = _Mock()

subtract = _Mock()

sum = _Mock()

swapaxes = _Mock()

sys = _Mock()

take = _Mock()

tan = _Mock()

tanh = _Mock()

tensormultiply = _Mock()

test = _Mock()

togglebyteorder = _Mock()

trace = _Mock()

transpose = _Mock()

true_divide = _Mock()

typeDict = _Mock()

typecodes = _Mock()

typefrom = _Mock()

types = _Mock()

vdot = _Mock()

warnings = _Mock()

where = _Mock()

zeros = _Mock()

CLIP = 0

HasUInt64 = 1

RAISE = 2

SLOPPY = 1

STRICT = 0

WARN = 2

WRAP = 1

_msg = 'The numarray module will be dropped in Numpy 1.9'

e = 2.718281828459045

isBigEndian = _Mock()

pi = 3.141592653589793

tcode = 'f'

tname = 'Float32'

value = 'f'

class AnyType(_Mock):
  pass


class ArrayType(_Mock):
  pass


class BooleanType(_Mock):
  pass


class ComplexType(_Mock):
  pass


class EarlyEOFError(_Mock):
  pass


class FileSeekWarning(_Mock):
  pass


class FloatingType(_Mock):
  pass


class IntegralType(_Mock):
  pass


class MathDomainError(_Mock):
  pass


class ModuleDeprecationWarning(_Mock):
  pass


class NumOverflowError(_Mock):
  pass


class NumericType(_Mock):
  pass


class ObjectType(_Mock):
  pass


class SignedIntegralType(_Mock):
  pass


class SignedType(_Mock):
  pass


class SizeMismatchError(_Mock):
  pass


class SizeMismatchWarning(_Mock):
  pass


class Tester(_Mock):
  pass


class UnderflowError(_Mock):
  pass


class UnsignedIntegralType(_Mock):
  pass


class UnsignedType(_Mock):
  pass


