from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_assertFinite = _Mock()

_assertNdSquareness = _Mock()

_assertNoEmpty2d = _Mock()

_assertRank2 = _Mock()

_assertRankAtLeast2 = _Mock()

_assertSquareness = _Mock()

_commonType = _Mock()

_complexType = _Mock()

_complex_types_map = _Mock()

_convertarray = _Mock()

_determine_error_states = _Mock()

_fastCT = _Mock()

_fastCopyAndTranspose = _Mock()

_linalgRealType = _Mock()

_linalg_error_extobj = _Mock()

_makearray = _Mock()

_multi_svd_norm = _Mock()

_raise_linalgerror_eigenvalues_nonconvergence = _Mock()

_raise_linalgerror_nonposdef = _Mock()

_raise_linalgerror_singular = _Mock()

_raise_linalgerror_svd_nonconvergence = _Mock()

_realType = _Mock()

_real_types_map = _Mock()

_to_native_byte_order = _Mock()

_umath_linalg = _Mock()

abs = _Mock()

absolute_import = _Mock()

add = _Mock()

all = _Mock()

amax = _Mock()

amin = _Mock()

array = _Mock()

asarray = _Mock()

asfarray = _Mock()

cholesky = _Mock()

cond = _Mock()

det = _Mock()

division = _Mock()

dot = _Mock()

eig = _Mock()

eigh = _Mock()

eigvals = _Mock()

eigvalsh = _Mock()

empty = _Mock()

empty_like = _Mock()

fastCopyAndTranspose = _Mock()

get_linalg_error_extobj = _Mock()

geterrobj = _Mock()

inv = _Mock()

isComplexType = _Mock()

isfinite = _Mock()

lapack_lite = _Mock()

lstsq = _Mock()

matrix_power = _Mock()

matrix_rank = _Mock()

maximum = _Mock()

multiply = _Mock()

newaxis = _Mock()

norm = _Mock()

pinv = _Mock()

print_function = _Mock()

product = _Mock()

qr = _Mock()

ravel = _Mock()

rollaxis = _Mock()

size = _Mock()

slogdet = _Mock()

solve = _Mock()

sqrt = _Mock()

sum = _Mock()

svd = _Mock()

tensorinv = _Mock()

tensorsolve = _Mock()

transpose = _Mock()

triu = _Mock()

warnings = _Mock()

zeros = _Mock()

Inf = float('inf')

_A = 'A'

_L = 'L'

_N = 'N'

_S = 'S'

_V = 'V'

class LinAlgError(_Mock):
  pass


class asbytes(_Mock):
  pass


class broadcast(_Mock):
  pass


class cdouble(_Mock):
  pass


class complexfloating(_Mock):
  pass


class csingle(_Mock):
  pass


class double(_Mock):
  pass


class errstate(_Mock):
  pass


class finfo(_Mock):
  pass


class fortran_int(_Mock):
  pass


class inexact(_Mock):
  pass


class intc(_Mock):
  pass


class longdouble(_Mock):
  pass


class single(_Mock):
  pass


