from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_umath_linalg = _Mock()

absolute_import = _Mock()

bench = _Mock()

cholesky = _Mock()

cond = _Mock()

det = _Mock()

division = _Mock()

eig = _Mock()

eigh = _Mock()

eigvals = _Mock()

eigvalsh = _Mock()

info = _Mock()

inv = _Mock()

lapack_lite = _Mock()

linalg = _Mock()

lstsq = _Mock()

matrix_power = _Mock()

matrix_rank = _Mock()

norm = _Mock()

pinv = _Mock()

print_function = _Mock()

qr = _Mock()

slogdet = _Mock()

solve = _Mock()

svd = _Mock()

tensorinv = _Mock()

tensorsolve = _Mock()

test = _Mock()



class LinAlgError(_Mock):
  pass


class Tester(_Mock):
  pass


