from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


DEBUG = _Mock()

_check_append_ext_library = _Mock()

_check_append_library = _Mock()

_command_line_ok = _Mock()

_dict_append = _Mock()

absolute_import = _Mock()

bdist_rpm = _Mock()

build = _Mock()

build_clib = _Mock()

build_ext = _Mock()

build_py = _Mock()

build_scripts = _Mock()

build_src = _Mock()

config = _Mock()

config_compiler = _Mock()

distutils = _Mock()

division = _Mock()

extension_keywords = _Mock()

gen_usage = _Mock()

get_data_files = _Mock()

get_distribution = _Mock()

install = _Mock()

install_clib = _Mock()

install_data = _Mock()

install_headers = _Mock()

is_sequence = _Mock()

is_string = _Mock()

numpy_cmdclass = _Mock()

old_setup = _Mock()

os = _Mock()

print_function = _Mock()

run_setup = _Mock()

sdist = _Mock()

setup = _Mock()

setup_keywords = _Mock()

sys = _Mock()

warnings = _Mock()

USAGE = 'usage: %(script)s [global_opts] cmd1 [cmd1_opts] [cmd2 [cmd2_opts] ...]\n   or: %(script)s --help [cmd1 cmd2 ...]\n   or: %(script)s --help-commands\n   or: %(script)s cmd --help\n'

have_setuptools = _Mock()

class CCompilerError(_Mock):
  pass


class Command(_Mock):
  pass


class Distribution(_Mock):
  pass
  common_usage = "Common commands: (see '--help-commands' for more)\n\n  setup.py build      will build the package underneath 'build/'\n  setup.py install    will install the package\n"

class DistutilsArgError(_Mock):
  pass


class DistutilsError(_Mock):
  pass


class DistutilsSetupError(_Mock):
  pass


class Extension(_Mock):
  pass


class NumpyDistribution(_Mock):
  pass
  common_usage = "Common commands: (see '--help-commands' for more)\n\n  setup.py build      will build the package underneath 'build/'\n  setup.py install    will install the package\n"

class PyPIRCCommand(_Mock):
  pass
  DEFAULT_REALM = 'pypi'
  DEFAULT_REPOSITORY = 'https://pypi.python.org/pypi'

