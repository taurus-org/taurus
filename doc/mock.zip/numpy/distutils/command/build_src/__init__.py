from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_f2py_module_name_match = _Mock()

_f2py_user_module_name_match = _Mock()

_f_pyf_ext_match = _Mock()

_find_swig_target = _Mock()

_has_c_header = _Mock()

_has_cpp_header = _Mock()

_header_ext_match = _Mock()

_swig_module_name_match = _Mock()

absolute_import = _Mock()

appendpath = _Mock()

build_ext = _Mock()

copy = _Mock()

division = _Mock()

fortran_ext_match = _Mock()

get_cmd = _Mock()

get_f2py_modulename = _Mock()

get_platform = _Mock()

get_swig_modulename = _Mock()

get_swig_target = _Mock()

have_pyrex = _Mock()

is_sequence = _Mock()

is_string = _Mock()

log = _Mock()

newer = _Mock()

newer_group = _Mock()

os = _Mock()

print_function = _Mock()

process_c_file = _Mock()

process_f_file = _Mock()

re = _Mock()

shlex = _Mock()

subst_vars = _Mock()

sys = _Mock()



class DistutilsError(_Mock):
  pass


class DistutilsSetupError(_Mock):
  pass


class build_src(_Mock):
  pass
  description = 'build sources from SWIG, F2PY files or a function'
  sep_by = " (separated by ':')"

