from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_bits = _Mock()

_cached_atlas_version = _Mock()

absolute_import = _Mock()

combine_paths = _Mock()

copy = _Mock()

default_include_dirs = _Mock()

default_lib_dirs = _Mock()

default_src_dirs = _Mock()

default_x11_include_dirs = _Mock()

default_x11_lib_dirs = _Mock()

dict_append = _Mock()

distutils = _Mock()

division = _Mock()

exec_command = _Mock()

find_executable = _Mock()

get_atlas_version = _Mock()

get_exception = _Mock()

get_info = _Mock()

get_platform = _Mock()

get_pythonexe = _Mock()

get_shared_lib_extension = _Mock()

get_standard_file = _Mock()

glob = _Mock()

globbed_x11_dir = _Mock()

inv_language_map = _Mock()

is_sequence = _Mock()

is_string = _Mock()

language_map = _Mock()

libpaths = _Mock()

log = _Mock()

os = _Mock()

p = _Mock()

parseCmdLine = _Mock()

platform = _Mock()

print_function = _Mock()

re = _Mock()

reduce = _Mock()

show_all = _Mock()

sp = _Mock()

sys = _Mock()

tmp = _Mock()

warnings = _Mock()

_m = '/sw/src'

atlas_version_c_text = '\n/* This file is generated from numpy/distutils/system_info.py */\nvoid ATL_buildinfo(void);\nint main(void) {\n  ATL_buildinfo();\n  return 0;\n}\n'

platform_bits = 64

so_ext = '.so'

triplet = 'x86_64-linux-gnu'

x11_so_dir = '/usr/lib/x86_64-linux-gnu'

class AtlasNotFoundError(_Mock):
  pass


class BlasNotFoundError(_Mock):
  pass


class BlasSrcNotFoundError(_Mock):
  pass


class ConfigParser(_Mock):
  pass


class DJBFFTNotFoundError(_Mock):
  pass


class Distribution(_Mock):
  pass
  common_usage = "Common commands: (see '--help-commands' for more)\n\n  setup.py build      will build the package underneath 'build/'\n  setup.py install    will install the package\n"

class DistutilsError(_Mock):
  pass


class FFTWNotFoundError(_Mock):
  pass


class LapackNotFoundError(_Mock):
  pass


class LapackSrcNotFoundError(_Mock):
  pass


class NoOptionError(_Mock):
  pass


class NotFoundError(_Mock):
  pass


class NumericNotFoundError(_Mock):
  pass


class Numeric_info(_Mock):
  pass
  modulename = 'Numeric'
  search_static_first = 0
  section = 'Numeric'
  verbosity = 1

class UmfpackNotFoundError(_Mock):
  pass


class X11NotFoundError(_Mock):
  pass


class _numpy_info(_Mock):
  pass
  modulename = 'Numeric'
  search_static_first = 0
  section = 'Numeric'
  verbosity = 1

class _pkg_config_info(_Mock):
  pass
  append_config_exe = ''
  cflags_flag = '--cflags'
  config_env_var = 'PKG_CONFIG'
  default_config_exe = 'pkg-config'
  search_static_first = 0
  verbosity = 1
  version_flag = '--modversion'

class agg2_info(_Mock):
  pass
  dir_env_var = 'AGG2'
  search_static_first = 0
  section = 'agg2'
  verbosity = 1

class amd_info(_Mock):
  pass
  dir_env_var = 'AMD'
  search_static_first = 0
  section = 'amd'
  verbosity = 1

class atlas_blas_info(_Mock):
  pass
  dir_env_var = 'ATLAS'
  search_static_first = 0
  section = 'atlas'
  verbosity = 1

class atlas_blas_threads_info(_Mock):
  pass
  search_static_first = 0
  section = 'atlas'
  verbosity = 1

class atlas_info(_Mock):
  pass
  dir_env_var = 'ATLAS'
  search_static_first = 0
  section = 'atlas'
  verbosity = 1

class atlas_threads_info(_Mock):
  pass
  search_static_first = 0
  section = 'atlas'
  verbosity = 1

class blas_info(_Mock):
  pass
  dir_env_var = 'BLAS'
  search_static_first = 0
  section = 'blas'
  verbosity = 1

class blas_mkl_info(_Mock):
  pass
  dir_env_var = 'MKL'
  search_static_first = 0
  section = 'mkl'
  verbosity = 1

class blas_opt_info(_Mock):
  pass
  search_static_first = 0
  section = 'ALL'
  verbosity = 1

class blas_src_info(_Mock):
  pass
  dir_env_var = 'BLAS_SRC'
  search_static_first = 0
  section = 'blas_src'
  verbosity = 1

class boost_python_info(_Mock):
  pass
  dir_env_var = 'BOOST'
  search_static_first = 0
  section = 'boost_python'
  verbosity = 1

class cmd_config(_Mock):
  pass
  description = 'prepare to build'

class dfftw_info(_Mock):
  pass
  dir_env_var = 'FFTW'
  search_static_first = 0
  section = 'fftw'
  verbosity = 1

class dfftw_threads_info(_Mock):
  pass
  dir_env_var = 'FFTW'
  search_static_first = 0
  section = 'fftw'
  verbosity = 1

class djbfft_info(_Mock):
  pass
  dir_env_var = 'DJBFFT'
  search_static_first = 0
  section = 'djbfft'
  verbosity = 1

class f2py_info(_Mock):
  pass
  search_static_first = 0
  section = 'ALL'
  verbosity = 1

class fft_opt_info(_Mock):
  pass
  search_static_first = 0
  section = 'ALL'
  verbosity = 1

class fftw2_info(_Mock):
  pass
  dir_env_var = 'FFTW'
  search_static_first = 0
  section = 'fftw'
  verbosity = 1

class fftw3_info(_Mock):
  pass
  dir_env_var = 'FFTW3'
  search_static_first = 0
  section = 'fftw3'
  verbosity = 1

class fftw_info(_Mock):
  pass
  dir_env_var = 'FFTW'
  search_static_first = 0
  section = 'fftw'
  verbosity = 1

class fftw_threads_info(_Mock):
  pass
  dir_env_var = 'FFTW'
  search_static_first = 0
  section = 'fftw'
  verbosity = 1

class freetype2_info(_Mock):
  pass
  append_config_exe = 'freetype2'
  cflags_flag = '--cflags'
  config_env_var = 'PKG_CONFIG'
  default_config_exe = 'pkg-config'
  search_static_first = 0
  section = 'freetype2'
  verbosity = 1
  version_flag = '--modversion'
  version_macro_name = 'FREETYPE2_VERSION'

class gdk_2_info(_Mock):
  pass
  append_config_exe = 'gdk-2.0'
  cflags_flag = '--cflags'
  config_env_var = 'PKG_CONFIG'
  default_config_exe = 'pkg-config'
  search_static_first = 0
  section = 'gdk_2'
  verbosity = 1
  version_flag = '--modversion'
  version_macro_name = 'GDK_VERSION'

class gdk_info(_Mock):
  pass
  append_config_exe = 'gdk'
  cflags_flag = '--cflags'
  config_env_var = 'PKG_CONFIG'
  default_config_exe = 'pkg-config'
  search_static_first = 0
  section = 'gdk'
  verbosity = 1
  version_flag = '--modversion'
  version_macro_name = 'GDK_VERSION'

class gdk_pixbuf_2_info(_Mock):
  pass
  append_config_exe = 'gdk-pixbuf-2.0'
  cflags_flag = '--cflags'
  config_env_var = 'PKG_CONFIG'
  default_config_exe = 'pkg-config'
  search_static_first = 0
  section = 'gdk_pixbuf_2'
  verbosity = 1
  version_flag = '--modversion'
  version_macro_name = 'GDK_PIXBUF_VERSION'

class gdk_pixbuf_xlib_2_info(_Mock):
  pass
  append_config_exe = 'gdk-pixbuf-xlib-2.0'
  cflags_flag = '--cflags'
  config_env_var = 'PKG_CONFIG'
  default_config_exe = 'pkg-config'
  search_static_first = 0
  section = 'gdk_pixbuf_xlib_2'
  verbosity = 1
  version_flag = '--modversion'
  version_macro_name = 'GDK_PIXBUF_XLIB_VERSION'

class gdk_x11_2_info(_Mock):
  pass
  append_config_exe = 'gdk-x11-2.0'
  cflags_flag = '--cflags'
  config_env_var = 'PKG_CONFIG'
  default_config_exe = 'pkg-config'
  search_static_first = 0
  section = 'gdk_x11_2'
  verbosity = 1
  version_flag = '--modversion'
  version_macro_name = 'GDK_X11_VERSION'

class gtkp_2_info(_Mock):
  pass
  append_config_exe = 'gtk+-2.0'
  cflags_flag = '--cflags'
  config_env_var = 'PKG_CONFIG'
  default_config_exe = 'pkg-config'
  search_static_first = 0
  section = 'gtkp_2'
  verbosity = 1
  version_flag = '--modversion'
  version_macro_name = 'GTK_VERSION'

class gtkp_x11_2_info(_Mock):
  pass
  append_config_exe = 'gtk+-x11-2.0'
  cflags_flag = '--cflags'
  config_env_var = 'PKG_CONFIG'
  default_config_exe = 'pkg-config'
  search_static_first = 0
  section = 'gtkp_x11_2'
  verbosity = 1
  version_flag = '--modversion'
  version_macro_name = 'GTK_X11_VERSION'

class lapack_atlas_info(_Mock):
  pass
  dir_env_var = 'ATLAS'
  search_static_first = 0
  section = 'atlas'
  verbosity = 1

class lapack_atlas_threads_info(_Mock):
  pass
  search_static_first = 0
  section = 'atlas'
  verbosity = 1

class lapack_info(_Mock):
  pass
  dir_env_var = 'LAPACK'
  search_static_first = 0
  section = 'lapack'
  verbosity = 1

class lapack_mkl_info(_Mock):
  pass
  dir_env_var = 'MKL'
  search_static_first = 0
  section = 'mkl'
  verbosity = 1

class lapack_opt_info(_Mock):
  pass
  search_static_first = 0
  section = 'ALL'
  verbosity = 1

class lapack_src_info(_Mock):
  pass
  dir_env_var = 'LAPACK_SRC'
  search_static_first = 0
  section = 'lapack_src'
  verbosity = 1

class mkl_info(_Mock):
  pass
  dir_env_var = 'MKL'
  search_static_first = 0
  section = 'mkl'
  verbosity = 1

class numarray_info(_Mock):
  pass
  modulename = 'numarray'
  search_static_first = 0
  section = 'numarray'
  verbosity = 1

class numerix_info(_Mock):
  pass
  search_static_first = 0
  section = 'numerix'
  verbosity = 1

class numpy_info(_Mock):
  pass
  modulename = 'numpy'
  search_static_first = 0
  section = 'numpy'
  verbosity = 1

class openblas_info(_Mock):
  pass
  dir_env_var = 'OPENBLAS'
  search_static_first = 0
  section = 'openblas'
  verbosity = 1

class sfftw_info(_Mock):
  pass
  dir_env_var = 'FFTW'
  search_static_first = 0
  section = 'fftw'
  verbosity = 1

class sfftw_threads_info(_Mock):
  pass
  dir_env_var = 'FFTW'
  search_static_first = 0
  section = 'fftw'
  verbosity = 1

class system_info(_Mock):
  pass
  search_static_first = 0
  section = 'ALL'
  verbosity = 1

class umfpack_info(_Mock):
  pass
  dir_env_var = 'UMFPACK'
  search_static_first = 0
  section = 'umfpack'
  verbosity = 1

class wx_info(_Mock):
  pass
  append_config_exe = ''
  cflags_flag = '--cxxflags'
  config_env_var = 'WX_CONFIG'
  default_config_exe = 'wx-config'
  release_macro_name = 'WX_RELEASE'
  search_static_first = 0
  section = 'wx'
  verbosity = 1
  version_flag = '--version'
  version_macro_name = 'WX_VERSION'

class x11_info(_Mock):
  pass
  search_static_first = 0
  section = 'x11'
  verbosity = 1

class xft_info(_Mock):
  pass
  append_config_exe = 'xft'
  cflags_flag = '--cflags'
  config_env_var = 'PKG_CONFIG'
  default_config_exe = 'pkg-config'
  search_static_first = 0
  section = 'xft'
  verbosity = 1
  version_flag = '--modversion'
  version_macro_name = 'XFT_VERSION'

