from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_fix_paths = _Mock()

_get_directories = _Mock()

_get_f90_modules = _Mock()

_get_headers = _Mock()

_temporary_directory = _Mock()

absolute_import = _Mock()

all_strings = _Mock()

allpath = _Mock()

appendpath = _Mock()

as_list = _Mock()

atexit = _Mock()

blue_text = _Mock()

clean_up_temporary_directory = _Mock()

colour_text = _Mock()

copy = _Mock()

cxx_ext_match = _Mock()

cyan_text = _Mock()

cyg2win32 = _Mock()

default_config_dict = _Mock()

default_text = _Mock()

dict_append = _Mock()

distutils = _Mock()

division = _Mock()

dot_join = _Mock()

f90_ext_match = _Mock()

f90_module_name_match = _Mock()

filter_sources = _Mock()

fortran_ext_match = _Mock()

general_source_directories_files = _Mock()

general_source_files = _Mock()

generate_config_py = _Mock()

get_build_architecture = _Mock()

get_cmd = _Mock()

get_data_files = _Mock()

get_dependencies = _Mock()

get_exception = _Mock()

get_ext_source_files = _Mock()

get_frame = _Mock()

get_info = _Mock()

get_language = _Mock()

get_lib_source_files = _Mock()

get_mathlibs = _Mock()

get_npy_pkg_dir = _Mock()

get_numpy_include_dirs = _Mock()

get_path_from_frame = _Mock()

get_pkg_info = _Mock()

get_script_files = _Mock()

get_shared_lib_extension = _Mock()

glob = _Mock()

gpaths = _Mock()

green_text = _Mock()

has_cxx_sources = _Mock()

has_f_sources = _Mock()

imp = _Mock()

is_bootstrapping = _Mock()

is_glob_pattern = _Mock()

is_local_src_dir = _Mock()

is_sequence = _Mock()

is_string = _Mock()

make_temp_file = _Mock()

mingw32 = _Mock()

minrelpath = _Mock()

msvc_runtime_library = _Mock()

msvc_version = _Mock()

njoin = _Mock()

os = _Mock()

print_function = _Mock()

quote_args = _Mock()

re = _Mock()

red_text = _Mock()

rel_path = _Mock()

shutil = _Mock()

subprocess = _Mock()

sys = _Mock()

tempfile = _Mock()

terminal_has_colors = _Mock()

yellow_text = _Mock()



class Configuration(_Mock):
  pass


class DistutilsError(_Mock):
  pass


class InstallableLib(_Mock):
  pass


