from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_exec_command = _Mock()

_exec_command_posix = _Mock()

_exec_command_python = _Mock()

_preserve_environment = _Mock()

_supports_fileno = _Mock()

_update_environment = _Mock()

absolute_import = _Mock()

division = _Mock()

exec_command = _Mock()

find_executable = _Mock()

get_exception = _Mock()

get_pythonexe = _Mock()

is_sequence = _Mock()

log = _Mock()

make_temp_file = _Mock()

open_latin1 = _Mock()

os = _Mock()

print_function = _Mock()

quote_arg = _Mock()

shlex = _Mock()

splitcmdline = _Mock()

sys = _Mock()

temp_file_name = _Mock()

test = _Mock()

test_cl = _Mock()

test_execute_in = _Mock()

test_nt = _Mock()

test_posix = _Mock()

test_svn = _Mock()





