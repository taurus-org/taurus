from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


CCompiler_compile = _Mock()

CCompiler_customize = _Mock()

CCompiler_customize_cmd = _Mock()

CCompiler_cxx_compiler = _Mock()

CCompiler_get_version = _Mock()

CCompiler_object_filenames = _Mock()

CCompiler_show_customization = _Mock()

CCompiler_spawn = _Mock()

_compiler_to_string = _Mock()

_distutils_gen_lib_options = _Mock()

_distutils_gen_preprocess_options = _Mock()

_distutils_new_compiler = _Mock()

_dquote_re = _Mock()

_has_white_re = _Mock()

_m = _Mock()

_squote_re = _Mock()

_wordchars_re = _Mock()

absolute_import = _Mock()

ccompiler = _Mock()

compiler_class = _Mock()

copy = _Mock()

customize_compiler = _Mock()

cyg2win32 = _Mock()

division = _Mock()

exec_command = _Mock()

execute = _Mock()

gen_lib_options = _Mock()

gen_preprocess_options = _Mock()

get_default_compiler = _Mock()

get_exception = _Mock()

is_sequence = _Mock()

log = _Mock()

mingw32 = _Mock()

mkpath = _Mock()

move_file = _Mock()

new_compiler = _Mock()

newer_group = _Mock()

os = _Mock()

print_function = _Mock()

quote_args = _Mock()

re = _Mock()

replace_method = _Mock()

show_compilers = _Mock()

simple_version_match = _Mock()

spawn = _Mock()

split_quoted = _Mock()

string = _Mock()

sys = _Mock()

types = _Mock()

_cc = 'unixc'

class CCompiler(_Mock):
  pass
  EXECUTABLE = 'executable'
  SHARED_LIBRARY = 'shared_library'
  SHARED_OBJECT = 'shared_object'

class CompileError(_Mock):
  pass


class DistutilsExecError(_Mock):
  pass


class DistutilsModuleError(_Mock):
  pass


class DistutilsPlatformError(_Mock):
  pass


class LinkError(_Mock):
  pass


class LooseVersion(_Mock):
  pass


class UnknownFileError(_Mock):
  pass


