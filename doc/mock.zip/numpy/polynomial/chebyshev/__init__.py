from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_cseries_to_zseries = _Mock()

_zseries_der = _Mock()

_zseries_div = _Mock()

_zseries_int = _Mock()

_zseries_mul = _Mock()

_zseries_to_cseries = _Mock()

absolute_import = _Mock()

cheb2poly = _Mock()

chebadd = _Mock()

chebcompanion = _Mock()

chebder = _Mock()

chebdiv = _Mock()

chebdomain = _Mock()

chebfit = _Mock()

chebfromroots = _Mock()

chebgauss = _Mock()

chebgrid2d = _Mock()

chebgrid3d = _Mock()

chebint = _Mock()

chebline = _Mock()

chebmul = _Mock()

chebmulx = _Mock()

chebone = _Mock()

chebpow = _Mock()

chebpts1 = _Mock()

chebpts2 = _Mock()

chebroots = _Mock()

chebsub = _Mock()

chebtrim = _Mock()

chebval = _Mock()

chebval2d = _Mock()

chebval3d = _Mock()

chebvander = _Mock()

chebvander2d = _Mock()

chebvander3d = _Mock()

chebweight = _Mock()

chebx = _Mock()

chebzero = _Mock()

division = _Mock()

la = _Mock()

np = _Mock()

poly2cheb = _Mock()

polytemplate = _Mock()

print_function = _Mock()

pu = _Mock()

warnings = _Mock()



class Chebyshev(_Mock):
  pass
  maxpower = 16

