from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


absolute_import = _Mock()

division = _Mock()

herm2poly = _Mock()

hermadd = _Mock()

hermcompanion = _Mock()

hermder = _Mock()

hermdiv = _Mock()

hermdomain = _Mock()

hermfit = _Mock()

hermfromroots = _Mock()

hermgauss = _Mock()

hermgrid2d = _Mock()

hermgrid3d = _Mock()

hermint = _Mock()

hermline = _Mock()

hermmul = _Mock()

hermmulx = _Mock()

hermone = _Mock()

hermpow = _Mock()

hermroots = _Mock()

hermsub = _Mock()

hermtrim = _Mock()

hermval = _Mock()

hermval2d = _Mock()

hermval3d = _Mock()

hermvander = _Mock()

hermvander2d = _Mock()

hermvander3d = _Mock()

hermweight = _Mock()

hermx = _Mock()

hermzero = _Mock()

la = _Mock()

np = _Mock()

poly2herm = _Mock()

polytemplate = _Mock()

print_function = _Mock()

pu = _Mock()

warnings = _Mock()



class Hermite(_Mock):
  pass
  maxpower = 16

