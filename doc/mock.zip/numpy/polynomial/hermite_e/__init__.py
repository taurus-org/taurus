from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


absolute_import = _Mock()

division = _Mock()

herme2poly = _Mock()

hermeadd = _Mock()

hermecompanion = _Mock()

hermeder = _Mock()

hermediv = _Mock()

hermedomain = _Mock()

hermefit = _Mock()

hermefromroots = _Mock()

hermegauss = _Mock()

hermegrid2d = _Mock()

hermegrid3d = _Mock()

hermeint = _Mock()

hermeline = _Mock()

hermemul = _Mock()

hermemulx = _Mock()

hermeone = _Mock()

hermepow = _Mock()

hermeroots = _Mock()

hermesub = _Mock()

hermetrim = _Mock()

hermeval = _Mock()

hermeval2d = _Mock()

hermeval3d = _Mock()

hermevander = _Mock()

hermevander2d = _Mock()

hermevander3d = _Mock()

hermeweight = _Mock()

hermex = _Mock()

hermezero = _Mock()

la = _Mock()

np = _Mock()

poly2herme = _Mock()

polytemplate = _Mock()

print_function = _Mock()

pu = _Mock()

warnings = _Mock()



class HermiteE(_Mock):
  pass
  maxpower = 16

