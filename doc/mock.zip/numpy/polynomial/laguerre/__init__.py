from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


absolute_import = _Mock()

division = _Mock()

la = _Mock()

lag2poly = _Mock()

lagadd = _Mock()

lagcompanion = _Mock()

lagder = _Mock()

lagdiv = _Mock()

lagdomain = _Mock()

lagfit = _Mock()

lagfromroots = _Mock()

laggauss = _Mock()

laggrid2d = _Mock()

laggrid3d = _Mock()

lagint = _Mock()

lagline = _Mock()

lagmul = _Mock()

lagmulx = _Mock()

lagone = _Mock()

lagpow = _Mock()

lagroots = _Mock()

lagsub = _Mock()

lagtrim = _Mock()

lagval = _Mock()

lagval2d = _Mock()

lagval3d = _Mock()

lagvander = _Mock()

lagvander2d = _Mock()

lagvander3d = _Mock()

lagweight = _Mock()

lagx = _Mock()

lagzero = _Mock()

np = _Mock()

poly2lag = _Mock()

polytemplate = _Mock()

print_function = _Mock()

pu = _Mock()

warnings = _Mock()



class Laguerre(_Mock):
  pass
  maxpower = 16

