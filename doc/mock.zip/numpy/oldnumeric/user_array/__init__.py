from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


DumpArray = _Mock()

LoadArray = _Mock()

NewAxis = _Mock()

absolute = _Mock()

absolute_import = _Mock()

add = _Mock()

allclose = _Mock()

alltrue = _Mock()

arange = _Mock()

arccos = _Mock()

arccosh = _Mock()

arcsin = _Mock()

arcsinh = _Mock()

arctan = _Mock()

arctan2 = _Mock()

arctanh = _Mock()

argmax = _Mock()

argmin = _Mock()

argsort = _Mock()

around = _Mock()

array = _Mock()

array2string = _Mock()

array_constructor = _Mock()

array_repr = _Mock()

array_str = _Mock()

arrayrange = _Mock()

asarray = _Mock()

average = _Mock()

bitwise_and = _Mock()

bitwise_or = _Mock()

bitwise_xor = _Mock()

ceil = _Mock()

choose = _Mock()

clip = _Mock()

compress = _Mock()

concatenate = _Mock()

conjugate = _Mock()

convolve = _Mock()

copy = _Mock()

copy_reg = _Mock()

cos = _Mock()

cosh = _Mock()

cross_correlate = _Mock()

cross_product = _Mock()

cumproduct = _Mock()

cumsum = _Mock()

diagonal = _Mock()

divide = _Mock()

divide_safe = _Mock()

division = _Mock()

dot = _Mock()

dump = _Mock()

dumps = _Mock()

empty = _Mock()

equal = _Mock()

exp = _Mock()

fabs = _Mock()

floor = _Mock()

floor_divide = _Mock()

fmod = _Mock()

fromfunction = _Mock()

fromstring = _Mock()

greater = _Mock()

greater_equal = _Mock()

hypot = _Mock()

identity = _Mock()

indices = _Mock()

innerproduct = _Mock()

insert = _Mock()

invert = _Mock()

left_shift = _Mock()

less = _Mock()

less_equal = _Mock()

load = _Mock()

loads = _Mock()

log = _Mock()

log10 = _Mock()

logical_and = _Mock()

logical_not = _Mock()

logical_or = _Mock()

logical_xor = _Mock()

math = _Mock()

matrixmultiply = _Mock()

maximum = _Mock()

minimum = _Mock()

multiarray = _Mock()

multiply = _Mock()

negative = _Mock()

nonzero = _Mock()

not_equal = _Mock()

ones = _Mock()

outerproduct = _Mock()

pickle = _Mock()

pickle_array = _Mock()

power = _Mock()

print_function = _Mock()

product = _Mock()

put = _Mock()

putmask = _Mock()

rank = _Mock()

ravel = _Mock()

remainder = _Mock()

repeat = _Mock()

reshape = _Mock()

resize = _Mock()

right_shift = _Mock()

sarray = _Mock()

searchsorted = _Mock()

shape = _Mock()

sign = _Mock()

sin = _Mock()

sinh = _Mock()

size = _Mock()

sometrue = _Mock()

sort = _Mock()

sqrt = _Mock()

string = _Mock()

subtract = _Mock()

sum = _Mock()

swapaxes = _Mock()

take = _Mock()

tan = _Mock()

tanh = _Mock()

trace = _Mock()

transpose = _Mock()

true_divide = _Mock()

typecodes = _Mock()

types = _Mock()

vdot = _Mock()

where = _Mock()

zeros = _Mock()

Character = 'c'

Complex = 'D'

Complex0 = 'F'

Complex16 = 'F'

Complex32 = 'F'

Complex64 = 'D'

Complex8 = 'F'

Float = 'd'

Float0 = 'f'

Float16 = 'f'

Float32 = 'f'

Float64 = 'd'

Float8 = 'f'

Int = 'l'

Int0 = 'b'

Int16 = 'h'

Int32 = 'i'

Int64 = 'l'

Int8 = 'b'

LittleEndian = _Mock()

PyObject = 'O'

UInt = 'u'

UInt16 = 'H'

UInt32 = 'I'

UInt64 = 'L'

UInt8 = 'B'

UnsignedInt = 'u'

UnsignedInt16 = 'H'

UnsignedInt32 = 'I'

UnsignedInt64 = 'L'

UnsignedInt8 = 'B'

UnsignedInteger = 'u'

__version__ = '1.8.2'

e = 2.718281828459045

pi = 3.141592653589793

class ArrayType(_Mock):
  pass


class Pickler(_Mock):
  pass
  _BATCHSIZE = 1000

class PrecisionError(_Mock):
  pass


class StringIO(_Mock):
  pass


class UFuncType(_Mock):
  pass


class UfuncType(_Mock):
  pass


class Unpickler(_Mock):
  pass


class UserArray(_Mock):
  pass


class arraytype(_Mock):
  pass


