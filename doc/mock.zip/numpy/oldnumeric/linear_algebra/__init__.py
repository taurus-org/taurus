from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


Heigenvalues = _Mock()

Heigenvectors = _Mock()

absolute_import = _Mock()

cholesky_decomposition = _Mock()

determinant = _Mock()

division = _Mock()

eigenvalues = _Mock()

eigenvectors = _Mock()

generalized_inverse = _Mock()

inverse = _Mock()

linalg = _Mock()

linear_least_squares = _Mock()

print_function = _Mock()

singular_value_decomposition = _Mock()

solve_linear_equations = _Mock()

transpose = _Mock()



class LinAlgError(_Mock):
  pass


