from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


absolute_import = _Mock()

alltrue = _Mock()

arange = _Mock()

argmax = _Mock()

argmin = _Mock()

array = _Mock()

asarray = _Mock()

average = _Mock()

compress = _Mock()

convtypecode = _Mock()

convtypecode2 = _Mock()

cross_product = _Mock()

cumproduct = _Mock()

cumsum = _Mock()

division = _Mock()

empty = _Mock()

fromfunction = _Mock()

fromstring = _Mock()

identity = _Mock()

indices = _Mock()

mu = _Mock()

nn = _Mock()

nonzero = _Mock()

np = _Mock()

ones = _Mock()

print_function = _Mock()

product = _Mock()

ravel = _Mock()

repeat = _Mock()

reshape = _Mock()

sarray = _Mock()

sometrue = _Mock()

sum = _Mock()

take = _Mock()

trace = _Mock()

where = _Mock()

zeros = _Mock()





