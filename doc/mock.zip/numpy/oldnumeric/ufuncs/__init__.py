from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


absolute = _Mock()

absolute_import = _Mock()

add = _Mock()

arccos = _Mock()

arccosh = _Mock()

arcsin = _Mock()

arcsinh = _Mock()

arctan = _Mock()

arctan2 = _Mock()

arctanh = _Mock()

bitwise_and = _Mock()

bitwise_or = _Mock()

bitwise_xor = _Mock()

ceil = _Mock()

conjugate = _Mock()

cos = _Mock()

cosh = _Mock()

divide = _Mock()

divide_safe = _Mock()

division = _Mock()

equal = _Mock()

exp = _Mock()

fabs = _Mock()

floor = _Mock()

floor_divide = _Mock()

fmod = _Mock()

greater = _Mock()

greater_equal = _Mock()

hypot = _Mock()

invert = _Mock()

left_shift = _Mock()

less = _Mock()

less_equal = _Mock()

log = _Mock()

log10 = _Mock()

logical_and = _Mock()

logical_not = _Mock()

logical_or = _Mock()

logical_xor = _Mock()

maximum = _Mock()

minimum = _Mock()

multiply = _Mock()

negative = _Mock()

not_equal = _Mock()

power = _Mock()

print_function = _Mock()

remainder = _Mock()

right_shift = _Mock()

sin = _Mock()

sinh = _Mock()

sqrt = _Mock()

subtract = _Mock()

tan = _Mock()

tanh = _Mock()

true_divide = _Mock()





