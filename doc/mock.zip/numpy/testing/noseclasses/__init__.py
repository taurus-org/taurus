from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


absolute_import = _Mock()

division = _Mock()

doctest = _Mock()

get_package_name = _Mock()

inspect = _Mock()

nose = _Mock()

npd = _Mock()

numpy = _Mock()

os = _Mock()

print_function = _Mock()

print_state = _Mock()

src = _Mock()



class ErrorClass(_Mock):
  pass


class ErrorClassPlugin(_Mock):
  pass
  can_configure = False
  enabled = False
  score = 1000

class KnownFailure(_Mock):
  pass
  can_configure = False
  enabled = True
  score = 1000

class KnownFailureTest(_Mock):
  pass


class NumpyDocTestCase(_Mock):
  pass
  _classSetupFailed = False
  _diffThreshold = 65536
  longMessage = False
  maxDiff = 640

class NumpyDocTestFinder(_Mock):
  pass


class NumpyDoctest(_Mock):
  pass
  can_configure = False
  doctest_optflags = 12
  enabled = False
  name = 'numpydoctest'
  score = 1000

class NumpyOutputChecker(_Mock):
  pass


class NumpyTestProgram(_Mock):
  pass
  USAGE = "Usage: %(progName)s [options] [test] [...]\n\nOptions:\n  -h, --help       Show this message\n  -v, --verbose    Verbose output\n  -q, --quiet      Minimal output\n%(failfast)s%(catchbreak)s%(buffer)s\nExamples:\n  %(progName)s                               - run default set of tests\n  %(progName)s MyTestSuite                   - run suite 'MyTestSuite'\n  %(progName)s MyTestCase.testSomething      - run MyTestCase.testSomething\n  %(progName)s MyTestCase                    - run all 'test*' test methods\n                                               in MyTestCase\n"
  verbosity = 1

class Plugin(_Mock):
  pass
  can_configure = False
  enabled = False
  score = 100

class Unplugger(_Mock):
  pass
  enabled = True
  name = 'unplugger'
  score = 4000

