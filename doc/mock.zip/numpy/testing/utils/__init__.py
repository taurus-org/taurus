from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_assert_valid_refcount = _Mock()

_gen_alignment_data = _Mock()

_integer_repr = _Mock()

absolute_import = _Mock()

arange = _Mock()

assert_ = _Mock()

assert_allclose = _Mock()

assert_almost_equal = _Mock()

assert_approx_equal = _Mock()

assert_array_almost_equal = _Mock()

assert_array_almost_equal_nulp = _Mock()

assert_array_compare = _Mock()

assert_array_equal = _Mock()

assert_array_less = _Mock()

assert_array_max_ulp = _Mock()

assert_equal = _Mock()

assert_no_warnings = _Mock()

assert_raises = _Mock()

assert_string_equal = _Mock()

assert_warns = _Mock()

build_err_msg = _Mock()

decorate_methods = _Mock()

division = _Mock()

empty = _Mock()

gisfinite = _Mock()

gisinf = _Mock()

gisnan = _Mock()

import_nose = _Mock()

integer_repr = _Mock()

jiffies = _Mock()

measure = _Mock()

memusage = _Mock()

nulp_diff = _Mock()

operator = _Mock()

os = _Mock()

print_assert_equal = _Mock()

print_function = _Mock()

raises = _Mock()

rand = _Mock()

re = _Mock()

rundocs = _Mock()

runstring = _Mock()

sys = _Mock()

warnings = _Mock()

verbose = 0

class IgnoreException(_Mock):
  pass


class StringIO(_Mock):
  pass


class WarningManager(_Mock):
  pass


class WarningMessage(_Mock):
  pass


class float32(_Mock):
  pass


