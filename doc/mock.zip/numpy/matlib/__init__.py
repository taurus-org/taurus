from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


False_ = _Mock()

ScalarType = _Mock()

True_ = _Mock()

absolute = _Mock()

absolute_import = _Mock()

add = _Mock()

add_docstring = _Mock()

add_newdoc = _Mock()

add_newdoc_ufunc = _Mock()

add_newdocs = _Mock()

alen = _Mock()

all = _Mock()

allclose = _Mock()

alltrue = _Mock()

alterdot = _Mock()

amax = _Mock()

amin = _Mock()

angle = _Mock()

any = _Mock()

append = _Mock()

apply_along_axis = _Mock()

apply_over_axes = _Mock()

arange = _Mock()

arccos = _Mock()

arccosh = _Mock()

arcsin = _Mock()

arcsinh = _Mock()

arctan = _Mock()

arctan2 = _Mock()

arctanh = _Mock()

argmax = _Mock()

argmin = _Mock()

argpartition = _Mock()

argsort = _Mock()

argwhere = _Mock()

around = _Mock()

array = _Mock()

array2string = _Mock()

array_equal = _Mock()

array_equiv = _Mock()

array_repr = _Mock()

array_split = _Mock()

array_str = _Mock()

asanyarray = _Mock()

asarray = _Mock()

asarray_chkfinite = _Mock()

ascontiguousarray = _Mock()

asfarray = _Mock()

asfortranarray = _Mock()

asmatrix = _Mock()

asscalar = _Mock()

atleast_1d = _Mock()

atleast_2d = _Mock()

atleast_3d = _Mock()

average = _Mock()

bartlett = _Mock()

base_repr = _Mock()

binary_repr = _Mock()

bincount = _Mock()

bitwise_and = _Mock()

bitwise_not = _Mock()

bitwise_or = _Mock()

bitwise_xor = _Mock()

blackman = _Mock()

bmat = _Mock()

broadcast_arrays = _Mock()

busday_count = _Mock()

busday_offset = _Mock()

byte_bounds = _Mock()

c_ = _Mock()

can_cast = _Mock()

cast = _Mock()

ceil = _Mock()

char = _Mock()

choose = _Mock()

clip = _Mock()

column_stack = _Mock()

common_type = _Mock()

compare_chararrays = _Mock()

compress = _Mock()

concatenate = _Mock()

conj = _Mock()

conjugate = _Mock()

convolve = _Mock()

copy = _Mock()

copysign = _Mock()

copyto = _Mock()

corrcoef = _Mock()

correlate = _Mock()

cos = _Mock()

cosh = _Mock()

count_nonzero = _Mock()

cov = _Mock()

cross = _Mock()

ctypeslib = _Mock()

cumprod = _Mock()

cumproduct = _Mock()

cumsum = _Mock()

datetime_as_string = _Mock()

datetime_data = _Mock()

deg2rad = _Mock()

degrees = _Mock()

delete = _Mock()

deprecate = _Mock()

deprecate_with_doc = _Mock()

diag = _Mock()

diag_indices = _Mock()

diag_indices_from = _Mock()

diagflat = _Mock()

diagonal = _Mock()

diff = _Mock()

digitize = _Mock()

disp = _Mock()

divide = _Mock()

division = _Mock()

dot = _Mock()

dsplit = _Mock()

dstack = _Mock()

ediff1d = _Mock()

einsum = _Mock()

emath = _Mock()

empty = _Mock()

empty_like = _Mock()

equal = _Mock()

exp = _Mock()

exp2 = _Mock()

expand_dims = _Mock()

expm1 = _Mock()

extract = _Mock()

eye = _Mock()

fabs = _Mock()

fastCopyAndTranspose = _Mock()

fft = _Mock()

fill_diagonal = _Mock()

find_common_type = _Mock()

fix = _Mock()

flatnonzero = _Mock()

fliplr = _Mock()

flipud = _Mock()

floor = _Mock()

floor_divide = _Mock()

fmax = _Mock()

fmin = _Mock()

fmod = _Mock()

frexp = _Mock()

frombuffer = _Mock()

fromfile = _Mock()

fromfunction = _Mock()

fromiter = _Mock()

frompyfunc = _Mock()

fromregex = _Mock()

fromstring = _Mock()

full = _Mock()

full_like = _Mock()

fv = _Mock()

genfromtxt = _Mock()

get_array_wrap = _Mock()

get_include = _Mock()

get_numarray_include = _Mock()

get_printoptions = _Mock()

getbuffer = _Mock()

getbufsize = _Mock()

geterr = _Mock()

geterrcall = _Mock()

geterrobj = _Mock()

gradient = _Mock()

greater = _Mock()

greater_equal = _Mock()

hamming = _Mock()

hanning = _Mock()

histogram = _Mock()

histogram2d = _Mock()

histogramdd = _Mock()

hsplit = _Mock()

hstack = _Mock()

hypot = _Mock()

i0 = _Mock()

identity = _Mock()

imag = _Mock()

in1d = _Mock()

index_exp = _Mock()

indices = _Mock()

info = _Mock()

inner = _Mock()

insert = _Mock()

int_asbuffer = _Mock()

interp = _Mock()

intersect1d = _Mock()

invert = _Mock()

ipmt = _Mock()

irr = _Mock()

is_busday = _Mock()

isclose = _Mock()

iscomplex = _Mock()

iscomplexobj = _Mock()

isfinite = _Mock()

isfortran = _Mock()

isinf = _Mock()

isnan = _Mock()

isneginf = _Mock()

isposinf = _Mock()

isreal = _Mock()

isrealobj = _Mock()

isscalar = _Mock()

issctype = _Mock()

issubclass_ = _Mock()

issubdtype = _Mock()

issubsctype = _Mock()

iterable = _Mock()

ix_ = _Mock()

kaiser = _Mock()

kron = _Mock()

ldexp = _Mock()

left_shift = _Mock()

less = _Mock()

less_equal = _Mock()

lexsort = _Mock()

linalg = _Mock()

linspace = _Mock()

load = _Mock()

loads = _Mock()

loadtxt = _Mock()

log = _Mock()

log10 = _Mock()

log1p = _Mock()

log2 = _Mock()

logaddexp = _Mock()

logaddexp2 = _Mock()

logical_and = _Mock()

logical_not = _Mock()

logical_or = _Mock()

logical_xor = _Mock()

logspace = _Mock()

lookfor = _Mock()

ma = _Mock()

mafromtxt = _Mock()

mask_indices = _Mock()

mat = _Mock()

math = _Mock()

maximum = _Mock()

maximum_sctype = _Mock()

may_share_memory = _Mock()

mean = _Mock()

median = _Mock()

meshgrid = _Mock()

mgrid = _Mock()

min_scalar_type = _Mock()

minimum = _Mock()

mintypecode = _Mock()

mirr = _Mock()

mod = _Mock()

modf = _Mock()

msort = _Mock()

multiply = _Mock()

nan_to_num = _Mock()

nanargmax = _Mock()

nanargmin = _Mock()

nanmax = _Mock()

nanmean = _Mock()

nanmin = _Mock()

nanstd = _Mock()

nansum = _Mock()

nanvar = _Mock()

nbytes = _Mock()

ndfromtxt = _Mock()

ndim = _Mock()

negative = _Mock()

nested_iters = _Mock()

newaxis = _Mock()

newbuffer = _Mock()

nextafter = _Mock()

nonzero = _Mock()

not_equal = _Mock()

np = _Mock()

nper = _Mock()

npv = _Mock()

obj2sctype = _Mock()

ogrid = _Mock()

ones = _Mock()

ones_like = _Mock()

outer = _Mock()

packbits = _Mock()

pad = _Mock()

partition = _Mock()

percentile = _Mock()

piecewise = _Mock()

pkgload = _Mock()

place = _Mock()

pmt = _Mock()

poly = _Mock()

polyadd = _Mock()

polyder = _Mock()

polydiv = _Mock()

polyfit = _Mock()

polyint = _Mock()

polymul = _Mock()

polysub = _Mock()

polyval = _Mock()

power = _Mock()

ppmt = _Mock()

print_function = _Mock()

prod = _Mock()

product = _Mock()

promote_types = _Mock()

ptp = _Mock()

put = _Mock()

putmask = _Mock()

pv = _Mock()

r_ = _Mock()

rad2deg = _Mock()

radians = _Mock()

rand = _Mock()

randn = _Mock()

random = _Mock()

rank = _Mock()

rate = _Mock()

ravel = _Mock()

ravel_multi_index = _Mock()

real = _Mock()

real_if_close = _Mock()

rec = _Mock()

recfromcsv = _Mock()

recfromtxt = _Mock()

reciprocal = _Mock()

remainder = _Mock()

repeat = _Mock()

repmat = _Mock()

require = _Mock()

reshape = _Mock()

resize = _Mock()

restoredot = _Mock()

result_type = _Mock()

right_shift = _Mock()

rint = _Mock()

roll = _Mock()

rollaxis = _Mock()

roots = _Mock()

rot90 = _Mock()

round_ = _Mock()

row_stack = _Mock()

s_ = _Mock()

safe_eval = _Mock()

save = _Mock()

savetxt = _Mock()

savez = _Mock()

savez_compressed = _Mock()

sctype2char = _Mock()

sctypeDict = _Mock()

sctypeNA = _Mock()

sctypes = _Mock()

searchsorted = _Mock()

select = _Mock()

set_numeric_ops = _Mock()

set_printoptions = _Mock()

set_string_function = _Mock()

setbufsize = _Mock()

setdiff1d = _Mock()

seterr = _Mock()

seterrcall = _Mock()

seterrobj = _Mock()

setxor1d = _Mock()

shape = _Mock()

show_config = _Mock()

sign = _Mock()

signbit = _Mock()

sin = _Mock()

sinc = _Mock()

sinh = _Mock()

size = _Mock()

sometrue = _Mock()

sort = _Mock()

sort_complex = _Mock()

source = _Mock()

spacing = _Mock()

split = _Mock()

sqrt = _Mock()

square = _Mock()

squeeze = _Mock()

std = _Mock()

subtract = _Mock()

sum = _Mock()

swapaxes = _Mock()

take = _Mock()

tan = _Mock()

tanh = _Mock()

tensordot = _Mock()

tile = _Mock()

trace = _Mock()

transpose = _Mock()

trapz = _Mock()

tri = _Mock()

tril = _Mock()

tril_indices = _Mock()

tril_indices_from = _Mock()

trim_zeros = _Mock()

triu = _Mock()

triu_indices = _Mock()

triu_indices_from = _Mock()

true_divide = _Mock()

trunc = _Mock()

typeDict = _Mock()

typeNA = _Mock()

typecodes = _Mock()

typename = _Mock()

union1d = _Mock()

unique = _Mock()

unpackbits = _Mock()

unravel_index = _Mock()

unwrap = _Mock()

vander = _Mock()

var = _Mock()

vdot = _Mock()

vsplit = _Mock()

vstack = _Mock()

where = _Mock()

who = _Mock()

zeros = _Mock()

zeros_like = _Mock()

ALLOW_THREADS = 1

BUFSIZE = 8192

CLIP = 0

ERR_CALL = 3

ERR_DEFAULT = 0

ERR_DEFAULT2 = 521

ERR_IGNORE = 0

ERR_LOG = 5

ERR_PRINT = 4

ERR_RAISE = 2

ERR_WARN = 1

FLOATING_POINT_SUPPORT = 1

FPE_DIVIDEBYZERO = 1

FPE_INVALID = 8

FPE_OVERFLOW = 2

FPE_UNDERFLOW = 4

Inf = float('inf')

Infinity = float('inf')

MAXDIMS = 32

NAN = float('nan')

NINF = float('-inf')

NZERO = -0.0

NaN = float('nan')

PINF = float('inf')

PZERO = 0.0

RAISE = 2

SHIFT_DIVIDEBYZERO = 0

SHIFT_INVALID = 9

SHIFT_OVERFLOW = 3

SHIFT_UNDERFLOW = 6

UFUNC_BUFSIZE_DEFAULT = 8192

UFUNC_PYVALS_NAME = 'UFUNC_PYVALS'

WRAP = 1

__version__ = '1.8.2'

e = 2.718281828459045

euler_gamma = 0.5772156649015329

inf = float('inf')

infty = float('inf')

little_endian = _Mock()

nan = float('nan')

pi = 3.141592653589793

class ComplexWarning(_Mock):
  pass


class DataSource(_Mock):
  pass


class MachAr(_Mock):
  pass


class ModuleDeprecationWarning(_Mock):
  pass


class PackageLoader(_Mock):
  pass


class RankWarning(_Mock):
  pass


class bool8(_Mock):
  pass


class bool_(_Mock):
  pass


class broadcast(_Mock):
  pass


class busdaycalendar(_Mock):
  pass


class byte(_Mock):
  pass


class bytes_(_Mock):
  pass


class cdouble(_Mock):
  pass


class cfloat(_Mock):
  pass


class character(_Mock):
  pass


class chararray(_Mock):
  pass


class clongdouble(_Mock):
  pass


class clongfloat(_Mock):
  pass


class complex128(_Mock):
  pass


class complex256(_Mock):
  pass


class complex64(_Mock):
  pass


class complex_(_Mock):
  pass


class complexfloating(_Mock):
  pass


class csingle(_Mock):
  pass


class datetime64(_Mock):
  pass


class double(_Mock):
  pass


class dtype(_Mock):
  pass


class errstate(_Mock):
  pass


class finfo(_Mock):
  pass


class flatiter(_Mock):
  pass


class flexible(_Mock):
  pass


class float128(_Mock):
  pass


class float16(_Mock):
  pass


class float32(_Mock):
  pass


class float64(_Mock):
  pass


class float_(_Mock):
  pass


class floating(_Mock):
  pass


class format_parser(_Mock):
  pass


class generic(_Mock):
  pass


class half(_Mock):
  pass


class iinfo(_Mock):
  pass


class inexact(_Mock):
  pass


class int0(_Mock):
  pass


class int16(_Mock):
  pass


class int32(_Mock):
  pass


class int64(_Mock):
  pass


class int8(_Mock):
  pass


class int_(_Mock):
  pass


class intc(_Mock):
  pass


class integer(_Mock):
  pass


class intp(_Mock):
  pass


class longcomplex(_Mock):
  pass


class longdouble(_Mock):
  pass


class longfloat(_Mock):
  pass


class longlong(_Mock):
  pass


class matrix(_Mock):
  pass


class memmap(_Mock):
  pass


class ndarray(_Mock):
  pass


class ndenumerate(_Mock):
  pass


class ndindex(_Mock):
  pass


class nditer(_Mock):
  pass


class number(_Mock):
  pass


class object0(_Mock):
  pass


class object_(_Mock):
  pass


class poly1d(_Mock):
  pass


class recarray(_Mock):
  pass


class record(_Mock):
  pass


class short(_Mock):
  pass


class signedinteger(_Mock):
  pass


class single(_Mock):
  pass


class singlecomplex(_Mock):
  pass


class str_(_Mock):
  pass


class string0(_Mock):
  pass


class string_(_Mock):
  pass


class timedelta64(_Mock):
  pass


class ubyte(_Mock):
  pass


class ufunc(_Mock):
  pass


class uint(_Mock):
  pass


class uint0(_Mock):
  pass


class uint16(_Mock):
  pass


class uint32(_Mock):
  pass


class uint64(_Mock):
  pass


class uint8(_Mock):
  pass


class uintc(_Mock):
  pass


class uintp(_Mock):
  pass


class ulonglong(_Mock):
  pass


class unicode0(_Mock):
  pass


class unicode_(_Mock):
  pass


class unsignedinteger(_Mock):
  pass


class ushort(_Mock):
  pass


class vectorize(_Mock):
  pass


class void(_Mock):
  pass


class void0(_Mock):
  pass


