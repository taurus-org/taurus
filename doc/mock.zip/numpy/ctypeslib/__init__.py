from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_flagdict = _Mock()

_flagnames = _Mock()

_flags_fromnum = _Mock()

_num_fromflags = _Mock()

_pointer_type_cache = _Mock()

_typecodes = _Mock()

absolute_import = _Mock()

array = _Mock()

as_array = _Mock()

as_ctypes = _Mock()

ct = _Mock()

ctypes = _Mock()

ctypes_load_library = _Mock()

deprecate = _Mock()

division = _Mock()

load_library = _Mock()

ndpointer = _Mock()

os = _Mock()

prep_array = _Mock()

prep_pointer = _Mock()

prep_simple = _Mock()

print_function = _Mock()

simple_types = _Mock()

sys = _Mock()

types = _Mock()

code = 'f'

class _ARRAY_TYPE(_Mock):
  pass


class _dtype(_Mock):
  pass


class _ndptr(_Mock):
  pass
  _type_ = 'P'

class _ndptr_base(_Mock):
  pass
  _type_ = 'P'

class c_intp(_Mock):
  pass
  _type_ = 'l'

class flagsobj(_Mock):
  pass


class integer(_Mock):
  pass


class ndarray(_Mock):
  pass


class tp(_Mock):
  pass
  _type_ = 'd'

