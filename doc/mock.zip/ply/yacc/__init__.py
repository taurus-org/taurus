from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_is_identifier = _Mock()

digraph = _Mock()

format_result = _Mock()

format_stack_entry = _Mock()

func_code = _Mock()

get_caller_module_dict = _Mock()

load_ply_lex = _Mock()

os = _Mock()

parse_grammar = _Mock()

re = _Mock()

rightmost_terminal = _Mock()

sys = _Mock()

traverse = _Mock()

types = _Mock()

yacc = _Mock()

MAXINT = 9223372036854775807

__version__ = '3.4'

debug_file = 'parser.out'

default_lr = 'LALR'

error_count = 3

pickle_protocol = 0

resultlimit = 40

tab_module = 'parsetab'

yaccdebug = 1

yaccdevel = 0

class Grammar(_Mock):
  pass


class GrammarError(_Mock):
  pass


class LALRError(_Mock):
  pass


class LRGeneratedTable(_Mock):
  pass


class LRItem(_Mock):
  pass


class LRParser(_Mock):
  pass


class LRTable(_Mock):
  pass


class MiniProduction(_Mock):
  pass


class NullLogger(_Mock):
  pass


class ParserReflect(_Mock):
  pass


class PlyLogger(_Mock):
  pass


class Production(_Mock):
  pass
  reduced = 0

class VersionError(_Mock):
  pass


class YaccError(_Mock):
  pass


class YaccProduction(_Mock):
  pass


class YaccSymbol(_Mock):
  pass


