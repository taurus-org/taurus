from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


StringTypes = _Mock()

TOKEN = _Mock()

Token = _Mock()

_form_master_re = _Mock()

_funcs_to_names = _Mock()

_is_identifier = _Mock()

_names_to_funcs = _Mock()

_statetoken = _Mock()

copy = _Mock()

func_code = _Mock()

get_caller_module_dict = _Mock()

lex = _Mock()

os = _Mock()

re = _Mock()

runmain = _Mock()

sys = _Mock()

types = _Mock()

__version__ = '3.4'

class LexError(_Mock):
  pass


class LexToken(_Mock):
  pass


class Lexer(_Mock):
  pass


class LexerReflect(_Mock):
  pass


class NullLogger(_Mock):
  pass


class PlyLogger(_Mock):
  pass


