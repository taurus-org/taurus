from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


FMT_GROUPS = _Mock()

collections = _Mock()

is_text_string = _Mock()

print_function = _Mock()

re = _Mock()

sys = _Mock()

to_text_string = _Mock()

unicode_literals = _Mock()

update_dataset = _Mock()

utf8_to_unicode = _Mock()

DEBUG_DESERIALIZE = _Mock()

PY2 = _Mock()

class ActivableDataSet(_Mock):
  pass
  _active = True
  _ro = True

class BeginGroup(_Mock):
  pass
  count = 0

class BeginTabGroup(_Mock):
  pass
  count = 0

class DataItem(_Mock):
  pass
  count = 0

class DataItemProxy(_Mock):
  pass


class DataItemVariable(_Mock):
  pass


class DataSet(_Mock):
  pass


class DataSetGroup(_Mock):
  pass


class DataSetMeta(_Mock):
  pass


class EndGroup(_Mock):
  pass
  count = 0

class EndTabGroup(_Mock):
  pass
  count = 0

class FormatProp(_Mock):
  pass


class FuncProp(_Mock):
  pass


class GetAttrProp(_Mock):
  pass


class GroupItem(_Mock):
  pass


class ItemProperty(_Mock):
  pass


class Meta_Py3Compat(_Mock):
  pass


class NoDefault(_Mock):
  pass


class NotProp(_Mock):
  pass


class Obj(_Mock):
  pass


class ObjectItem(_Mock):
  pass
  count = 0

class TabGroupItem(_Mock):
  pass


class ValueProp(_Mock):
  pass


