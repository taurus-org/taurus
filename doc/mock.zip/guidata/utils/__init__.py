from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_TIMER = _Mock()

add_extension = _Mock()

assert_interface_supported = _Mock()

assert_interfaces_valid = _Mock()

bind = _Mock()

collections = _Mock()

cythonize_all = _Mock()

decode_fs_string = _Mock()

format_hms = _Mock()

get_func_code = _Mock()

get_func_name = _Mock()

get_module_path = _Mock()

get_package_data = _Mock()

get_subpackages = _Mock()

is_module_available = _Mock()

is_program_installed = _Mock()

is_text_string = _Mock()

is_unicode = _Mock()

isodate_to_localtime = _Mock()

locale = _Mock()

localtime_to_isodate = _Mock()

min_equals_max = _Mock()

os = _Mock()

osp = _Mock()

pairs = _Mock()

print_function = _Mock()

restore_dataset = _Mock()

run_program = _Mock()

subprocess = _Mock()

sys = _Mock()

tic = _Mock()

time = _Mock()

to_text_string = _Mock()

toc = _Mock()

trace = _Mock()

unicode_to_stdout = _Mock()

update_dataset = _Mock()

utf8_to_unicode = _Mock()

STDOUT_ENCODING = 'utf-8'

class FormatTime(_Mock):
  pass


class Timer(_Mock):
  pass


