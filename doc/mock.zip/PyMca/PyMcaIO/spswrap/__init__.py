from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


getarrayinfo = _Mock()

getarraylist = _Mock()

getdata = _Mock()

getdatacol = _Mock()

getdatarow = _Mock()

getenv = _Mock()

getkeylist = _Mock()

getspeclist = _Mock()

isupdated = _Mock()

putenv = _Mock()

specrunning = _Mock()

sps = _Mock()

spsdefaultarraylist = _Mock()

spsdefaultoutput = _Mock()

spslock = _Mock()

sys = _Mock()

threading = _Mock()

time = _Mock()

updatecounter = _Mock()

updatedone = _Mock()

CHAR = 6

DOUBLE = 0

FLOAT = 1

IS_ARRAY = 2

IS_IMAGE = 10

IS_MCA = 6

SHORT = 4

STRING = 8

TAG_ARRAY = 2

TAG_FRAMES = 256

TAG_IMAGE = 32

TAG_INFO = 128

TAG_MASK = 15

TAG_MCA = 16

TAG_SCAN = 64

TAG_STATUS = 1

UCHAR = 7

USHORT = 5

class error(_Mock):
  pass


