from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


CONF = _Mock()

DEFAULTS = _Mock()

EDIT_EXT = _Mock()

EDIT_FILETYPES = _Mock()

EXCLUDED_NAMES = _Mock()

EXCLUDE_PATTERNS = _Mock()

IMPORT_EXT = _Mock()

INCLUDE_PATTERNS = _Mock()

MONOSPACE = _Mock()

NAME_FILTERS = _Mock()

SANS_SERIF = _Mock()

SHOW_EXT = _Mock()

VALID_EXT = _Mock()

_ = _Mock()

_create_filter = _Mock()

_get_extensions = _Mock()

_get_filters = _Mock()

codeanalysis = _Mock()

get_filter = _Mock()

get_home_dir = _Mock()

iofuncs = _Mock()

is_ubuntu = _Mock()

os = _Mock()

osp = _Mock()

sys = _Mock()

ALL_FILTER = u'All files (*)'

BIG = 12

CHECK_ALL = _Mock()

CONF_VERSION = '9.0.0'

CTRL = 'Ctrl'

EDIT_FILTERS = u'Python files (*.py *.pyw *.ipy);;Cython/Pyrex files (*.pyx *.pxd *.pxi);;C files (*.c *.h);;C++ files (*.cc *.cpp *.cxx *.h *.hh *.hpp *.hxx);;OpenCL files (*.cl);;Fortran files (*.f *.for *.f77 *.f90 *.f95 *.f2k);;IDL files (*.pro);;MATLAB files (*.m);;Julia files (*.jl);;Patch and diff files (*.patch *.diff *.rej);;Batch files (*.bat *.cmd);;Text files (*.txt);;reStructured Text files (*.txt *.rst);;gettext files (*.po *.pot);;NSIS files (*.nsi *.nsh);;Web page files (*.css *.htm *.html);;XML files (*.xml);;Javascript files (*.js);;Enaml files (*.enaml);;Configuration files (*.properties *.session *.ini *.inf *.reg *.cfg *.desktop);;All files (*)'

MEDIUM = 9

OPEN_FILES_PORT = 21128

SMALL = 9

SUBFOLDER = '.spyder2'

_ext = '.svg'

old_location = u'/home/cpascual/.spyder.ini'

class UserConfig(_Mock):
  pass
  DEFAULT_SECTION_NAME = 'main'

