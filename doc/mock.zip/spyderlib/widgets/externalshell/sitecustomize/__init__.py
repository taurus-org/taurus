from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_get_globals = _Mock()

_print = _Mock()

bdb = _Mock()

builtins = _Mock()

debugfile = _Mock()

evalsc = _Mock()

interaction = _Mock()

loc = _Mock()

locale = _Mock()

monitor = _Mock()

monkeypatch_method = _Mock()

mpl_backend = _Mock()

os = _Mock()

osp = _Mock()

pdb = _Mock()

postcmd = _Mock()

reset = _Mock()

runfile = _Mock()

sitecustomize = _Mock()

sys = _Mock()

user_return = _Mock()

encoding = 'UTF-8'

mpl_ion = ''

pyqt_api = 0

spyderlib_path = '/usr/lib/python2.7/dist-packages'

class SpyderPdb(_Mock):
  pass
  doc_header = 'Documented commands (type help <topic>):'
  doc_leader = ''
  identchars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'
  lastcmd = ''
  misc_header = 'Miscellaneous help topics:'
  nohelp = '*** No help on %s'
  prompt = '(Cmd) '
  ruler = '='
  undoc_header = 'Undocumented commands:'
  use_rawinput = 1

class UserModuleDeleter(_Mock):
  pass


