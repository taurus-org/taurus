from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


PACKET_NOT_RECEIVED = _Mock()

REMOTE_SETTINGS = _Mock()

SUPPORTED_TYPES = _Mock()

_getcdlistdir = _Mock()

_thread = _Mock()

communicate = _Mock()

fix_reference_name = _Mock()

get_conf_path = _Mock()

get_remote_data = _Mock()

get_supported_types = _Mock()

getargtxt = _Mock()

getcwd = _Mock()

getdoc = _Mock()

getobjdir = _Mock()

getsource = _Mock()

is_text_string = _Mock()

isdefined = _Mock()

log_last_error = _Mock()

make_remote_view = _Mock()

module_completion = _Mock()

monitor_copy_global = _Mock()

monitor_del_global = _Mock()

monitor_get_global = _Mock()

monitor_load_globals = _Mock()

monitor_save_globals = _Mock()

monitor_set_global = _Mock()

os = _Mock()

pickle = _Mock()

read_packet = _Mock()

socket = _Mock()

struct = _Mock()

threading = _Mock()

write_packet = _Mock()

DEBUG = 0

DEBUG_MONITOR = _Mock()

LOG_FILENAME = u'/home/cpascual/.spyder2/monitor.log'

PICKLE_HIGHEST_PROTOCOL = 2

class Monitor(_Mock):
  pass
  _Thread__initialized = False

