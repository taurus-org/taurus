from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


DTYPES = _Mock()

Image = _Mock()

SAVED_CONFIG_FILES = _Mock()

STDERR = _Mock()

_ = _Mock()

dis = _Mock()

get_conf_path = _Mock()

get_matlab_value = _Mock()

getcwd = _Mock()

inspect = _Mock()

iofunctions = _Mock()

json = _Mock()

load_array = _Mock()

load_dictionary = _Mock()

load_image = _Mock()

load_json = _Mock()

load_matlab = _Mock()

load_pickle = _Mock()

load_session = _Mock()

np = _Mock()

os = _Mock()

osp = _Mock()

pd = _Mock()

pickle = _Mock()

print_function = _Mock()

reset_session = _Mock()

save_auto = _Mock()

save_dictionary = _Mock()

save_matlab = _Mock()

save_session = _Mock()

shutil = _Mock()

spio = _Mock()

sys = _Mock()

tarfile = _Mock()

to_text_string = _Mock()

warnings = _Mock()

PY2 = _Mock()

_ENDIAN = '<'

class IOFunctions(_Mock):
  pass


class MatlabStruct(_Mock):
  pass


