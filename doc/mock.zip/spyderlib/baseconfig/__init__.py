from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


DEV = _Mock()

EXCLUDED_NAMES = _Mock()

IMG_PATH = _Mock()

INT_TYPES = _Mock()

STDERR = _Mock()

STDOUT = _Mock()

TEST = _Mock()

TEXT_TYPES = _Mock()

_ = _Mock()

_get_debug_env = _Mock()

add_image_path = _Mock()

debug_print = _Mock()

encoding = _Mock()

get_conf_path = _Mock()

get_home_dir = _Mock()

get_image_path = _Mock()

get_module_data_path = _Mock()

get_module_path = _Mock()

get_module_source_path = _Mock()

get_supported_types = _Mock()

get_translation = _Mock()

is_py2exe_or_cx_Freeze = _Mock()

is_text_string = _Mock()

is_unicode = _Mock()

os = _Mock()

osp = _Mock()

print_function = _Mock()

sys = _Mock()

to_text_string = _Mock()

CHECK_ALL = _Mock()

DEBUG = 0

PLUGIN_PATH = '/usr/lib/python2.7/dist-packages/spyderplugins'

PY3 = _Mock()

SCIENTIFIC_STARTUP = '/usr/lib/python2.7/dist-packages/spyderlib/scientific_startup.py'

SUBFOLDER = '.spyder2'

__version__ = '2.3.1'



