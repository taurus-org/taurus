from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


INT_TYPES = _Mock()

NUMERIC_TYPES = _Mock()

TEXT_TYPES = _Mock()

_thread = _Mock()

builtins = _Mock()

cmp = _Mock()

codecs = _Mock()

configparser = _Mock()

get_func_code = _Mock()

get_func_defaults = _Mock()

get_func_name = _Mock()

get_meth_class = _Mock()

get_meth_class_inst = _Mock()

get_meth_func = _Mock()

getcwd = _Mock()

input = _Mock()

io = _Mock()

is_binary_string = _Mock()

is_string = _Mock()

is_text_string = _Mock()

is_unicode = _Mock()

os = _Mock()

pickle = _Mock()

print_function = _Mock()

qbytearray_to_str = _Mock()

str_lower = _Mock()

string = _Mock()

sys = _Mock()

to_binary_string = _Mock()

to_text_string = _Mock()

u = _Mock()

PY2 = _Mock()

PY3 = _Mock()

maxsize = 9223372036854775807

class MutableMapping(_Mock):
  pass


class zip_longest(_Mock):
  pass


