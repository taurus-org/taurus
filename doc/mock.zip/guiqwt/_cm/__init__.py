from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_Accent_data = _Mock()

_Blues_data = _Mock()

_BrBG_data = _Mock()

_BuGn_data = _Mock()

_BuPu_data = _Mock()

_Dark2_data = _Mock()

_GnBu_data = _Mock()

_Greens_data = _Mock()

_Greys_data = _Mock()

_OrRd_data = _Mock()

_Oranges_data = _Mock()

_PRGn_data = _Mock()

_Paired_data = _Mock()

_Pastel1_data = _Mock()

_Pastel2_data = _Mock()

_PiYG_data = _Mock()

_PuBuGn_data = _Mock()

_PuBu_data = _Mock()

_PuOr_data = _Mock()

_PuRd_data = _Mock()

_Purples_data = _Mock()

_RdBu_data = _Mock()

_RdGy_data = _Mock()

_RdPu_data = _Mock()

_RdYlBu_data = _Mock()

_RdYlGn_data = _Mock()

_Reds_data = _Mock()

_Set1_data = _Mock()

_Set2_data = _Mock()

_Set3_data = _Mock()

_Spectral_data = _Mock()

_YlGnBu_data = _Mock()

_YlGn_data = _Mock()

_YlOrBr_data = _Mock()

_YlOrRd_data = _Mock()

_autumn_data = _Mock()

_binary_data = _Mock()

_bone_data = _Mock()

_cool_data = _Mock()

_copper_data = _Mock()

_flag_data = _Mock()

_gist_earth_data = _Mock()

_gist_gray_data = _Mock()

_gist_heat_data = _Mock()

_gist_ncar_data = _Mock()

_gist_rainbow_data = _Mock()

_gist_stern_data = _Mock()

_gist_yarg_data = _Mock()

_gray_data = _Mock()

_hot_data = _Mock()

_hsv_data = _Mock()

_jet_data = _Mock()

_pink_data = _Mock()

_prism_data = _Mock()

_spectral_data = _Mock()

_spring_data = _Mock()

_summer_data = _Mock()

_winter_data = _Mock()

datad = _Mock()





