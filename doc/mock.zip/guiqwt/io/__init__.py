from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


DTYPES = _Mock()

ITEM_MODULES = _Mock()

SERIALIZABLE_ITEMS = _Mock()

_ = _Mock()

_import_dcm = _Mock()

_imread_dcm = _Mock()

_imread_pil = _Mock()

_imread_txt = _Mock()

_imwrite_dcm = _Mock()

_imwrite_pil = _Mock()

_imwrite_txt = _Mock()

array_to_imagefile = _Mock()

eliminate_outliers = _Mock()

imagefile_to_array = _Mock()

imread = _Mock()

imwrite = _Mock()

iohandler = _Mock()

is_text_string = _Mock()

item_class_from_name = _Mock()

item_name_from_object = _Mock()

load_item = _Mock()

load_items = _Mock()

np = _Mock()

osp = _Mock()

print_function = _Mock()

re = _Mock()

register_serializable_items = _Mock()

save_item = _Mock()

save_items = _Mock()

scale_data_to_dtype = _Mock()

sys = _Mock()

to_text_string = _Mock()

_ENDIAN = '<'

class FileType(_Mock):
  pass


class ImageIOHandler(_Mock):
  pass


