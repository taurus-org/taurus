from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


build_items = _Mock()

make = _Mock()

np = _Mock()

os = _Mock()

osp = _Mock()

print_function = _Mock()

SHOW = _Mock()

class Axes(_Mock):
  pass
  ADDITIONNAL_POINTS = 0
  AutoScale = 2
  CLOSED = True
  LINK_ADDITIONNAL_POINTS = False
  Legend = 1
  RenderAntialiased = 1
  Rtti_PlotCurve = 4
  Rtti_PlotGrid = 1
  Rtti_PlotHistogram = 5
  Rtti_PlotItem = 0
  Rtti_PlotMarker = 3
  Rtti_PlotSVG = 7
  Rtti_PlotScale = 2
  Rtti_PlotSpectrogram = 6
  Rtti_PlotUserItem = 1000
  _can_move = True
  _can_resize = True
  _can_rotate = False
  _can_select = True
  _private = False
  _readonly = False

class IOTest(_Mock):
  pass


class ImageDialog(_Mock):
  pass
  Accepted = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Rejected = 0

class ImageMaskTool(_Mock):
  pass


class LoadItemsTool(_Mock):
  pass


class PickleTest(_Mock):
  pass
  FNAME = 'loadsavecanvas.pickle'

class PolygonShape(_Mock):
  pass
  ADDITIONNAL_POINTS = 0
  AutoScale = 2
  CLOSED = True
  LINK_ADDITIONNAL_POINTS = False
  Legend = 1
  RenderAntialiased = 1
  Rtti_PlotCurve = 4
  Rtti_PlotGrid = 1
  Rtti_PlotHistogram = 5
  Rtti_PlotItem = 0
  Rtti_PlotMarker = 3
  Rtti_PlotSVG = 7
  Rtti_PlotScale = 2
  Rtti_PlotSpectrogram = 6
  Rtti_PlotUserItem = 1000
  _can_move = True
  _can_resize = True
  _can_rotate = False
  _can_select = True
  _private = False
  _readonly = False

class QFont(_Mock):
  pass
  AbsoluteSpacing = 1
  AllLowercase = 2
  AllUppercase = 1
  AnyStyle = 5
  Black = 87
  Bold = 75
  Capitalize = 4
  Condensed = 75
  Courier = 2
  Cursive = 6
  Decorative = 3
  DemiBold = 63
  Expanded = 125
  ExtraCondensed = 62
  ExtraExpanded = 150
  Fantasy = 8
  ForceIntegerMetrics = 1024
  ForceOutline = 16
  Helvetica = 0
  Light = 25
  MixedCase = 0
  Monospace = 7
  NoAntialias = 256
  NoFontMerging = 32768
  Normal = 50
  OldEnglish = 3
  OpenGLCompatible = 512
  PercentageSpacing = 0
  PreferAntialias = 128
  PreferBitmap = 2
  PreferDefault = 1
  PreferDefaultHinting = 0
  PreferDevice = 4
  PreferFullHinting = 3
  PreferMatch = 32
  PreferNoHinting = 1
  PreferOutline = 8
  PreferQuality = 64
  PreferVerticalHinting = 2
  SansSerif = 0
  SemiCondensed = 87
  SemiExpanded = 112
  Serif = 1
  SmallCaps = 3
  StyleItalic = 1
  StyleNormal = 0
  StyleOblique = 2
  System = 4
  Times = 1
  TypeWriter = 2
  UltraCondensed = 50
  UltraExpanded = 200
  Unstretched = 100

class SaveItemsTool(_Mock):
  pass


