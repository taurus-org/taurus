from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


create_window = _Mock()

make = _Mock()

osp = _Mock()

test = _Mock()

SHOW = _Mock()

class AnnotatedCircleTool(_Mock):
  pass
  AVOID_NULL_SHAPE = False
  CURSOR = 2
  ICON = u'circle.png'
  SHAPE_STYLE_KEY = u'shape/drag'
  SHAPE_STYLE_SECT = u'plot'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Circle'

class AnnotatedEllipseTool(_Mock):
  pass
  AVOID_NULL_SHAPE = False
  CURSOR = 2
  ICON = u'ellipse_shape.png'
  SHAPE_STYLE_KEY = u'shape/drag'
  SHAPE_STYLE_SECT = u'plot'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Ellipse'

class AnnotatedObliqueRectangleTool(_Mock):
  pass
  AVOID_NULL_SHAPE = True
  CURSOR = 2
  ICON = u'oblique_rectangle.png'
  SHAPE_STYLE_KEY = u'shape/drag'
  SHAPE_STYLE_SECT = u'plot'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Oblique rectangle'

class AnnotatedPointTool(_Mock):
  pass
  AVOID_NULL_SHAPE = False
  CURSOR = 2
  ICON = u'point_shape.png'
  SHAPE_STYLE_KEY = u'shape/point'
  SHAPE_STYLE_SECT = u'plot'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Point'

class AnnotatedRectangleTool(_Mock):
  pass
  AVOID_NULL_SHAPE = False
  CURSOR = 2
  ICON = u'rectangle.png'
  SHAPE_STYLE_KEY = u'shape/drag'
  SHAPE_STYLE_SECT = u'plot'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Rectangle'

class AnnotatedSegmentTool(_Mock):
  pass
  AVOID_NULL_SHAPE = False
  CURSOR = 2
  ICON = u'segment.png'
  SHAPE_STYLE_KEY = u'shape/segment'
  SHAPE_STYLE_SECT = u'plot'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Segment'

class CircleTool(_Mock):
  pass
  AVOID_NULL_SHAPE = False
  CURSOR = 2
  ICON = u'circle.png'
  SHAPE_STYLE_KEY = u'shape/drag'
  SHAPE_STYLE_SECT = u'plot'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Circle'

class EllipseTool(_Mock):
  pass
  AVOID_NULL_SHAPE = False
  CURSOR = 2
  ICON = u'ellipse_shape.png'
  SHAPE_STYLE_KEY = u'shape/drag'
  SHAPE_STYLE_SECT = u'plot'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Ellipse'

class FreeFormTool(_Mock):
  pass
  CURSOR = 0
  ICON = u'freeform.png'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Free form'

class HCursorTool(_Mock):
  pass
  CURSOR = 2
  ICON = u'hcursor.png'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Horizontal cursor'

class HRangeTool(_Mock):
  pass
  CURSOR = 2
  ICON = u'xrange.png'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Horizontal selection'

class ImageDialog(_Mock):
  pass
  Accepted = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Rejected = 0

class LabelTool(_Mock):
  pass
  CURSOR = 2
  ICON = u'label.png'
  LABEL_STYLE_KEY = u'label'
  LABEL_STYLE_SECT = u'plot'
  SWITCH_TO_DEFAULT_TOOL = True
  TITLE = u'Label'

class MultiLineTool(_Mock):
  pass
  CURSOR = 0
  ICON = u'polyline.png'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Polyline'

class ObliqueRectangleTool(_Mock):
  pass
  AVOID_NULL_SHAPE = True
  CURSOR = 2
  ICON = u'oblique_rectangle.png'
  SHAPE_STYLE_KEY = u'shape/drag'
  SHAPE_STYLE_SECT = u'plot'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Oblique rectangle'

class PlaceAxesTool(_Mock):
  pass
  AVOID_NULL_SHAPE = False
  CURSOR = 2
  ICON = u'gtaxes.png'
  SHAPE_STYLE_KEY = u'shape/axes'
  SHAPE_STYLE_SECT = u'plot'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Axes'

class RectangleTool(_Mock):
  pass
  AVOID_NULL_SHAPE = False
  CURSOR = 2
  ICON = u'rectangle.png'
  SHAPE_STYLE_KEY = u'shape/drag'
  SHAPE_STYLE_SECT = u'plot'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Rectangle'

class SegmentTool(_Mock):
  pass
  AVOID_NULL_SHAPE = False
  CURSOR = 2
  ICON = u'segment.png'
  SHAPE_STYLE_KEY = u'shape/segment'
  SHAPE_STYLE_SECT = u'plot'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Segment'

class VCursorTool(_Mock):
  pass
  CURSOR = 2
  ICON = u'vcursor.png'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Vertical cursor'

class XCursorTool(_Mock):
  pass
  CURSOR = 2
  ICON = u'xcursor.png'
  SWITCH_TO_DEFAULT_TOOL = False
  TITLE = u'Cross cursor'

