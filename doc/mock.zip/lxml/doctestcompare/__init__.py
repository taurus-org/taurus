from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_find_doctest_frame = _Mock()

_html_parser = _Mock()

_norm_whitespace_re = _Mock()

_repr_re = _Mock()

cgi = _Mock()

doctest = _Mock()

etree = _Mock()

html_fromstring = _Mock()

install = _Mock()

norm_whitespace = _Mock()

re = _Mock()

strip = _Mock()

sys = _Mock()

temp_install = _Mock()

NOPARSE_MARKUP = 4096

PARSE_HTML = 1024

PARSE_XML = 2048

_IS_PYTHON_3 = _Mock()

class LHTMLOutputChecker(_Mock):
  pass


class LXMLOutputChecker(_Mock):
  pass


class OutputChecker(_Mock):
  pass


class _RestoreChecker(_Mock):
  pass


class _basestring(_Mock):
  pass


