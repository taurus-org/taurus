from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


_body_re = _Mock()

_contains_block_level_tag = _Mock()

_end_body_re = _Mock()

_fixup_ins_del_tags = _Mock()

_ins_del_re = _Mock()

_merge_element_contents = _Mock()

_move_el_inside_block = _Mock()

block_level_container_tags = _Mock()

block_level_tags = _Mock()

cleanup_delete = _Mock()

cleanup_html = _Mock()

compress_merge_back = _Mock()

compress_tokens = _Mock()

copy_annotations = _Mock()

default_markup = _Mock()

difflib = _Mock()

empty_tags = _Mock()

end_tag = _Mock()

end_whitespace_re = _Mock()

etree = _Mock()

expand_tokens = _Mock()

fixup_chunks = _Mock()

fixup_ins_del_tags = _Mock()

flatten_el = _Mock()

fragment_fromstring = _Mock()

html_annotate = _Mock()

html_annotate_merge_annotations = _Mock()

html_escape = _Mock()

htmldiff = _Mock()

htmldiff_tokens = _Mock()

is_end_tag = _Mock()

is_start_tag = _Mock()

is_word = _Mock()

locate_unbalanced_end = _Mock()

locate_unbalanced_start = _Mock()

markup_serialize_tokens = _Mock()

merge_delete = _Mock()

merge_insert = _Mock()

parse_html = _Mock()

re = _Mock()

serialize_html_fragment = _Mock()

split_delete = _Mock()

split_trailing_whitespace = _Mock()

split_unbalanced = _Mock()

split_words = _Mock()

split_words_re = _Mock()

start_tag = _Mock()

start_whitespace_re = _Mock()

tokenize = _Mock()

tokenize_annotated = _Mock()



class DEL_END(_Mock):
  pass


class DEL_START(_Mock):
  pass


class InsensitiveSequenceMatcher(_Mock):
  pass
  threshold = 2

class NoDeletes(_Mock):
  pass


class _unicode(_Mock):
  pass


class href_token(_Mock):
  pass
  hide_when_equal = True

class tag_token(_Mock):
  pass
  hide_when_equal = False

class token(_Mock):
  pass
  hide_when_equal = False

