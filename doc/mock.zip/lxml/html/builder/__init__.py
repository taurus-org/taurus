from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


A = _Mock()

ABBR = _Mock()

ACRONYM = _Mock()

ADDRESS = _Mock()

APPLET = _Mock()

AREA = _Mock()

B = _Mock()

BASE = _Mock()

BASEFONT = _Mock()

BDO = _Mock()

BIG = _Mock()

BLOCKQUOTE = _Mock()

BODY = _Mock()

BR = _Mock()

BUTTON = _Mock()

CAPTION = _Mock()

CENTER = _Mock()

CITE = _Mock()

CLASS = _Mock()

CODE = _Mock()

COL = _Mock()

COLGROUP = _Mock()

DD = _Mock()

DEL = _Mock()

DFN = _Mock()

DIR = _Mock()

DIV = _Mock()

DL = _Mock()

DT = _Mock()

E = _Mock()

EM = _Mock()

FIELDSET = _Mock()

FONT = _Mock()

FOR = _Mock()

FORM = _Mock()

FRAME = _Mock()

FRAMESET = _Mock()

H1 = _Mock()

H2 = _Mock()

H3 = _Mock()

H4 = _Mock()

H5 = _Mock()

H6 = _Mock()

HEAD = _Mock()

HR = _Mock()

HTML = _Mock()

I = _Mock()

IFRAME = _Mock()

IMG = _Mock()

INPUT = _Mock()

INS = _Mock()

ISINDEX = _Mock()

KBD = _Mock()

LABEL = _Mock()

LEGEND = _Mock()

LI = _Mock()

LINK = _Mock()

MAP = _Mock()

MENU = _Mock()

META = _Mock()

NOFRAMES = _Mock()

NOSCRIPT = _Mock()

OBJECT = _Mock()

OL = _Mock()

OPTGROUP = _Mock()

OPTION = _Mock()

P = _Mock()

PARAM = _Mock()

PRE = _Mock()

Q = _Mock()

S = _Mock()

SAMP = _Mock()

SCRIPT = _Mock()

SELECT = _Mock()

SMALL = _Mock()

SPAN = _Mock()

STRIKE = _Mock()

STRONG = _Mock()

STYLE = _Mock()

SUB = _Mock()

SUP = _Mock()

TABLE = _Mock()

TBODY = _Mock()

TD = _Mock()

TEXTAREA = _Mock()

TFOOT = _Mock()

TH = _Mock()

THEAD = _Mock()

TITLE = _Mock()

TR = _Mock()

TT = _Mock()

U = _Mock()

UL = _Mock()

VAR = _Mock()

html_parser = _Mock()



class ATTR(_Mock):
  pass


class ElementMaker(_Mock):
  pass


