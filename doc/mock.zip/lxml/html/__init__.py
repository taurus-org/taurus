from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


Element = _Mock()

_archive_re = _Mock()

_class_xpath = _Mock()

_collect_string_content = _Mock()

_contains_block_level_tag = _Mock()

_element_name = _Mock()

_forms_xpath = _Mock()

_id_xpath = _Mock()

_iter_css_imports = _Mock()

_iter_css_urls = _Mock()

_label_xpath = _Mock()

_looks_like_full_html_bytes = _Mock()

_looks_like_full_html_unicode = _Mock()

_nons = _Mock()

_options_xpath = _Mock()

_rel_links_xpath = _Mock()

_setmixin = _Mock()

_transform_result = _Mock()

_unquote_match = _Mock()

copy = _Mock()

defs = _Mock()

document_fromstring = _Mock()

etree = _Mock()

find_class = _Mock()

find_rel_links = _Mock()

fragment_fromstring = _Mock()

fragments_fromstring = _Mock()

fromstring = _Mock()

html_parser = _Mock()

html_to_xhtml = _Mock()

iterlinks = _Mock()

make_links_absolute = _Mock()

open_http_urllib = _Mock()

open_in_browser = _Mock()

parse = _Mock()

re = _Mock()

resolve_base_href = _Mock()

rewrite_links = _Mock()

submit_form = _Mock()

sys = _Mock()

tostring = _Mock()

urljoin = _Mock()

xhtml_parser = _Mock()

xhtml_to_html = _Mock()

XHTML_NAMESPACE = 'http://www.w3.org/1999/xhtml'

class CheckboxGroup(_Mock):
  pass


class CheckboxValues(_Mock):
  pass


class DictMixin(_Mock):
  pass
  _abc_negative_cache_version = 29

class FieldsDict(_Mock):
  pass
  _abc_negative_cache_version = 29

class FormElement(_Mock):
  pass


class HTMLParser(_Mock):
  pass


class HtmlComment(_Mock):
  pass


class HtmlElement(_Mock):
  pass


class HtmlElementClassLookup(_Mock):
  pass


class HtmlEntity(_Mock):
  pass


class HtmlMixin(_Mock):
  pass


class HtmlProcessingInstruction(_Mock):
  pass


class InputElement(_Mock):
  pass


class InputGetter(_Mock):
  pass


class InputMixin(_Mock):
  pass


class LabelElement(_Mock):
  pass


class MultipleSelectOptions(_Mock):
  pass


class RadioGroup(_Mock):
  pass


class SelectElement(_Mock):
  pass


class SetMixin(_Mock):
  pass


class TextareaElement(_Mock):
  pass


class XHTMLParser(_Mock):
  pass


class _MethodFunc(_Mock):
  pass


