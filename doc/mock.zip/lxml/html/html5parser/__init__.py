from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


Element = _Mock()

_contains_block_level_tag = _Mock()

_find_tag = _Mock()

_looks_like_url = _Mock()

document_fromstring = _Mock()

etree = _Mock()

fragment_fromstring = _Mock()

fragments_fromstring = _Mock()

fromstring = _Mock()

html_parser = _Mock()

parse = _Mock()

string = _Mock()

sys = _Mock()

urlopen = _Mock()

urlparse = _Mock()

XHTML_NAMESPACE = 'http://www.w3.org/1999/xhtml'

class HTMLParser(_Mock):
  pass


class TreeBuilder(_Mock):
  pass


class _HTMLParser(_Mock):
  pass


class _strings(_Mock):
  pass


