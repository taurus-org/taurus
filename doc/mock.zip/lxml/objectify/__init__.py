from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


DataElement = _Mock()

E = _Mock()

Element = _Mock()

SubElement = _Mock()

XML = _Mock()

annotate = _Mock()

deannotate = _Mock()

dump = _Mock()

enable_recursive_str = _Mock()

fromstring = _Mock()

getRegisteredTypes = _Mock()

makeparser = _Mock()

parse = _Mock()

pyannotate = _Mock()

pytypename = _Mock()

set_default_parser = _Mock()

set_pytype_attribute_tag = _Mock()

xsiannotate = _Mock()

PYTYPE_ATTRIBUTE = '{http://codespeak.net/lxml/objectify/pytype}pytype'

__version__ = u'3.4.0'

class BoolElement(_Mock):
  pass


class ElementMaker(_Mock):
  pass


class FloatElement(_Mock):
  pass


class IntElement(_Mock):
  pass


class LongElement(_Mock):
  pass


class NoneElement(_Mock):
  pass


class NumberElement(_Mock):
  pass


class ObjectPath(_Mock):
  pass


class ObjectifiedDataElement(_Mock):
  pass


class ObjectifiedElement(_Mock):
  pass


class ObjectifyElementClassLookup(_Mock):
  pass


class PyType(_Mock):
  pass


class StringElement(_Mock):
  pass


