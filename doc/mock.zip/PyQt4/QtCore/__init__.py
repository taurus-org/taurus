from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


PYQT_CONFIGURATION = _Mock()

QT_TRANSLATE_NOOP = _Mock()

QT_TR_NOOP = _Mock()

QT_TR_NOOP_UTF8 = _Mock()

Q_ARG = _Mock()

Q_CLASSINFO = _Mock()

Q_ENUMS = _Mock()

Q_FLAGS = _Mock()

Q_RETURN_ARG = _Mock()

SIGNAL = _Mock()

SLOT = _Mock()

Slot = _Mock()

bin = _Mock()

bom = _Mock()

center = _Mock()

dec = _Mock()

endl = _Mock()

fixed = _Mock()

flush = _Mock()

forcepoint = _Mock()

forcesign = _Mock()

hex = _Mock()

left = _Mock()

lowercasebase = _Mock()

lowercasedigits = _Mock()

noforcepoint = _Mock()

noforcesign = _Mock()

noshowbase = _Mock()

oct = _Mock()

pyqtPickleProtocol = _Mock()

pyqtRemoveInputHook = _Mock()

pyqtRestoreInputHook = _Mock()

pyqtSetPickleProtocol = _Mock()

pyqtSignature = _Mock()

pyqtSlot = _Mock()

qAbs = _Mock()

qAddPostRoutine = _Mock()

qChecksum = _Mock()

qCompress = _Mock()

qCritical = _Mock()

qDebug = _Mock()

qErrnoWarning = _Mock()

qFatal = _Mock()

qFuzzyCompare = _Mock()

qInf = _Mock()

qInstallMsgHandler = _Mock()

qIsFinite = _Mock()

qIsInf = _Mock()

qIsNaN = _Mock()

qIsNull = _Mock()

qQNaN = _Mock()

qRegisterResourceData = _Mock()

qRemovePostRoutine = _Mock()

qRound = _Mock()

qRound64 = _Mock()

qSNaN = _Mock()

qSetFieldWidth = _Mock()

qSetPadChar = _Mock()

qSetRealNumberPrecision = _Mock()

qSharedBuild = _Mock()

qSwap = _Mock()

qUncompress = _Mock()

qUnregisterResourceData = _Mock()

qVersion = _Mock()

qWarning = _Mock()

qrand = _Mock()

qsrand = _Mock()

reset = _Mock()

right = _Mock()

scientific = _Mock()

showbase = _Mock()

uppercasebase = _Mock()

uppercasedigits = _Mock()

ws = _Mock()

PYQT_VERSION = 264962

PYQT_VERSION_STR = '4.11.2'

QT_VERSION = 264198

QT_VERSION_STR = '4.8.6'

QtCriticalMsg = 2

QtDebugMsg = 0

QtFatalMsg = 3

QtSystemMsg = 2

QtWarningMsg = 1

class Property(_Mock):
  pass


class QAbstractAnimation(_Mock):
  pass
  Backward = 1
  DeleteWhenStopped = 1
  Forward = 0
  KeepWhenStopped = 0
  Paused = 1
  Running = 2
  Stopped = 0

class QAbstractEventDispatcher(_Mock):
  pass


class QAbstractFileEngine(_Mock):
  pass
  AbsoluteName = 3
  AbsolutePathName = 4
  AccessTime = 2
  BaseName = 1
  BundleName = 8
  BundleType = 524288
  CanonicalName = 6
  CanonicalPathName = 7
  CreationTime = 0
  DefaultName = 0
  DirectoryType = 262144
  ExeGroupPerm = 16
  ExeOtherPerm = 1
  ExeOwnerPerm = 4096
  ExeUserPerm = 256
  ExistsFlag = 4194304
  FileInfoAll = 268435455
  FileType = 131072
  FlagsMask = 267386880
  HiddenFlag = 1048576
  LinkName = 5
  LinkType = 65536
  LocalDiskFlag = 2097152
  ModificationTime = 1
  OwnerGroup = 1
  OwnerUser = 0
  PathName = 2
  PermsMask = 65535
  ReadGroupPerm = 64
  ReadOtherPerm = 4
  ReadOwnerPerm = 16384
  ReadUserPerm = 1024
  Refresh = 16777216
  RootFlag = 8388608
  TypesMask = 983040
  WriteGroupPerm = 32
  WriteOtherPerm = 2
  WriteOwnerPerm = 8192
  WriteUserPerm = 512

class QAbstractFileEngineHandler(_Mock):
  pass


class QAbstractFileEngineIterator(_Mock):
  pass


class QAbstractItemModel(_Mock):
  pass


class QAbstractListModel(_Mock):
  pass


class QAbstractState(_Mock):
  pass


class QAbstractTableModel(_Mock):
  pass


class QAbstractTransition(_Mock):
  pass


class QAnimationGroup(_Mock):
  pass
  Backward = 1
  DeleteWhenStopped = 1
  Forward = 0
  KeepWhenStopped = 0
  Paused = 1
  Running = 2
  Stopped = 0

class QBasicTimer(_Mock):
  pass


class QBitArray(_Mock):
  pass


class QBuffer(_Mock):
  pass
  Append = 4
  NotOpen = 0
  ReadOnly = 1
  ReadWrite = 3
  Text = 16
  Truncate = 8
  Unbuffered = 32
  WriteOnly = 2

class QByteArray(_Mock):
  pass


class QByteArrayMatcher(_Mock):
  pass


class QChar(_Mock):
  pass
  ByteOrderMark = 65279
  ByteOrderSwapped = 65534
  Canonical = 1
  Center = 3
  Circle = 8
  Combining_Above = 230
  Combining_AboveAttached = 214
  Combining_AboveLeft = 228
  Combining_AboveLeftAttached = 212
  Combining_AboveRight = 232
  Combining_AboveRightAttached = 216
  Combining_Below = 220
  Combining_BelowAttached = 202
  Combining_BelowLeft = 218
  Combining_BelowLeftAttached = 200
  Combining_BelowRight = 222
  Combining_BelowRightAttached = 204
  Combining_DoubleAbove = 234
  Combining_DoubleBelow = 233
  Combining_IotaSubscript = 240
  Combining_Left = 224
  Combining_LeftAttached = 208
  Combining_Right = 226
  Combining_RightAttached = 210
  Compat = 16
  DirAL = 13
  DirAN = 5
  DirB = 7
  DirBN = 18
  DirCS = 6
  DirEN = 2
  DirES = 3
  DirET = 4
  DirL = 0
  DirLRE = 11
  DirLRO = 12
  DirNSM = 17
  DirON = 10
  DirPDF = 16
  DirR = 1
  DirRLE = 14
  DirRLO = 15
  DirS = 8
  DirWS = 9
  Dual = 1
  Final = 6
  Font = 2
  Fraction = 17
  Initial = 4
  Isolated = 7
  Letter_Lowercase = 16
  Letter_Modifier = 18
  Letter_Other = 19
  Letter_Titlecase = 17
  Letter_Uppercase = 15
  LineSeparator = 8232
  Mark_Enclosing = 3
  Mark_NonSpacing = 1
  Mark_SpacingCombining = 2
  Medial = 5
  Narrow = 13
  Nbsp = 160
  NoBreak = 3
  NoCategory = 0
  NoDecomposition = 0
  Null = 0
  Number_DecimalDigit = 4
  Number_Letter = 5
  Number_Other = 6
  ObjectReplacementCharacter = 65532
  OtherJoining = 0
  Other_Control = 10
  Other_Format = 11
  Other_NotAssigned = 14
  Other_PrivateUse = 13
  Other_Surrogate = 12
  ParagraphSeparator = 8233
  Punctuation_Close = 23
  Punctuation_Connector = 20
  Punctuation_Dash = 21
  Punctuation_Dask = 21
  Punctuation_FinalQuote = 25
  Punctuation_InitialQuote = 24
  Punctuation_Open = 22
  Punctuation_Other = 26
  ReplacementCharacter = 65533
  Right = 2
  Separator_Line = 8
  Separator_Paragraph = 9
  Separator_Space = 7
  Small = 14
  Square = 15
  Sub = 10
  Super = 9
  Symbol_Currency = 28
  Symbol_Math = 27
  Symbol_Modifier = 29
  Symbol_Other = 30
  Unicode_1_1 = 1
  Unicode_2_0 = 2
  Unicode_2_1_2 = 3
  Unicode_3_0 = 4
  Unicode_3_1 = 5
  Unicode_3_2 = 6
  Unicode_4_0 = 7
  Unicode_4_1 = 8
  Unicode_5_0 = 9
  Unicode_Unassigned = 0
  Vertical = 11
  Wide = 12

class QChildEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QCoreApplication(_Mock):
  pass
  CodecForTr = 0
  DefaultCodec = 0
  UnicodeUTF8 = 1

class QCryptographicHash(_Mock):
  pass
  Md4 = 0
  Md5 = 1
  Sha1 = 2

class QDataStream(_Mock):
  pass
  BigEndian = 0
  DoublePrecision = 1
  LittleEndian = 1
  Ok = 0
  Qt_1_0 = 1
  Qt_2_0 = 2
  Qt_2_1 = 3
  Qt_3_0 = 4
  Qt_3_1 = 5
  Qt_3_3 = 6
  Qt_4_0 = 7
  Qt_4_1 = 7
  Qt_4_2 = 8
  Qt_4_3 = 9
  Qt_4_4 = 10
  Qt_4_5 = 11
  Qt_4_6 = 12
  Qt_4_7 = 12
  Qt_4_8 = 12
  ReadCorruptData = 2
  ReadPastEnd = 1
  SinglePrecision = 0
  WriteFailed = 3

class QDate(_Mock):
  pass
  DateFormat = 0
  StandaloneFormat = 1

class QDateTime(_Mock):
  pass


class QDir(_Mock):
  pass
  AccessMask = 1008
  AllDirs = 1024
  AllEntries = 7
  CaseSensitive = 2048
  Dirs = 1
  DirsFirst = 4
  DirsLast = 32
  Drives = 4
  Executable = 64
  Files = 2
  Hidden = 256
  IgnoreCase = 16
  LocaleAware = 64
  Modified = 128
  Name = 0
  NoDot = 8192
  NoDotAndDotDot = 4096
  NoDotDot = 16384
  NoFilter = -1
  NoSort = -1
  NoSymLinks = 8
  PermissionMask = 112
  Readable = 16
  Reversed = 8
  Size = 2
  SortByMask = 3
  System = 512
  Time = 1
  Type = 128
  TypeMask = 15
  Unsorted = 3
  Writable = 32

class QDirIterator(_Mock):
  pass
  FollowSymlinks = 1
  NoIteratorFlags = 0
  Subdirectories = 2

class QDynamicPropertyChangeEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QEasingCurve(_Mock):
  pass
  CosineCurve = 44
  Custom = 45
  InBack = 33
  InBounce = 37
  InCirc = 25
  InCubic = 5
  InCurve = 41
  InElastic = 29
  InExpo = 21
  InOutBack = 35
  InOutBounce = 39
  InOutCirc = 27
  InOutCubic = 7
  InOutElastic = 31
  InOutExpo = 23
  InOutQuad = 3
  InOutQuart = 11
  InOutQuint = 15
  InOutSine = 19
  InQuad = 1
  InQuart = 9
  InQuint = 13
  InSine = 17
  Linear = 0
  OutBack = 34
  OutBounce = 38
  OutCirc = 26
  OutCubic = 6
  OutCurve = 42
  OutElastic = 30
  OutExpo = 22
  OutInBack = 36
  OutInBounce = 40
  OutInCirc = 28
  OutInCubic = 8
  OutInElastic = 32
  OutInExpo = 24
  OutInQuad = 4
  OutInQuart = 12
  OutInQuint = 16
  OutInSine = 20
  OutQuad = 2
  OutQuart = 10
  OutQuint = 14
  OutSine = 18
  SineCurve = 43

class QElapsedTimer(_Mock):
  pass
  MachAbsoluteTime = 3
  MonotonicClock = 1
  PerformanceCounter = 4
  SystemTime = 0
  TickCounter = 2

class QEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QEventLoop(_Mock):
  pass
  AllEvents = 0
  DeferredDeletion = 16
  ExcludeSocketNotifiers = 2
  ExcludeUserInputEvents = 1
  WaitForMoreEvents = 4
  X11ExcludeTimers = 8

class QEventTransition(_Mock):
  pass


class QFSFileEngine(_Mock):
  pass
  AbsoluteName = 3
  AbsolutePathName = 4
  AccessTime = 2
  BaseName = 1
  BundleName = 8
  BundleType = 524288
  CanonicalName = 6
  CanonicalPathName = 7
  CreationTime = 0
  DefaultName = 0
  DirectoryType = 262144
  ExeGroupPerm = 16
  ExeOtherPerm = 1
  ExeOwnerPerm = 4096
  ExeUserPerm = 256
  ExistsFlag = 4194304
  FileInfoAll = 268435455
  FileType = 131072
  FlagsMask = 267386880
  HiddenFlag = 1048576
  LinkName = 5
  LinkType = 65536
  LocalDiskFlag = 2097152
  ModificationTime = 1
  OwnerGroup = 1
  OwnerUser = 0
  PathName = 2
  PermsMask = 65535
  ReadGroupPerm = 64
  ReadOtherPerm = 4
  ReadOwnerPerm = 16384
  ReadUserPerm = 1024
  Refresh = 16777216
  RootFlag = 8388608
  TypesMask = 983040
  WriteGroupPerm = 32
  WriteOtherPerm = 2
  WriteOwnerPerm = 8192
  WriteUserPerm = 512

class QFile(_Mock):
  pass
  AbortError = 6
  Append = 4
  AutoCloseHandle = 1
  CopyError = 14
  DontCloseHandle = 0
  ExeGroup = 16
  ExeOther = 1
  ExeOwner = 4096
  ExeUser = 256
  FatalError = 3
  NoError = 0
  NoOptions = 0
  NotOpen = 0
  OpenError = 5
  PermissionsError = 13
  PositionError = 11
  ReadError = 1
  ReadGroup = 64
  ReadOnly = 1
  ReadOther = 4
  ReadOwner = 16384
  ReadUser = 1024
  ReadWrite = 3
  RemoveError = 9
  RenameError = 10
  ResizeError = 12
  ResourceError = 4
  Text = 16
  TimeOutError = 7
  Truncate = 8
  Unbuffered = 32
  UnspecifiedError = 8
  WriteError = 2
  WriteGroup = 32
  WriteOnly = 2
  WriteOther = 2
  WriteOwner = 8192
  WriteUser = 512

class QFileInfo(_Mock):
  pass


class QFileSystemWatcher(_Mock):
  pass


class QFinalState(_Mock):
  pass


class QGenericArgument(_Mock):
  pass


class QGenericReturnArgument(_Mock):
  pass


class QHistoryState(_Mock):
  pass
  DeepHistory = 1
  ShallowHistory = 0

class QIODevice(_Mock):
  pass
  Append = 4
  NotOpen = 0
  ReadOnly = 1
  ReadWrite = 3
  Text = 16
  Truncate = 8
  Unbuffered = 32
  WriteOnly = 2

class QLatin1Char(_Mock):
  pass


class QLatin1String(_Mock):
  pass


class QLibrary(_Mock):
  pass
  ExportExternalSymbolsHint = 2
  LoadArchiveMemberHint = 4
  ResolveAllSymbolsHint = 1

class QLibraryInfo(_Mock):
  pass
  BinariesPath = 4
  DataPath = 6
  DemosPath = 9
  DocumentationPath = 1
  ExamplesPath = 10
  HeadersPath = 2
  ImportsPath = 11
  LibrariesPath = 3
  PluginsPath = 5
  PrefixPath = 0
  SettingsPath = 8
  TranslationsPath = 7

class QLine(_Mock):
  pass


class QLineF(_Mock):
  pass
  BoundedIntersection = 1
  NoIntersection = 0
  UnboundedIntersection = 2

class QLocale(_Mock):
  pass
  Abkhazian = 2
  Afan = 3
  Afar = 4
  Afghanistan = 1
  Afrikaans = 5
  Aghem = 216
  Akan = 146
  Albania = 2
  Albanian = 6
  Algeria = 3
  AlternateQuotation = 1
  AmericanSamoa = 4
  Amharic = 7
  Andorra = 5
  Angola = 6
  Anguilla = 7
  Antarctica = 8
  AntiguaAndBarbuda = 9
  AnyCountry = 0
  AnyLanguage = 0
  AnyScript = 0
  Arabic = 8
  ArabicScript = 1
  Argentina = 10
  Armenia = 11
  Armenian = 9
  Aruba = 12
  Assamese = 10
  Asu = 205
  Atsam = 156
  Australia = 13
  Austria = 14
  Aymara = 11
  Azerbaijan = 15
  Azerbaijani = 12
  Bafia = 222
  Bahamas = 16
  Bahrain = 17
  Bambara = 188
  Bangladesh = 18
  Barbados = 19
  Basaa = 217
  Bashkir = 13
  Basque = 14
  Belarus = 20
  Belgium = 21
  Belize = 22
  Bemba = 195
  Bena = 186
  Bengali = 15
  Benin = 23
  Bermuda = 24
  Bhutan = 25
  Bhutani = 16
  Bihari = 17
  Bislama = 18
  Blin = 152
  Bodo = 215
  Bolivia = 26
  BosniaAndHerzegowina = 27
  Bosnian = 142
  Botswana = 28
  BouvetIsland = 29
  Brazil = 30
  Breton = 19
  BritishIndianOceanTerritory = 31
  BritishVirginIslands = 233
  BruneiDarussalam = 32
  Bulgaria = 33
  Bulgarian = 20
  BurkinaFaso = 34
  Burmese = 21
  Burundi = 35
  Byelorussian = 22
  C = 1
  Cambodia = 36
  Cambodian = 23
  Cameroon = 37
  Canada = 38
  CapeVerde = 39
  Catalan = 24
  CaymanIslands = 40
  CentralAfricanRepublic = 41
  CentralMoroccoTamazight = 212
  Chad = 42
  Cherokee = 190
  Chewa = 165
  Chiga = 211
  Chile = 43
  China = 44
  Chinese = 25
  ChristmasIsland = 45
  CocosIslands = 46
  Colognian = 201
  Colombia = 47
  Comoros = 48
  CongoSwahili = 230
  CookIslands = 51
  Cornish = 145
  Corsican = 26
  CostaRica = 52
  Croatia = 54
  Croatian = 27
  Cuba = 55
  CurrencyDisplayName = 2
  CurrencyIsoCode = 0
  CurrencySymbol = 1
  Cyprus = 56
  CyrillicScript = 2
  Czech = 28
  CzechRepublic = 57
  Danish = 29
  DemocraticRepublicOfCongo = 49
  DemocraticRepublicOfKorea = 113
  Denmark = 58
  DeseretScript = 3
  Divehi = 143
  Djibouti = 59
  Dominica = 60
  DominicanRepublic = 61
  Duala = 219
  Dutch = 30
  EastTimor = 62
  Ecuador = 63
  Egypt = 64
  ElSalvador = 65
  Embu = 189
  English = 31
  EquatorialGuinea = 66
  Eritrea = 67
  Esperanto = 32
  Estonia = 68
  Estonian = 33
  Ethiopia = 69
  Ewe = 161
  Ewondo = 221
  FalklandIslands = 70
  FaroeIslands = 71
  Faroese = 34
  FijiCountry = 72
  FijiLanguage = 35
  Filipino = 166
  Finland = 73
  Finnish = 36
  France = 74
  French = 37
  FrenchGuiana = 76
  FrenchPolynesia = 77
  FrenchSouthernTerritories = 78
  Frisian = 38
  Friulian = 159
  Fulah = 177
  Ga = 148
  Gabon = 79
  Gaelic = 39
  Galician = 40
  Gambia = 80
  Ganda = 194
  Geez = 153
  Georgia = 81
  Georgian = 41
  German = 42
  Germany = 82
  Ghana = 83
  Gibraltar = 84
  Greece = 85
  Greek = 43
  Greenland = 86
  Greenlandic = 44
  Grenada = 87
  Guadeloupe = 88
  Guam = 89
  Guarani = 45
  Guatemala = 90
  Guinea = 91
  GuineaBissau = 92
  Gujarati = 46
  GurmukhiScript = 4
  Gusii = 175
  Guyana = 93
  Haiti = 94
  Hausa = 47
  Hawaiian = 163
  HeardAndMcDonaldIslands = 95
  Hebrew = 48
  Hindi = 49
  Honduras = 96
  HongKong = 97
  Hungarian = 50
  Hungary = 98
  Iceland = 99
  Icelandic = 51
  Igbo = 149
  ImperialSystem = 1
  India = 100
  Indonesia = 101
  Indonesian = 52
  Interlingua = 53
  Interlingue = 54
  Inuktitut = 55
  Inupiak = 56
  Iran = 102
  Iraq = 103
  Ireland = 104
  Irish = 57
  Israel = 105
  Italian = 58
  Italy = 106
  IvoryCoast = 53
  Jamaica = 107
  Japan = 108
  Japanese = 59
  Javanese = 60
  Jju = 158
  JolaFonyi = 220
  Jordan = 109
  Kabuverdianu = 196
  Kabyle = 184
  Kalenjin = 198
  Kamba = 150
  Kannada = 61
  Kashmiri = 62
  Kazakh = 63
  Kazakhstan = 110
  Kenya = 111
  Kikuyu = 178
  Kinyarwanda = 64
  Kirghiz = 65
  Kiribati = 112
  Konkani = 147
  Korean = 66
  Koro = 154
  KoyraChiini = 208
  KoyraboroSenni = 213
  Kpelle = 169
  Kurdish = 67
  Kurundi = 68
  Kuwait = 115
  Kwasio = 226
  Kyrgyzstan = 116
  Langi = 193
  Lao = 117
  Laothian = 69
  LastCountry = 246
  LastLanguage = 234
  Latin = 70
  LatinAmericaAndTheCaribbean = 246
  LatinScript = 7
  Latvia = 118
  Latvian = 71
  Lebanon = 119
  Lesotho = 120
  Liberia = 121
  LibyanArabJamahiriya = 122
  Liechtenstein = 123
  Lingala = 72
  Lithuania = 124
  Lithuanian = 73
  LongFormat = 0
  LowGerman = 170
  LubaKatanga = 223
  Luo = 210
  Luxembourg = 125
  Luyia = 204
  Macau = 126
  Macedonia = 127
  Macedonian = 74
  Machame = 200
  Madagascar = 128
  MakhuwaMeetto = 224
  Makonde = 192
  Malagasy = 75
  Malawi = 129
  Malay = 76
  Malayalam = 77
  Malaysia = 130
  Maldives = 131
  Mali = 132
  Malta = 133
  Maltese = 78
  Manx = 144
  Maori = 79
  Marathi = 80
  MarshallIslands = 134
  Martinique = 135
  Masai = 202
  Mauritania = 136
  Mauritius = 137
  Mayotte = 138
  Meru = 197
  MetricSystem = 0
  MetropolitanFrance = 75
  Mexico = 139
  Micronesia = 140
  Moldavian = 81
  Moldova = 141
  Monaco = 142
  Mongolia = 143
  Mongolian = 82
  MongolianScript = 8
  Montenegro = 242
  Montserrat = 144
  Morisyen = 191
  Morocco = 145
  Mozambique = 146
  Mundang = 225
  Myanmar = 147
  Nama = 199
  Namibia = 148
  NarrowFormat = 2
  NauruCountry = 149
  NauruLanguage = 83
  Nepal = 150
  Nepali = 84
  Netherlands = 151
  NetherlandsAntilles = 152
  NewCaledonia = 153
  NewZealand = 154
  Nicaragua = 155
  Niger = 156
  Nigeria = 157
  Niue = 158
  NorfolkIsland = 159
  NorthNdebele = 181
  NorthernMarianaIslands = 160
  NorthernSami = 173
  NorthernSotho = 172
  Norway = 161
  Norwegian = 85
  NorwegianBokmal = 85
  NorwegianNynorsk = 141
  Nuer = 227
  Nyankole = 185
  Nynorsk = 141
  Occitan = 86
  Oman = 162
  OmitGroupSeparator = 1
  Oriya = 87
  Pakistan = 163
  Palau = 164
  PalestinianTerritory = 165
  Panama = 166
  PapuaNewGuinea = 167
  Paraguay = 168
  Pashto = 88
  PeoplesRepublicOfCongo = 50
  Persian = 89
  Peru = 169
  Philippines = 170
  Pitcairn = 171
  Poland = 172
  Polish = 90
  Portugal = 173
  Portuguese = 91
  PuertoRico = 174
  Punjabi = 92
  Qatar = 175
  Quechua = 93
  RejectGroupSeparator = 2
  RepublicOfKorea = 114
  Reunion = 176
  RhaetoRomance = 94
  Romania = 177
  Romanian = 95
  Rombo = 182
  Rundi = 68
  Russian = 96
  RussianFederation = 178
  Rwa = 209
  Rwanda = 179
  Saho = 207
  SaintBarthelemy = 244
  SaintKittsAndNevis = 180
  SaintMartin = 245
  Sakha = 228
  Samburu = 179
  Samoa = 183
  Samoan = 97
  SanMarino = 184
  Sangho = 98
  Sangu = 229
  Sanskrit = 99
  SaoTomeAndPrincipe = 185
  SaudiArabia = 186
  Sena = 180
  Senegal = 187
  Serbia = 243
  SerbiaAndMontenegro = 241
  Serbian = 100
  SerboCroatian = 101
  Sesotho = 102
  Setswana = 103
  Seychelles = 188
  Shambala = 214
  Shona = 104
  ShortFormat = 1
  SichuanYi = 168
  Sidamo = 155
  SierraLeone = 189
  SimplifiedChineseScript = 5
  SimplifiedHanScript = 5
  Sindhi = 105
  Singapore = 190
  Singhalese = 106
  Siswati = 107
  Slovak = 108
  Slovakia = 191
  Slovenia = 192
  Slovenian = 109
  Soga = 203
  SolomonIslands = 193
  Somali = 110
  Somalia = 194
  SouthAfrica = 195
  SouthGeorgiaAndTheSouthSandwichIslands = 196
  SouthNdebele = 171
  Spain = 197
  Spanish = 111
  SriLanka = 198
  StHelena = 199
  StLucia = 181
  StPierreAndMiquelon = 200
  StVincentAndTheGrenadines = 182
  StandardQuotation = 0
  Sudan = 201
  Sundanese = 112
  Suriname = 202
  SvalbardAndJanMayenIslands = 203
  Swahili = 113
  Swaziland = 204
  Sweden = 205
  Swedish = 114
  SwissGerman = 167
  Switzerland = 206
  Syriac = 151
  SyrianArabRepublic = 207
  Tachelhit = 183
  Tagalog = 115
  Taita = 176
  Taiwan = 208
  Tajik = 116
  Tajikistan = 209
  Tamil = 117
  Tanzania = 210
  Taroko = 174
  Tasawaq = 231
  Tatar = 118
  Telugu = 119
  Teso = 206
  Thai = 120
  Thailand = 211
  Tibetan = 121
  TifinaghScript = 9
  Tigre = 157
  Tigrinya = 122
  Togo = 212
  Tokelau = 213
  TongaCountry = 214
  TongaLanguage = 123
  TraditionalChineseScript = 6
  TraditionalHanScript = 6
  TrinidadAndTobago = 215
  Tsonga = 124
  Tunisia = 216
  Turkey = 217
  Turkish = 125
  Turkmen = 126
  Turkmenistan = 218
  TurksAndCaicosIslands = 219
  Tuvalu = 220
  Twi = 127
  Tyap = 164
  USVirginIslands = 234
  Uganda = 221
  Uigur = 128
  Ukraine = 222
  Ukrainian = 129
  UnitedArabEmirates = 223
  UnitedKingdom = 224
  UnitedStates = 225
  UnitedStatesMinorOutlyingIslands = 226
  Urdu = 130
  Uruguay = 227
  Uzbek = 131
  Uzbekistan = 228
  Vai = 232
  Vanuatu = 229
  VaticanCityState = 230
  Venda = 160
  Venezuela = 231
  VietNam = 232
  Vietnamese = 132
  Volapuk = 133
  Vunjo = 187
  Walamo = 162
  WallisAndFutunaIslands = 235
  Walser = 233
  Welsh = 134
  WesternSahara = 236
  Wolof = 135
  Xhosa = 136
  Yangben = 234
  Yemen = 237
  Yiddish = 137
  Yoruba = 138
  Yugoslavia = 238
  Zambia = 239
  Zarma = 218
  Zhuang = 139
  Zimbabwe = 240
  Zulu = 140

class QMargins(_Mock):
  pass


class QMetaClassInfo(_Mock):
  pass


class QMetaEnum(_Mock):
  pass


class QMetaMethod(_Mock):
  pass
  Constructor = 3
  Method = 0
  Private = 0
  Protected = 1
  Public = 2
  Signal = 1
  Slot = 2

class QMetaObject(_Mock):
  pass


class QMetaProperty(_Mock):
  pass


class QMetaType(_Mock):
  pass
  Bool = 1
  Char = 131
  Double = 6
  FirstGuiType = 63
  Float = 135
  Int = 2
  LastCoreType = 29
  Long = 129
  LongLong = 4
  QBitArray = 13
  QBitmap = 73
  QBrush = 66
  QByteArray = 12
  QChar = 7
  QColor = 67
  QCursor = 74
  QDate = 14
  QDateTime = 16
  QEasingCurve = 29
  QFont = 64
  QIcon = 69
  QImage = 70
  QKeySequence = 76
  QLine = 23
  QLineF = 24
  QLocale = 18
  QMatrix = 80
  QMatrix4x4 = 82
  QObjectStar = 136
  QPalette = 68
  QPen = 77
  QPixmap = 65
  QPoint = 25
  QPointF = 26
  QPolygon = 71
  QQuaternion = 86
  QRect = 19
  QRectF = 20
  QRegExp = 27
  QRegion = 72
  QSize = 21
  QSizeF = 22
  QSizePolicy = 75
  QString = 10
  QStringList = 11
  QTextFormat = 79
  QTextLength = 78
  QTime = 15
  QTransform = 81
  QUrl = 17
  QVariant = 138
  QVariantHash = 28
  QVariantList = 9
  QVariantMap = 8
  QVector2D = 83
  QVector3D = 84
  QVector4D = 85
  QWidgetStar = 137
  Short = 130
  UChar = 134
  UInt = 3
  ULong = 132
  ULongLong = 5
  UShort = 133
  User = 256
  Void = 0
  VoidStar = 128

class QMimeData(_Mock):
  pass


class QModelIndex(_Mock):
  pass


class QMutex(_Mock):
  pass
  NonRecursive = 0
  Recursive = 1

class QMutexLocker(_Mock):
  pass


class QObject(_Mock):
  pass


class QObjectCleanupHandler(_Mock):
  pass


class QParallelAnimationGroup(_Mock):
  pass
  Backward = 1
  DeleteWhenStopped = 1
  Forward = 0
  KeepWhenStopped = 0
  Paused = 1
  Running = 2
  Stopped = 0

class QPauseAnimation(_Mock):
  pass
  Backward = 1
  DeleteWhenStopped = 1
  Forward = 0
  KeepWhenStopped = 0
  Paused = 1
  Running = 2
  Stopped = 0

class QPersistentModelIndex(_Mock):
  pass


class QPluginLoader(_Mock):
  pass


class QPoint(_Mock):
  pass


class QPointF(_Mock):
  pass


class QProcess(_Mock):
  pass
  Append = 4
  CrashExit = 1
  Crashed = 1
  FailedToStart = 0
  ForwardedChannels = 2
  MergedChannels = 1
  NormalExit = 0
  NotOpen = 0
  NotRunning = 0
  ReadError = 3
  ReadOnly = 1
  ReadWrite = 3
  Running = 2
  SeparateChannels = 0
  StandardError = 1
  StandardOutput = 0
  Starting = 1
  Text = 16
  Timedout = 2
  Truncate = 8
  Unbuffered = 32
  UnknownError = 5
  WriteError = 4
  WriteOnly = 2

class QProcessEnvironment(_Mock):
  pass


class QPropertyAnimation(_Mock):
  pass
  Backward = 1
  DeleteWhenStopped = 1
  Forward = 0
  KeepWhenStopped = 0
  Paused = 1
  Running = 2
  Stopped = 0

class QReadLocker(_Mock):
  pass


class QReadWriteLock(_Mock):
  pass
  NonRecursive = 0
  Recursive = 1

class QRect(_Mock):
  pass


class QRectF(_Mock):
  pass


class QRegExp(_Mock):
  pass
  CaretAtOffset = 1
  CaretAtZero = 0
  CaretWontMatch = 2
  FixedString = 2
  RegExp = 0
  RegExp2 = 3
  W3CXmlSchema11 = 5
  Wildcard = 1
  WildcardUnix = 4

class QResource(_Mock):
  pass


class QRunnable(_Mock):
  pass


class QSemaphore(_Mock):
  pass


class QSequentialAnimationGroup(_Mock):
  pass
  Backward = 1
  DeleteWhenStopped = 1
  Forward = 0
  KeepWhenStopped = 0
  Paused = 1
  Running = 2
  Stopped = 0

class QSettings(_Mock):
  pass
  AccessError = 1
  FormatError = 2
  IniFormat = 1
  InvalidFormat = 16
  NativeFormat = 0
  NoError = 0
  SystemScope = 1
  UserScope = 0

class QSharedMemory(_Mock):
  pass
  AlreadyExists = 4
  InvalidSize = 2
  KeyError = 3
  LockError = 6
  NoError = 0
  NotFound = 5
  OutOfResources = 7
  PermissionDenied = 1
  ReadOnly = 0
  ReadWrite = 1
  UnknownError = 8

class QSignalMapper(_Mock):
  pass


class QSignalTransition(_Mock):
  pass


class QSize(_Mock):
  pass


class QSizeF(_Mock):
  pass


class QSocketNotifier(_Mock):
  pass
  Exception = 2
  Read = 0
  Write = 1

class QState(_Mock):
  pass
  ExclusiveStates = 0
  ParallelStates = 1

class QStateMachine(_Mock):
  pass
  DontRestoreProperties = 0
  ExclusiveStates = 0
  HighPriority = 1
  NoCommonAncestorForTransitionError = 3
  NoDefaultStateInHistoryStateError = 2
  NoError = 0
  NoInitialStateError = 1
  NormalPriority = 0
  ParallelStates = 1
  RestoreProperties = 1

class QString(_Mock):
  pass
  KeepEmptyParts = 0
  NormalizationForm_C = 1
  NormalizationForm_D = 0
  NormalizationForm_KC = 3
  NormalizationForm_KD = 2
  SectionCaseInsensitiveSeps = 8
  SectionDefault = 0
  SectionIncludeLeadingSep = 2
  SectionIncludeTrailingSep = 4
  SectionSkipEmpty = 1
  SkipEmptyParts = 1

class QStringList(_Mock):
  pass


class QStringMatcher(_Mock):
  pass


class QStringRef(_Mock):
  pass


class QSysInfo(_Mock):
  pass
  BigEndian = 0
  ByteOrder = 1
  LittleEndian = 1
  WordSize = 64

class QSystemLocale(_Mock):
  pass
  AMText = 24
  CountryId = 1
  CurrencySymbol = 28
  CurrencyToString = 29
  DateFormatLong = 6
  DateFormatShort = 7
  DateTimeFormatLong = 18
  DateTimeFormatShort = 19
  DateTimeToStringLong = 20
  DateTimeToStringShort = 21
  DateToStringLong = 14
  DateToStringShort = 15
  DayNameLong = 10
  DayNameShort = 11
  DecimalPoint = 2
  FirstDayOfWeek = 26
  GroupSeparator = 3
  LanguageId = 0
  ListToSeparatedString = 34
  LocaleChanged = 35
  MeasurementSystem = 22
  MonthNameLong = 12
  MonthNameShort = 13
  NativeCountryName = 37
  NativeLanguageName = 36
  NegativeSign = 5
  PMText = 25
  PositiveSign = 23
  ScriptId = 33
  StringToAlternateQuotation = 32
  StringToStandardQuotation = 31
  TimeFormatLong = 8
  TimeFormatShort = 9
  TimeToStringLong = 16
  TimeToStringShort = 17
  UILanguages = 30
  Weekdays = 27
  ZeroDigit = 4

class QSystemSemaphore(_Mock):
  pass
  AlreadyExists = 3
  Create = 1
  KeyError = 2
  NoError = 0
  NotFound = 4
  Open = 0
  OutOfResources = 5
  PermissionDenied = 1
  UnknownError = 6

class QTemporaryFile(_Mock):
  pass
  AbortError = 6
  Append = 4
  AutoCloseHandle = 1
  CopyError = 14
  DontCloseHandle = 0
  ExeGroup = 16
  ExeOther = 1
  ExeOwner = 4096
  ExeUser = 256
  FatalError = 3
  NoError = 0
  NoOptions = 0
  NotOpen = 0
  OpenError = 5
  PermissionsError = 13
  PositionError = 11
  ReadError = 1
  ReadGroup = 64
  ReadOnly = 1
  ReadOther = 4
  ReadOwner = 16384
  ReadUser = 1024
  ReadWrite = 3
  RemoveError = 9
  RenameError = 10
  ResizeError = 12
  ResourceError = 4
  Text = 16
  TimeOutError = 7
  Truncate = 8
  Unbuffered = 32
  UnspecifiedError = 8
  WriteError = 2
  WriteGroup = 32
  WriteOnly = 2
  WriteOther = 2
  WriteOwner = 8192
  WriteUser = 512

class QTextBoundaryFinder(_Mock):
  pass
  EndWord = 2
  Grapheme = 0
  Line = 2
  NotAtBoundary = 0
  Sentence = 3
  StartWord = 1
  Word = 1

class QTextCodec(_Mock):
  pass
  ConvertInvalidToNull = -2147483648
  DefaultConversion = 0
  IgnoreHeader = 1

class QTextDecoder(_Mock):
  pass


class QTextEncoder(_Mock):
  pass


class QTextStream(_Mock):
  pass
  AlignAccountingStyle = 3
  AlignCenter = 2
  AlignLeft = 0
  AlignRight = 1
  FixedNotation = 1
  ForcePoint = 2
  ForceSign = 4
  Ok = 0
  ReadCorruptData = 2
  ReadPastEnd = 1
  ScientificNotation = 2
  ShowBase = 1
  SmartNotation = 0
  UppercaseBase = 8
  UppercaseDigits = 16
  WriteFailed = 3

class QTextStreamManipulator(_Mock):
  pass


class QThread(_Mock):
  pass
  HighPriority = 4
  HighestPriority = 5
  IdlePriority = 0
  InheritPriority = 7
  LowPriority = 2
  LowestPriority = 1
  NormalPriority = 3
  TimeCriticalPriority = 6

class QThreadPool(_Mock):
  pass


class QTime(_Mock):
  pass


class QTimeLine(_Mock):
  pass
  Backward = 1
  CosineCurve = 5
  EaseInCurve = 0
  EaseInOutCurve = 2
  EaseOutCurve = 1
  Forward = 0
  LinearCurve = 3
  NotRunning = 0
  Paused = 1
  Running = 2
  SineCurve = 4

class QTimer(_Mock):
  pass


class QTimerEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QTranslator(_Mock):
  pass


class QUrl(_Mock):
  pass
  RemoveAuthority = 30
  RemoveFragment = 128
  RemovePassword = 2
  RemovePath = 32
  RemovePort = 8
  RemoveQuery = 64
  RemoveScheme = 1
  RemoveUserInfo = 6
  StrictMode = 1
  StripTrailingSlash = 65536
  TolerantMode = 0

class QUuid(_Mock):
  pass
  DCE = 2
  EmbeddedPOSIX = 2
  Microsoft = 6
  NCS = 0
  Name = 3
  Random = 4
  Reserved = 7
  Time = 1
  VarUnknown = -1
  VerUnknown = -1

class QVariant(_Mock):
  pass
  BitArray = 13
  Bitmap = 73
  Bool = 1
  Brush = 66
  ByteArray = 12
  Char = 7
  Color = 67
  Cursor = 74
  Date = 14
  DateTime = 16
  Double = 6
  EasingCurve = 29
  Font = 64
  Hash = 28
  Icon = 69
  Image = 70
  Int = 2
  Invalid = 0
  KeySequence = 76
  Line = 23
  LineF = 24
  List = 9
  Locale = 18
  LongLong = 4
  Map = 8
  Matrix = 80
  Matrix4x4 = 82
  Palette = 68
  Pen = 77
  Pixmap = 65
  Point = 25
  PointF = 26
  Polygon = 71
  Quaternion = 86
  Rect = 19
  RectF = 20
  RegExp = 27
  Region = 72
  Size = 21
  SizeF = 22
  SizePolicy = 75
  String = 10
  StringList = 11
  TextFormat = 79
  TextLength = 78
  Time = 15
  Transform = 81
  UInt = 3
  ULongLong = 5
  Url = 17
  UserType = 127
  Vector2D = 83
  Vector3D = 84
  Vector4D = 85

class QVariantAnimation(_Mock):
  pass
  Backward = 1
  DeleteWhenStopped = 1
  Forward = 0
  KeepWhenStopped = 0
  Paused = 1
  Running = 2
  Stopped = 0

class QWaitCondition(_Mock):
  pass


class QWriteLocker(_Mock):
  pass


class QXmlStreamAttribute(_Mock):
  pass


class QXmlStreamAttributes(_Mock):
  pass


class QXmlStreamEntityDeclaration(_Mock):
  pass


class QXmlStreamEntityResolver(_Mock):
  pass


class QXmlStreamNamespaceDeclaration(_Mock):
  pass


class QXmlStreamNotationDeclaration(_Mock):
  pass


class QXmlStreamReader(_Mock):
  pass
  Characters = 6
  Comment = 7
  CustomError = 2
  DTD = 8
  EndDocument = 3
  EndElement = 5
  EntityReference = 9
  ErrorOnUnexpectedElement = 0
  IncludeChildElements = 1
  Invalid = 1
  NoError = 0
  NoToken = 0
  NotWellFormedError = 3
  PrematureEndOfDocumentError = 4
  ProcessingInstruction = 10
  SkipChildElements = 2
  StartDocument = 2
  StartElement = 4
  UnexpectedElementError = 1

class QXmlStreamWriter(_Mock):
  pass


class Qt(_Mock):
  pass
  AA_CaptureMultimediaKeys = 11
  AA_DontCreateNativeWidgetSiblings = 4
  AA_DontShowIconsInMenus = 2
  AA_DontUseNativeMenuBar = 6
  AA_ImmediateWidgetCreation = 0
  AA_MSWindowsUseDirect3DByDefault = 1
  AA_MacDontSwapCtrlAndMeta = 7
  AA_MacPluginApplication = 5
  AA_NativeWindows = 3
  AA_S60DisablePartialScreenInputMode = 9
  AA_S60DontConstructApplicationPanes = 8
  AA_X11InitThreads = 10
  ALT = 134217728
  AbsoluteSize = 0
  AccessibleDescriptionRole = 12
  AccessibleTextRole = 11
  ActionMask = 255
  ActionsContextMenu = 2
  ActiveWindowFocusReason = 3
  AlignAbsolute = 16
  AlignBottom = 64
  AlignCenter = 132
  AlignHCenter = 4
  AlignHorizontal_Mask = 31
  AlignJustify = 8
  AlignLeading = 1
  AlignLeft = 1
  AlignRight = 2
  AlignTop = 32
  AlignTrailing = 2
  AlignVCenter = 128
  AlignVertical_Mask = 224
  AllDockWidgetAreas = 15
  AllToolBarAreas = 15
  AltModifier = 134217728
  AnchorBottom = 5
  AnchorHorizontalCenter = 1
  AnchorHref = 1
  AnchorLeft = 0
  AnchorName = 0
  AnchorRight = 2
  AnchorTop = 3
  AnchorVerticalCenter = 4
  ApplicationModal = 2
  ApplicationShortcut = 2
  ArrowCursor = 0
  AscendingOrder = 0
  AutoColor = 0
  AutoCompatConnection = 3
  AutoConnection = 0
  AutoDither = 0
  AutoText = 2
  AvoidDither = 128
  BDiagPattern = 12
  BackgroundColorRole = 8
  BackgroundRole = 8
  BacktabFocusReason = 2
  BevelJoin = 64
  BitmapCursor = 24
  BlankCursor = 10
  BlockingQueuedConnection = 4
  BottomDockWidgetArea = 8
  BottomLeftCorner = 2
  BottomLeftSection = 8
  BottomRightCorner = 3
  BottomRightSection = 6
  BottomSection = 7
  BottomToolBarArea = 8
  BusyCursor = 16
  BypassGraphicsProxyWidget = 536870912
  CTRL = 67108864
  CaseInsensitive = 0
  CaseSensitive = 1
  CheckStateRole = 10
  Checked = 2
  ClickFocus = 2
  ClosedHandCursor = 18
  ColorOnly = 3
  ConicalGradientPattern = 17
  ContainsItemBoundingRect = 2
  ContainsItemShape = 0
  ControlModifier = 67108864
  CopyAction = 1
  CrossCursor = 2
  CrossPattern = 11
  CustomContextMenu = 3
  CustomCursor = 25
  CustomDashLine = 6
  CustomGesture = 256
  CustomizeWindowHint = 33554432
  DashDotDotLine = 5
  DashDotLine = 4
  DashLine = 2
  DecorationRole = 1
  DefaultContextMenu = 1
  DefaultLocaleLongDate = 7
  DefaultLocaleShortDate = 6
  Dense1Pattern = 2
  Dense2Pattern = 3
  Dense3Pattern = 4
  Dense4Pattern = 5
  Dense5Pattern = 6
  Dense6Pattern = 7
  Dense7Pattern = 8
  DescendingOrder = 1
  Desktop = 17
  DeviceCoordinates = 0
  DiagCrossPattern = 14
  Dialog = 3
  DiffuseAlphaDither = 8
  DiffuseDither = 0
  DirectConnection = 1
  DisplayRole = 0
  DockWidgetArea_Mask = 15
  DontStartGestureOnChildren = 1
  DotLine = 3
  DownArrow = 2
  DragCopyCursor = 19
  DragLinkCursor = 21
  DragMoveCursor = 20
  Drawer = 7
  EditRole = 2
  ElideLeft = 0
  ElideMiddle = 2
  ElideNone = 3
  ElideRight = 1
  ExactHit = 0
  FDiagPattern = 13
  FastTransformation = 0
  FlatCap = 0
  FontRole = 6
  ForbiddenCursor = 14
  ForegroundRole = 9
  FramelessWindowHint = 2048
  Friday = 5
  FuzzyHit = 1
  GestureCanceled = 4
  GestureFinished = 3
  GestureStarted = 1
  GestureUpdated = 2
  GroupSwitchModifier = 1073741824
  HighEventPriority = 1
  HorPattern = 9
  Horizontal = 1
  IBeamCursor = 4
  ISODate = 1
  IgnoreAction = 0
  IgnoreAspectRatio = 0
  IgnoredGesturesPropagateToParent = 4
  ImAnchorPosition = 6
  ImCurrentSelection = 4
  ImCursorPosition = 2
  ImFont = 1
  ImMaximumTextLength = 5
  ImMicroFocus = 0
  ImSurroundingText = 3
  ImhDialableCharactersOnly = 1048576
  ImhDigitsOnly = 65536
  ImhEmailCharactersOnly = 2097152
  ImhExclusiveInputMask = -65536
  ImhFormattedNumbersOnly = 131072
  ImhHiddenText = 1
  ImhLowercaseOnly = 524288
  ImhNoAutoUppercase = 2
  ImhNoPredictiveText = 32
  ImhNone = 0
  ImhPreferLowercase = 16
  ImhPreferNumbers = 4
  ImhPreferUppercase = 8
  ImhUppercaseOnly = 262144
  ImhUrlCharactersOnly = 4194304
  InitialSortOrderRole = 14
  IntersectClip = 2
  IntersectsItemBoundingRect = 3
  IntersectsItemShape = 1
  ItemIsDragEnabled = 4
  ItemIsDropEnabled = 8
  ItemIsEditable = 2
  ItemIsEnabled = 32
  ItemIsSelectable = 1
  ItemIsTristate = 64
  ItemIsUserCheckable = 16
  KeepAspectRatio = 1
  KeepAspectRatioByExpanding = 2
  Key_0 = 48
  Key_1 = 49
  Key_2 = 50
  Key_3 = 51
  Key_4 = 52
  Key_5 = 53
  Key_6 = 54
  Key_7 = 55
  Key_8 = 56
  Key_9 = 57
  Key_A = 65
  Key_AE = 198
  Key_Aacute = 193
  Key_Acircumflex = 194
  Key_AddFavorite = 16777408
  Key_Adiaeresis = 196
  Key_Agrave = 192
  Key_Alt = 16777251
  Key_AltGr = 16781571
  Key_Ampersand = 38
  Key_Any = 32
  Key_Apostrophe = 39
  Key_ApplicationLeft = 16777415
  Key_ApplicationRight = 16777416
  Key_Aring = 197
  Key_AsciiCircum = 94
  Key_AsciiTilde = 126
  Key_Asterisk = 42
  Key_At = 64
  Key_Atilde = 195
  Key_AudioCycleTrack = 16777478
  Key_AudioForward = 16777474
  Key_AudioRandomPlay = 16777476
  Key_AudioRepeat = 16777475
  Key_AudioRewind = 16777413
  Key_Away = 16777464
  Key_B = 66
  Key_Back = 16777313
  Key_BackForward = 16777414
  Key_Backslash = 92
  Key_Backspace = 16777219
  Key_Backtab = 16777218
  Key_Bar = 124
  Key_BassBoost = 16777331
  Key_BassDown = 16777333
  Key_BassUp = 16777332
  Key_Battery = 16777470
  Key_Bluetooth = 16777471
  Key_Book = 16777417
  Key_BraceLeft = 123
  Key_BraceRight = 125
  Key_BracketLeft = 91
  Key_BracketRight = 93
  Key_BrightnessAdjust = 16777410
  Key_C = 67
  Key_CD = 16777418
  Key_Calculator = 16777419
  Key_Calendar = 16777444
  Key_Call = 17825796
  Key_Camera = 17825824
  Key_CameraFocus = 17825825
  Key_Cancel = 16908289
  Key_CapsLock = 16777252
  Key_Ccedilla = 199
  Key_Clear = 16777227
  Key_ClearGrab = 16777421
  Key_Close = 16777422
  Key_Codeinput = 16781623
  Key_Colon = 58
  Key_Comma = 44
  Key_Community = 16777412
  Key_Context1 = 17825792
  Key_Context2 = 17825793
  Key_Context3 = 17825794
  Key_Context4 = 17825795
  Key_ContrastAdjust = 16777485
  Key_Control = 16777249
  Key_Copy = 16777423
  Key_Cut = 16777424
  Key_D = 68
  Key_DOS = 16777426
  Key_Dead_Abovedot = 16781910
  Key_Dead_Abovering = 16781912
  Key_Dead_Acute = 16781905
  Key_Dead_Belowdot = 16781920
  Key_Dead_Breve = 16781909
  Key_Dead_Caron = 16781914
  Key_Dead_Cedilla = 16781915
  Key_Dead_Circumflex = 16781906
  Key_Dead_Diaeresis = 16781911
  Key_Dead_Doubleacute = 16781913
  Key_Dead_Grave = 16781904
  Key_Dead_Hook = 16781921
  Key_Dead_Horn = 16781922
  Key_Dead_Iota = 16781917
  Key_Dead_Macron = 16781908
  Key_Dead_Ogonek = 16781916
  Key_Dead_Semivoiced_Sound = 16781919
  Key_Dead_Tilde = 16781907
  Key_Dead_Voiced_Sound = 16781918
  Key_Delete = 16777223
  Key_Direction_L = 16777305
  Key_Direction_R = 16777312
  Key_Display = 16777425
  Key_Documents = 16777427
  Key_Dollar = 36
  Key_Down = 16777237
  Key_E = 69
  Key_ETH = 208
  Key_Eacute = 201
  Key_Ecircumflex = 202
  Key_Ediaeresis = 203
  Key_Egrave = 200
  Key_Eisu_Shift = 16781615
  Key_Eisu_toggle = 16781616
  Key_Eject = 16777401
  Key_End = 16777233
  Key_Enter = 16777221
  Key_Equal = 61
  Key_Escape = 16777216
  Key_Excel = 16777428
  Key_Exclam = 33
  Key_Execute = 16908291
  Key_Explorer = 16777429
  Key_F = 70
  Key_F1 = 16777264
  Key_F10 = 16777273
  Key_F11 = 16777274
  Key_F12 = 16777275
  Key_F13 = 16777276
  Key_F14 = 16777277
  Key_F15 = 16777278
  Key_F16 = 16777279
  Key_F17 = 16777280
  Key_F18 = 16777281
  Key_F19 = 16777282
  Key_F2 = 16777265
  Key_F20 = 16777283
  Key_F21 = 16777284
  Key_F22 = 16777285
  Key_F23 = 16777286
  Key_F24 = 16777287
  Key_F25 = 16777288
  Key_F26 = 16777289
  Key_F27 = 16777290
  Key_F28 = 16777291
  Key_F29 = 16777292
  Key_F3 = 16777266
  Key_F30 = 16777293
  Key_F31 = 16777294
  Key_F32 = 16777295
  Key_F33 = 16777296
  Key_F34 = 16777297
  Key_F35 = 16777298
  Key_F4 = 16777267
  Key_F5 = 16777268
  Key_F6 = 16777269
  Key_F7 = 16777270
  Key_F8 = 16777271
  Key_F9 = 16777272
  Key_Favorites = 16777361
  Key_Finance = 16777411
  Key_Flip = 17825798
  Key_Forward = 16777314
  Key_G = 71
  Key_Game = 16777430
  Key_Go = 16777431
  Key_Greater = 62
  Key_H = 72
  Key_Hangul = 16781617
  Key_Hangul_Banja = 16781625
  Key_Hangul_End = 16781619
  Key_Hangul_Hanja = 16781620
  Key_Hangul_Jamo = 16781621
  Key_Hangul_Jeonja = 16781624
  Key_Hangul_PostHanja = 16781627
  Key_Hangul_PreHanja = 16781626
  Key_Hangul_Romaja = 16781622
  Key_Hangul_Special = 16781631
  Key_Hangul_Start = 16781618
  Key_Hangup = 17825797
  Key_Hankaku = 16781609
  Key_Help = 16777304
  Key_Henkan = 16781603
  Key_Hibernate = 16777480
  Key_Hiragana = 16781605
  Key_Hiragana_Katakana = 16781607
  Key_History = 16777407
  Key_Home = 16777232
  Key_HomePage = 16777360
  Key_HotLinks = 16777409
  Key_Hyper_L = 16777302
  Key_Hyper_R = 16777303
  Key_I = 73
  Key_Iacute = 205
  Key_Icircumflex = 206
  Key_Idiaeresis = 207
  Key_Igrave = 204
  Key_Insert = 16777222
  Key_J = 74
  Key_K = 75
  Key_Kana_Lock = 16781613
  Key_Kana_Shift = 16781614
  Key_Kanji = 16781601
  Key_Katakana = 16781606
  Key_KeyboardBrightnessDown = 16777398
  Key_KeyboardBrightnessUp = 16777397
  Key_KeyboardLightOnOff = 16777396
  Key_L = 76
  Key_LastNumberRedial = 17825801
  Key_Launch0 = 16777378
  Key_Launch1 = 16777379
  Key_Launch2 = 16777380
  Key_Launch3 = 16777381
  Key_Launch4 = 16777382
  Key_Launch5 = 16777383
  Key_Launch6 = 16777384
  Key_Launch7 = 16777385
  Key_Launch8 = 16777386
  Key_Launch9 = 16777387
  Key_LaunchA = 16777388
  Key_LaunchB = 16777389
  Key_LaunchC = 16777390
  Key_LaunchD = 16777391
  Key_LaunchE = 16777392
  Key_LaunchF = 16777393
  Key_LaunchG = 16777486
  Key_LaunchH = 16777487
  Key_LaunchMail = 16777376
  Key_LaunchMedia = 16777377
  Key_Left = 16777234
  Key_Less = 60
  Key_LightBulb = 16777405
  Key_LogOff = 16777433
  Key_M = 77
  Key_MailForward = 16777467
  Key_Market = 16777434
  Key_Massyo = 16781612
  Key_MediaLast = 16842751
  Key_MediaNext = 16777347
  Key_MediaPause = 16777349
  Key_MediaPlay = 16777344
  Key_MediaPrevious = 16777346
  Key_MediaRecord = 16777348
  Key_MediaStop = 16777345
  Key_MediaTogglePlayPause = 16777350
  Key_Meeting = 16777435
  Key_Memo = 16777404
  Key_Menu = 16777301
  Key_MenuKB = 16777436
  Key_MenuPB = 16777437
  Key_Messenger = 16777465
  Key_Meta = 16777250
  Key_Minus = 45
  Key_Mode_switch = 16781694
  Key_MonBrightnessDown = 16777395
  Key_MonBrightnessUp = 16777394
  Key_Muhenkan = 16781602
  Key_Multi_key = 16781600
  Key_MultipleCandidate = 16781629
  Key_Music = 16777469
  Key_MySites = 16777438
  Key_N = 78
  Key_News = 16777439
  Key_No = 16842754
  Key_Ntilde = 209
  Key_NumLock = 16777253
  Key_NumberSign = 35
  Key_O = 79
  Key_Oacute = 211
  Key_Ocircumflex = 212
  Key_Odiaeresis = 214
  Key_OfficeHome = 16777440
  Key_Ograve = 210
  Key_Ooblique = 216
  Key_OpenUrl = 16777364
  Key_Option = 16777441
  Key_Otilde = 213
  Key_P = 80
  Key_PageDown = 16777239
  Key_PageUp = 16777238
  Key_ParenLeft = 40
  Key_ParenRight = 41
  Key_Paste = 16777442
  Key_Pause = 16777224
  Key_Percent = 37
  Key_Period = 46
  Key_Phone = 16777443
  Key_Pictures = 16777468
  Key_Play = 16908293
  Key_Plus = 43
  Key_PowerDown = 16777483
  Key_PowerOff = 16777399
  Key_PreviousCandidate = 16781630
  Key_Print = 16777225
  Key_Printer = 16908290
  Key_Q = 81
  Key_Question = 63
  Key_QuoteDbl = 34
  Key_QuoteLeft = 96
  Key_R = 82
  Key_Refresh = 16777316
  Key_Reload = 16777446
  Key_Reply = 16777445
  Key_Return = 16777220
  Key_Right = 16777236
  Key_Romaji = 16781604
  Key_RotateWindows = 16777447
  Key_RotationKB = 16777449
  Key_RotationPB = 16777448
  Key_S = 83
  Key_Save = 16777450
  Key_ScreenSaver = 16777402
  Key_ScrollLock = 16777254
  Key_Search = 16777362
  Key_Select = 16842752
  Key_Semicolon = 59
  Key_Send = 16777451
  Key_Shift = 16777248
  Key_Shop = 16777406
  Key_SingleCandidate = 16781628
  Key_Slash = 47
  Key_Sleep = 16908292
  Key_Space = 32
  Key_Spell = 16777452
  Key_SplitScreen = 16777453
  Key_Standby = 16777363
  Key_Stop = 16777315
  Key_Subtitle = 16777477
  Key_Super_L = 16777299
  Key_Super_R = 16777300
  Key_Support = 16777454
  Key_Suspend = 16777484
  Key_SysReq = 16777226
  Key_T = 84
  Key_THORN = 222
  Key_Tab = 16777217
  Key_TaskPane = 16777455
  Key_Terminal = 16777456
  Key_Time = 16777479
  Key_ToDoList = 16777420
  Key_ToggleCallHangup = 17825799
  Key_Tools = 16777457
  Key_TopMenu = 16777482
  Key_Touroku = 16781611
  Key_Travel = 16777458
  Key_TrebleDown = 16777335
  Key_TrebleUp = 16777334
  Key_U = 85
  Key_UWB = 16777473
  Key_Uacute = 218
  Key_Ucircumflex = 219
  Key_Udiaeresis = 220
  Key_Ugrave = 217
  Key_Underscore = 95
  Key_Up = 16777235
  Key_V = 86
  Key_Video = 16777459
  Key_View = 16777481
  Key_VoiceDial = 17825800
  Key_VolumeDown = 16777328
  Key_VolumeMute = 16777329
  Key_VolumeUp = 16777330
  Key_W = 87
  Key_WLAN = 16777472
  Key_WWW = 16777403
  Key_WakeUp = 16777400
  Key_WebCam = 16777466
  Key_Word = 16777460
  Key_X = 88
  Key_Xfer = 16777461
  Key_Y = 89
  Key_Yacute = 221
  Key_Yes = 16842753
  Key_Z = 90
  Key_Zenkaku = 16781608
  Key_Zenkaku_Hankaku = 16781610
  Key_Zoom = 16908294
  Key_ZoomIn = 16777462
  Key_ZoomOut = 16777463
  Key_acute = 180
  Key_brokenbar = 166
  Key_cedilla = 184
  Key_cent = 162
  Key_copyright = 169
  Key_currency = 164
  Key_degree = 176
  Key_diaeresis = 168
  Key_division = 247
  Key_exclamdown = 161
  Key_guillemotleft = 171
  Key_guillemotright = 187
  Key_hyphen = 173
  Key_iTouch = 16777432
  Key_macron = 175
  Key_masculine = 186
  Key_mu = 181
  Key_multiply = 215
  Key_nobreakspace = 160
  Key_notsign = 172
  Key_onehalf = 189
  Key_onequarter = 188
  Key_onesuperior = 185
  Key_ordfeminine = 170
  Key_paragraph = 182
  Key_periodcentered = 183
  Key_plusminus = 177
  Key_questiondown = 191
  Key_registered = 174
  Key_section = 167
  Key_ssharp = 223
  Key_sterling = 163
  Key_threequarters = 190
  Key_threesuperior = 179
  Key_twosuperior = 178
  Key_unknown = 33554431
  Key_ydiaeresis = 255
  Key_yen = 165
  KeyboardModifierMask = -33554432
  KeypadModifier = 536870912
  LastCursor = 21
  LayoutDirectionAuto = 2
  LeftArrow = 3
  LeftButton = 1
  LeftDockWidgetArea = 1
  LeftSection = 1
  LeftToRight = 0
  LeftToolBarArea = 1
  LinearGradientPattern = 15
  LinkAction = 4
  LinksAccessibleByKeyboard = 8
  LinksAccessibleByMouse = 4
  LocalDate = 2
  LocalTime = 0
  LocaleDate = 3
  LogText = 3
  LogicalCoordinates = 1
  LogicalMoveStyle = 0
  LowEventPriority = -1
  META = 268435456
  MODIFIER_MASK = -33554432
  MPenCapStyle = 48
  MPenJoinStyle = 448
  MPenStyle = 15
  MSWindowsFixedSizeDialogHint = 256
  MSWindowsOwnDC = 512
  MacWindowToolBarButtonHint = 268435456
  MaskInColor = 0
  MaskOutColor = 1
  MatchCaseSensitive = 16
  MatchContains = 1
  MatchEndsWith = 3
  MatchExactly = 0
  MatchFixedString = 8
  MatchRecursive = 64
  MatchRegExp = 4
  MatchStartsWith = 2
  MatchWildcard = 5
  MatchWrap = 32
  MaximumSize = 2
  MenuBarFocusReason = 6
  MetaModifier = 268435456
  MidButton = 4
  MiddleButton = 4
  MinimumDescent = 3
  MinimumSize = 0
  MiterJoin = 0
  Monday = 1
  MonoOnly = 2
  MouseFocusReason = 0
  MoveAction = 2
  NavigationModeCursorAuto = 3
  NavigationModeCursorForceVisible = 4
  NavigationModeKeypadDirectional = 2
  NavigationModeKeypadTabOrder = 1
  NavigationModeNone = 0
  NoArrow = 0
  NoBrush = 0
  NoButton = 0
  NoClip = 0
  NoContextMenu = 0
  NoDockWidgetArea = 0
  NoFocus = 0
  NoFocusReason = 8
  NoItemFlags = 0
  NoModifier = 0
  NoPen = 0
  NoSection = 0
  NoTextInteraction = 0
  NoToolBarArea = 0
  NonModal = 0
  NormalEventPriority = 0
  OddEvenFill = 0
  OffsetFromUTC = 2
  OpaqueMode = 1
  OpenHandCursor = 17
  OrderedAlphaDither = 4
  OrderedDither = 16
  OtherFocusReason = 7
  PanGesture = 3
  PartiallyChecked = 1
  PinchGesture = 4
  PlainText = 0
  PointingHandCursor = 13
  Popup = 9
  PopupFocusReason = 4
  PreferDither = 64
  PreferredSize = 1
  PreventContextMenu = 4
  QueuedConnection = 2
  RadialGradientPattern = 16
  ReceivePartialGestures = 2
  RelativeSize = 1
  RepeatTile = 1
  ReplaceClip = 1
  RichText = 1
  RightArrow = 4
  RightButton = 2
  RightDockWidgetArea = 2
  RightSection = 5
  RightToLeft = 1
  RightToolBarArea = 2
  RoundCap = 32
  RoundJoin = 128
  RoundTile = 2
  SHIFT = 33554432
  Saturday = 6
  ScrollBarAlwaysOff = 1
  ScrollBarAlwaysOn = 2
  ScrollBarAsNeeded = 0
  Sheet = 5
  ShiftModifier = 33554432
  ShortcutFocusReason = 5
  SizeAllCursor = 9
  SizeBDiagCursor = 7
  SizeFDiagCursor = 8
  SizeHintRole = 13
  SizeHorCursor = 6
  SizeVerCursor = 5
  SmoothTransformation = 1
  SolidLine = 1
  SolidPattern = 1
  SplashScreen = 15
  SplitHCursor = 12
  SplitVCursor = 11
  SquareCap = 16
  StatusTipRole = 4
  StretchTile = 0
  StrongFocus = 11
  SubWindow = 18
  Sunday = 7
  SvgMiterJoin = 256
  SwipeGesture = 5
  SystemLocaleDate = 2
  SystemLocaleLongDate = 5
  SystemLocaleShortDate = 4
  TabFocus = 1
  TabFocusReason = 1
  TapAndHoldGesture = 2
  TapGesture = 1
  TargetMoveAction = 32770
  TextAlignmentRole = 7
  TextBrowserInteraction = 13
  TextColorRole = 9
  TextDate = 0
  TextDontClip = 512
  TextDontPrint = 16384
  TextEditable = 16
  TextEditorInteraction = 19
  TextExpandTabs = 1024
  TextHideMnemonic = 32768
  TextIncludeTrailingSpaces = 134217728
  TextJustificationForced = 65536
  TextSelectableByKeyboard = 2
  TextSelectableByMouse = 1
  TextShowMnemonic = 2048
  TextSingleLine = 256
  TextWordWrap = 4096
  TextWrapAnywhere = 8192
  TexturePattern = 24
  ThresholdAlphaDither = 0
  ThresholdDither = 32
  Thursday = 4
  TitleBarArea = 9
  Tool = 11
  ToolBarArea_Mask = 15
  ToolButtonFollowStyle = 4
  ToolButtonIconOnly = 0
  ToolButtonTextBesideIcon = 2
  ToolButtonTextOnly = 1
  ToolButtonTextUnderIcon = 3
  ToolTip = 13
  ToolTipRole = 3
  TopDockWidgetArea = 4
  TopLeftCorner = 0
  TopLeftSection = 2
  TopRightCorner = 1
  TopRightSection = 4
  TopSection = 3
  TopToolBarArea = 4
  TouchPointMoved = 2
  TouchPointPressed = 1
  TouchPointReleased = 8
  TouchPointStationary = 4
  TransparentMode = 0
  Tuesday = 2
  UI_AnimateCombo = 3
  UI_AnimateMenu = 1
  UI_AnimateToolBox = 6
  UI_AnimateTooltip = 4
  UI_FadeMenu = 2
  UI_FadeTooltip = 5
  UI_General = 0
  UNICODE_ACCEL = 0
  UTC = 1
  Unchecked = 0
  UniqueConnection = 128
  UniteClip = 3
  UpArrow = 1
  UpArrowCursor = 1
  UserRole = 32
  VerPattern = 10
  Vertical = 2
  VisualMoveStyle = 1
  WA_AcceptDrops = 78
  WA_AcceptTouchEvents = 121
  WA_AlwaysShowToolTips = 84
  WA_AttributeCount = 135
  WA_AutoOrientation = 130
  WA_CustomWhatsThis = 47
  WA_DeleteOnClose = 55
  WA_Disabled = 0
  WA_DontCreateNativeAncestors = 101
  WA_ForceDisabled = 32
  WA_ForceUpdatesDisabled = 59
  WA_GrabbedShortcut = 50
  WA_GroupLeader = 72
  WA_Hover = 74
  WA_InputMethodEnabled = 14
  WA_InputMethodTransparent = 75
  WA_InvalidSize = 45
  WA_KeyCompression = 33
  WA_KeyboardFocusChange = 77
  WA_LaidOut = 7
  WA_LayoutOnEntireRect = 48
  WA_LayoutUsesWidgetRect = 92
  WA_LockLandscapeOrientation = 129
  WA_LockPortraitOrientation = 128
  WA_MSWindowsUseDirect3D = 94
  WA_MacAlwaysShowToolWindow = 96
  WA_MacBrushedMetal = 46
  WA_MacFrameworkScaled = 117
  WA_MacMetalStyle = 46
  WA_MacMiniSize = 91
  WA_MacNoClickThrough = 12
  WA_MacNoShadow = 134
  WA_MacNormalSize = 89
  WA_MacOpaqueSizeGrip = 85
  WA_MacShowFocusRect = 88
  WA_MacSmallSize = 90
  WA_MacVariableSize = 102
  WA_Mapped = 11
  WA_MergeSoftkeys = 124
  WA_MergeSoftkeysRecursively = 125
  WA_MouseNoMask = 71
  WA_MouseTracking = 2
  WA_Moved = 43
  WA_NativeWindow = 100
  WA_NoChildEventsForParent = 58
  WA_NoChildEventsFromChildren = 39
  WA_NoMousePropagation = 73
  WA_NoMouseReplay = 54
  WA_NoSystemBackground = 9
  WA_NoX11EventCompression = 81
  WA_OpaquePaintEvent = 4
  WA_OutsideWSRange = 49
  WA_PaintOnScreen = 8
  WA_PaintOutsidePaintEvent = 13
  WA_PaintUnclipped = 52
  WA_PendingMoveEvent = 34
  WA_PendingResizeEvent = 35
  WA_PendingUpdate = 44
  WA_QuitOnClose = 76
  WA_Resized = 42
  WA_RightToLeft = 56
  WA_SetCursor = 38
  WA_SetFont = 37
  WA_SetLayoutDirection = 57
  WA_SetLocale = 87
  WA_SetPalette = 36
  WA_SetStyle = 86
  WA_SetWindowIcon = 53
  WA_ShowWithoutActivating = 98
  WA_StaticContents = 5
  WA_StyleSheet = 97
  WA_StyledBackground = 93
  WA_TintedBackground = 82
  WA_TouchPadAcceptSingleTouchEvents = 123
  WA_TranslucentBackground = 120
  WA_TransparentForMouseEvents = 51
  WA_UnderMouse = 1
  WA_UpdatesDisabled = 10
  WA_WState_CompressKeys = 61
  WA_WState_ConfigPending = 64
  WA_WState_Created = 60
  WA_WState_ExplicitShowHide = 69
  WA_WState_Hidden = 16
  WA_WState_InPaintEvent = 62
  WA_WState_OwnSizePolicy = 68
  WA_WState_Polished = 66
  WA_WState_Reparented = 63
  WA_WState_Visible = 15
  WA_WindowModified = 41
  WA_WindowPropagation = 80
  WA_X11DoNotAcceptFocus = 132
  WA_X11NetWmWindowTypeCombo = 115
  WA_X11NetWmWindowTypeDND = 116
  WA_X11NetWmWindowTypeDesktop = 104
  WA_X11NetWmWindowTypeDialog = 110
  WA_X11NetWmWindowTypeDock = 105
  WA_X11NetWmWindowTypeDropDownMenu = 111
  WA_X11NetWmWindowTypeMenu = 107
  WA_X11NetWmWindowTypeNotification = 114
  WA_X11NetWmWindowTypePopupMenu = 112
  WA_X11NetWmWindowTypeSplash = 109
  WA_X11NetWmWindowTypeToolBar = 106
  WA_X11NetWmWindowTypeToolTip = 113
  WA_X11NetWmWindowTypeUtility = 108
  WA_X11OpenGLOverlay = 83
  WDestructiveClose = 'TO BE DONE'
  WaitCursor = 3
  Wednesday = 3
  WhatsThisCursor = 15
  WhatsThisRole = 5
  WheelFocus = 15
  WhiteSpaceModeUndefined = -1
  WhiteSpaceNoWrap = 2
  WhiteSpaceNormal = 0
  WhiteSpacePre = 1
  Widget = 0
  WidgetShortcut = 0
  WidgetWithChildrenShortcut = 3
  WindingFill = 1
  Window = 1
  WindowActive = 8
  WindowCancelButtonHint = 1048576
  WindowCloseButtonHint = 134217728
  WindowContextHelpButtonHint = 65536
  WindowFullScreen = 4
  WindowMaximizeButtonHint = 32768
  WindowMaximized = 2
  WindowMinMaxButtonsHint = 49152
  WindowMinimizeButtonHint = 16384
  WindowMinimized = 1
  WindowModal = 1
  WindowNoState = 0
  WindowOkButtonHint = 524288
  WindowShadeButtonHint = 131072
  WindowShortcut = 1
  WindowSoftkeysRespondHint = -2147483648
  WindowSoftkeysVisibleHint = 1073741824
  WindowStaysOnBottomHint = 67108864
  WindowStaysOnTopHint = 262144
  WindowSystemMenuHint = 8192
  WindowTitleHint = 4096
  WindowType_Mask = 255
  X11BypassWindowManagerHint = 1024
  XAxis = 0
  XButton1 = 8
  XButton2 = 16
  YAxis = 1
  ZAxis = 2
  black = 2
  blue = 9
  color0 = 0
  color1 = 1
  cyan = 10
  darkBlue = 15
  darkCyan = 16
  darkGray = 4
  darkGreen = 14
  darkMagenta = 17
  darkRed = 13
  darkYellow = 18
  gray = 5
  green = 8
  lightGray = 6
  magenta = 11
  red = 7
  transparent = 19
  white = 3
  yellow = 12

class QtMsgType(_Mock):
  pass


class Signal(_Mock):
  pass


class pyqtBoundSignal(_Mock):
  pass


class pyqtProperty(_Mock):
  pass


class pyqtSignal(_Mock):
  pass


class pyqtWrapperType(_Mock):
  pass


