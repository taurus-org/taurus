from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       






class QDBus(_Mock):
  pass
  AutoDetect = 3
  Block = 1
  BlockWithGui = 2
  NoBlock = 0

class QDBusAbstractAdaptor(_Mock):
  pass


class QDBusAbstractInterface(_Mock):
  pass


class QDBusArgument(_Mock):
  pass


class QDBusConnection(_Mock):
  pass
  ActivationBus = 2
  ExportAdaptors = 1
  ExportAllContents = 4080
  ExportAllInvokables = 2176
  ExportAllProperties = 1088
  ExportAllSignal = 544
  ExportAllSignals = 544
  ExportAllSlots = 272
  ExportChildObjects = 4096
  ExportNonScriptableContents = 3840
  ExportNonScriptableInvokables = 2048
  ExportNonScriptableProperties = 1024
  ExportNonScriptableSignals = 512
  ExportNonScriptableSlots = 256
  ExportScriptableContents = 240
  ExportScriptableInvokables = 128
  ExportScriptableProperties = 64
  ExportScriptableSignals = 32
  ExportScriptableSlots = 16
  SessionBus = 0
  SystemBus = 1
  UnixFileDescriptorPassing = 1
  UnregisterNode = 0
  UnregisterTree = 1

class QDBusConnectionInterface(_Mock):
  pass
  AllowReplacement = 1
  DontAllowReplacement = 0
  DontQueueService = 0
  QueueService = 1
  ReplaceExistingService = 2
  ServiceNotRegistered = 0
  ServiceQueued = 2
  ServiceRegistered = 1

class QDBusError(_Mock):
  pass
  AccessDenied = 9
  AddressInUse = 13
  BadAddress = 6
  Disconnected = 14
  Failed = 2
  InternalError = 20
  InvalidArgs = 15
  InvalidInterface = 24
  InvalidMember = 25
  InvalidObjectPath = 23
  InvalidService = 22
  InvalidSignature = 18
  LimitsExceeded = 8
  NoError = 0
  NoMemory = 3
  NoNetwork = 12
  NoReply = 5
  NoServer = 10
  NotSupported = 7
  Other = 1
  ServiceUnknown = 4
  TimedOut = 17
  Timeout = 11
  UnknownInterface = 19
  UnknownMethod = 16
  UnknownObject = 21

class QDBusInterface(_Mock):
  pass


class QDBusMessage(_Mock):
  pass
  ErrorMessage = 3
  InvalidMessage = 0
  MethodCallMessage = 1
  ReplyMessage = 2
  SignalMessage = 4

class QDBusObjectPath(_Mock):
  pass


class QDBusPendingCall(_Mock):
  pass


class QDBusPendingCallWatcher(_Mock):
  pass


class QDBusPendingReply(_Mock):
  pass


class QDBusReply(_Mock):
  pass


class QDBusServiceWatcher(_Mock):
  pass
  WatchForOwnerChange = 3
  WatchForRegistration = 1
  WatchForUnregistration = 2

class QDBusSignature(_Mock):
  pass


class QDBusUnixFileDescriptor(_Mock):
  pass


class QDBusVariant(_Mock):
  pass


