from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       




QPyDeclarativeListProperty = 'QDeclarativeListProperty<QObject>'

class QDeclarativeComponent(_Mock):
  pass
  Error = 3
  Loading = 2
  Null = 0
  Ready = 1

class QDeclarativeContext(_Mock):
  pass


class QDeclarativeEngine(_Mock):
  pass
  CppOwnership = 0
  JavaScriptOwnership = 1

class QDeclarativeError(_Mock):
  pass


class QDeclarativeExpression(_Mock):
  pass


class QDeclarativeExtensionPlugin(_Mock):
  pass


class QDeclarativeImageProvider(_Mock):
  pass
  Image = 0
  Pixmap = 1

class QDeclarativeItem(_Mock):
  pass
  Bottom = 7
  BottomLeft = 6
  BottomRight = 8
  Center = 4
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  Left = 3
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  Right = 5
  SceneModal = 2
  Top = 1
  TopLeft = 0
  TopRight = 2
  UserType = 65536

class QDeclarativeListReference(_Mock):
  pass


class QDeclarativeNetworkAccessManagerFactory(_Mock):
  pass


class QDeclarativeParserStatus(_Mock):
  pass


class QDeclarativeProperty(_Mock):
  pass
  Invalid = 0
  InvalidCategory = 0
  List = 1
  Normal = 3
  Object = 2
  Property = 1
  SignalProperty = 2

class QDeclarativePropertyMap(_Mock):
  pass


class QDeclarativePropertyValueSource(_Mock):
  pass


class QDeclarativeScriptString(_Mock):
  pass


class QDeclarativeView(_Mock):
  pass
  AnchorUnderMouse = 2
  AnchorViewCenter = 1
  BoundingRectViewportUpdate = 4
  Box = 1
  CacheBackground = 1
  CacheNone = 0
  DontAdjustForAntialiasing = 4
  DontClipPainter = 1
  DontSavePainterState = 2
  DrawChildren = 2
  DrawWindowBackground = 1
  Error = 3
  FullViewportUpdate = 0
  HLine = 4
  IgnoreMask = 4
  Loading = 2
  MinimalViewportUpdate = 1
  NoAnchor = 0
  NoDrag = 0
  NoFrame = 0
  NoViewportUpdate = 3
  Null = 0
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  Raised = 32
  Ready = 1
  RubberBandDrag = 2
  ScrollHandDrag = 1
  Shadow_Mask = 240
  Shape_Mask = 15
  SizeRootObjectToView = 1
  SizeViewToRootObject = 0
  SmartViewportUpdate = 2
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QPyDeclarativePropertyValueSource(_Mock):
  pass


