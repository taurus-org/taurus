from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       






class QDomAttr(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomCDATASection(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomCharacterData(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomComment(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomDocument(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomDocumentFragment(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomDocumentType(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomElement(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomEntity(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomEntityReference(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomImplementation(_Mock):
  pass
  AcceptInvalidChars = 0
  DropInvalidChars = 1
  ReturnNullNode = 2

class QDomNamedNodeMap(_Mock):
  pass


class QDomNode(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomNodeList(_Mock):
  pass


class QDomNotation(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomProcessingInstruction(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomText(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QXmlAttributes(_Mock):
  pass


class QXmlContentHandler(_Mock):
  pass


class QXmlDTDHandler(_Mock):
  pass


class QXmlDeclHandler(_Mock):
  pass


class QXmlDefaultHandler(_Mock):
  pass


class QXmlEntityResolver(_Mock):
  pass


class QXmlErrorHandler(_Mock):
  pass


class QXmlInputSource(_Mock):
  pass
  EndOfData = 65534
  EndOfDocument = 65535

class QXmlLexicalHandler(_Mock):
  pass


class QXmlLocator(_Mock):
  pass


class QXmlNamespaceSupport(_Mock):
  pass


class QXmlParseException(_Mock):
  pass


class QXmlReader(_Mock):
  pass


class QXmlSimpleReader(_Mock):
  pass


