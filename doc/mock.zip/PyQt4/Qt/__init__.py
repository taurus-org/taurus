from __future__ import print_function



class _MockMeta(type):
    def __getattr__(self, name):
        return _Mock()

class _Mock(object):
    __metaclass__ = _MockMeta
    def __init__(self, *a, **kw):
        object.__init__(self)
        for k,v in kw.iteritems():
            setattr(self, k, v)
    def __getattr__(*a, **kw): return _Mock()
    def __call__(*a, **kw): return _Mock()
    def __getitem__(*a, **kw): return _Mock()
    def __int__(*a, **kw): return 1
    def __contains__(*a, **kw): return False
    def __len__(*a, **kw): return 1
    def __iter__(*a, **kw): return iter([])
    def __exit__(*a, **kw): return False
    def __complex__(*a, **kw): return 1j
    def __float__(*a, **kw): return 1.0
    def __bool__(*a, **kw): return True
    def __nonzero__(*a, **kw): return True
    def __oct__(*a, **kw): return 1
    def __hex__(*a, **kw): return 0x1
    def __long__(*a, **kw): return long(1)
    def __index__(*a, **kw): return 1       


PYQT_CONFIGURATION = _Mock()

QT_TRANSLATE_NOOP = _Mock()

QT_TR_NOOP = _Mock()

QT_TR_NOOP_UTF8 = _Mock()

Q_ARG = _Mock()

Q_CLASSINFO = _Mock()

Q_ENUMS = _Mock()

Q_FLAGS = _Mock()

Q_RETURN_ARG = _Mock()

SIGNAL = _Mock()

SLOT = _Mock()

Slot = _Mock()

bin = _Mock()

bom = _Mock()

center = _Mock()

dec = _Mock()

endl = _Mock()

fixed = _Mock()

flush = _Mock()

forcepoint = _Mock()

forcesign = _Mock()

hex = _Mock()

left = _Mock()

lowercasebase = _Mock()

lowercasedigits = _Mock()

noforcepoint = _Mock()

noforcesign = _Mock()

noshowbase = _Mock()

oct = _Mock()

pyqtPickleProtocol = _Mock()

pyqtRemoveInputHook = _Mock()

pyqtRestoreInputHook = _Mock()

pyqtSetPickleProtocol = _Mock()

pyqtSignature = _Mock()

pyqtSlot = _Mock()

qAbs = _Mock()

qAddPostRoutine = _Mock()

qAlpha = _Mock()

qApp = _Mock()

qBlue = _Mock()

qChecksum = _Mock()

qCompress = _Mock()

qCritical = _Mock()

qDebug = _Mock()

qDrawBorderPixmap = _Mock()

qDrawPlainRect = _Mock()

qDrawShadeLine = _Mock()

qDrawShadePanel = _Mock()

qDrawShadeRect = _Mock()

qDrawWinButton = _Mock()

qDrawWinPanel = _Mock()

qErrnoWarning = _Mock()

qFatal = _Mock()

qFuzzyCompare = _Mock()

qGray = _Mock()

qGreen = _Mock()

qInf = _Mock()

qInstallMsgHandler = _Mock()

qIsFinite = _Mock()

qIsGray = _Mock()

qIsInf = _Mock()

qIsNaN = _Mock()

qIsNull = _Mock()

qQNaN = _Mock()

qRed = _Mock()

qRegisterResourceData = _Mock()

qRemovePostRoutine = _Mock()

qRgb = _Mock()

qRgba = _Mock()

qRound = _Mock()

qRound64 = _Mock()

qSNaN = _Mock()

qScriptConnect = _Mock()

qScriptDisconnect = _Mock()

qSetFieldWidth = _Mock()

qSetPadChar = _Mock()

qSetRealNumberPrecision = _Mock()

qSharedBuild = _Mock()

qSwap = _Mock()

qUncompress = _Mock()

qUnregisterResourceData = _Mock()

qVersion = _Mock()

qWarning = _Mock()

qWebKitMajorVersion = _Mock()

qWebKitMinorVersion = _Mock()

qWebKitVersion = _Mock()

qrand = _Mock()

qsrand = _Mock()

qt_x11_wait_for_window_manager = _Mock()

reset = _Mock()

right = _Mock()

scientific = _Mock()

showbase = _Mock()

uppercasebase = _Mock()

uppercasedigits = _Mock()

ws = _Mock()

PYQT_VERSION = 264962

PYQT_VERSION_STR = '4.11.2'

QPyDeclarativeListProperty = 'QDeclarativeListProperty<QObject>'

QT_VERSION = 264198

QT_VERSION_STR = '4.8.6'

QtCriticalMsg = 2

QtDebugMsg = 0

QtFatalMsg = 3

QtSystemMsg = 2

QtWarningMsg = 1

class Display(_Mock):
  pass


class Property(_Mock):
  pass


class QAbstractAnimation(_Mock):
  pass
  Backward = 1
  DeleteWhenStopped = 1
  Forward = 0
  KeepWhenStopped = 0
  Paused = 1
  Running = 2
  Stopped = 0

class QAbstractButton(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QAbstractEventDispatcher(_Mock):
  pass


class QAbstractExtensionFactory(_Mock):
  pass


class QAbstractExtensionManager(_Mock):
  pass


class QAbstractFileEngine(_Mock):
  pass
  AbsoluteName = 3
  AbsolutePathName = 4
  AccessTime = 2
  BaseName = 1
  BundleName = 8
  BundleType = 524288
  CanonicalName = 6
  CanonicalPathName = 7
  CreationTime = 0
  DefaultName = 0
  DirectoryType = 262144
  ExeGroupPerm = 16
  ExeOtherPerm = 1
  ExeOwnerPerm = 4096
  ExeUserPerm = 256
  ExistsFlag = 4194304
  FileInfoAll = 268435455
  FileType = 131072
  FlagsMask = 267386880
  HiddenFlag = 1048576
  LinkName = 5
  LinkType = 65536
  LocalDiskFlag = 2097152
  ModificationTime = 1
  OwnerGroup = 1
  OwnerUser = 0
  PathName = 2
  PermsMask = 65535
  ReadGroupPerm = 64
  ReadOtherPerm = 4
  ReadOwnerPerm = 16384
  ReadUserPerm = 1024
  Refresh = 16777216
  RootFlag = 8388608
  TypesMask = 983040
  WriteGroupPerm = 32
  WriteOtherPerm = 2
  WriteOwnerPerm = 8192
  WriteUserPerm = 512

class QAbstractFileEngineHandler(_Mock):
  pass


class QAbstractFileEngineIterator(_Mock):
  pass


class QAbstractFormBuilder(_Mock):
  pass


class QAbstractGraphicsShapeItem(_Mock):
  pass
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QAbstractItemDelegate(_Mock):
  pass
  EditNextItem = 1
  EditPreviousItem = 2
  NoHint = 0
  RevertModelCache = 4
  SubmitModelCache = 3

class QAbstractItemModel(_Mock):
  pass


class QAbstractItemView(_Mock):
  pass
  AboveItem = 1
  AllEditTriggers = 31
  AnimatingState = 6
  AnyKeyPressed = 16
  BelowItem = 2
  Box = 1
  CollapsingState = 5
  ContiguousSelection = 4
  CurrentChanged = 1
  DoubleClicked = 2
  DragDrop = 3
  DragOnly = 1
  DragSelectingState = 2
  DraggingState = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  DropOnly = 2
  EditKeyPressed = 8
  EditingState = 3
  EnsureVisible = 0
  ExpandingState = 4
  ExtendedSelection = 3
  HLine = 4
  IgnoreMask = 4
  InternalMove = 4
  MoveDown = 1
  MoveEnd = 5
  MoveHome = 4
  MoveLeft = 2
  MoveNext = 8
  MovePageDown = 7
  MovePageUp = 6
  MovePrevious = 9
  MoveRight = 3
  MoveUp = 0
  MultiSelection = 2
  NoDragDrop = 0
  NoEditTriggers = 0
  NoFrame = 0
  NoSelection = 0
  NoState = 0
  OnItem = 0
  OnViewport = 3
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  PositionAtBottom = 2
  PositionAtCenter = 3
  PositionAtTop = 1
  Raised = 32
  ScrollPerItem = 0
  ScrollPerPixel = 1
  SelectColumns = 2
  SelectItems = 0
  SelectRows = 1
  SelectedClicked = 4
  Shadow_Mask = 240
  Shape_Mask = 15
  SingleSelection = 1
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QAbstractListModel(_Mock):
  pass


class QAbstractMessageHandler(_Mock):
  pass


class QAbstractNetworkCache(_Mock):
  pass


class QAbstractPrintDialog(_Mock):
  pass
  Accepted = 1
  AllPages = 0
  CurrentPage = 3
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  None_ = 0
  PageRange = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  PrintCollateCopies = 16
  PrintCurrentPage = 64
  PrintPageRange = 4
  PrintSelection = 2
  PrintShowPageSize = 8
  PrintToFile = 1
  Rejected = 0
  Selection = 1

class QAbstractProxyModel(_Mock):
  pass


class QAbstractScrollArea(_Mock):
  pass
  Box = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  HLine = 4
  IgnoreMask = 4
  NoFrame = 0
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  Raised = 32
  Shadow_Mask = 240
  Shape_Mask = 15
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QAbstractSlider(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  SliderMove = 7
  SliderNoAction = 0
  SliderOrientationChange = 1
  SliderPageStepAdd = 3
  SliderPageStepSub = 4
  SliderRangeChange = 0
  SliderSingleStepAdd = 1
  SliderSingleStepSub = 2
  SliderStepsChange = 2
  SliderToMaximum = 6
  SliderToMinimum = 5
  SliderValueChange = 3

class QAbstractSocket(_Mock):
  pass
  AddressInUseError = 8
  Append = 4
  BoundState = 4
  ClosingState = 6
  ConnectedState = 3
  ConnectingState = 2
  ConnectionRefusedError = 0
  DatagramTooLargeError = 6
  HostLookupState = 1
  HostNotFoundError = 2
  IPv4Protocol = 0
  IPv6Protocol = 1
  KeepAliveOption = 1
  ListeningState = 5
  LowDelayOption = 0
  MulticastLoopbackOption = 3
  MulticastTtlOption = 2
  NetworkError = 7
  NotOpen = 0
  ProxyAuthenticationRequiredError = 12
  ProxyConnectionClosedError = 15
  ProxyConnectionRefusedError = 14
  ProxyConnectionTimeoutError = 16
  ProxyNotFoundError = 17
  ProxyProtocolError = 18
  ReadOnly = 1
  ReadWrite = 3
  RemoteHostClosedError = 1
  SocketAccessError = 3
  SocketAddressNotAvailableError = 9
  SocketResourceError = 4
  SocketTimeoutError = 5
  SslHandshakeFailedError = 13
  TcpSocket = 0
  Text = 16
  Truncate = 8
  UdpSocket = 1
  Unbuffered = 32
  UnconnectedState = 0
  UnfinishedSocketOperationError = 11
  UnknownNetworkLayerProtocol = -1
  UnknownSocketError = -1
  UnknownSocketType = -1
  UnsupportedSocketOperationError = 10
  WriteOnly = 2

class QAbstractSpinBox(_Mock):
  pass
  CorrectToNearestValue = 1
  CorrectToPreviousValue = 0
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  NoButtons = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  PlusMinus = 1
  StepDownEnabled = 2
  StepNone = 0
  StepUpEnabled = 1
  UpDownArrows = 0

class QAbstractState(_Mock):
  pass


class QAbstractTableModel(_Mock):
  pass


class QAbstractTextDocumentLayout(_Mock):
  pass


class QAbstractTransition(_Mock):
  pass


class QAbstractUriResolver(_Mock):
  pass


class QAbstractXmlNodeModel(_Mock):
  pass
  FirstChild = 1
  NextSibling = 3
  Parent = 0
  PreviousSibling = 2

class QAbstractXmlReceiver(_Mock):
  pass


class QAction(_Mock):
  pass
  AboutQtRole = 3
  AboutRole = 4
  ApplicationSpecificRole = 2
  HighPriority = 256
  Hover = 1
  LowPriority = 0
  NegativeSoftKey = 2
  NoRole = 0
  NoSoftKey = 0
  NormalPriority = 128
  PositiveSoftKey = 1
  PreferencesRole = 5
  QuitRole = 6
  SelectSoftKey = 3
  TextHeuristicRole = 1
  Trigger = 0

class QActionEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QActionGroup(_Mock):
  pass


class QAnimationGroup(_Mock):
  pass
  Backward = 1
  DeleteWhenStopped = 1
  Forward = 0
  KeepWhenStopped = 0
  Paused = 1
  Running = 2
  Stopped = 0

class QApplication(_Mock):
  pass
  CodecForTr = 0
  CustomColor = 1
  DefaultCodec = 0
  GuiClient = 1
  GuiServer = 2
  ManyColor = 2
  NormalColor = 0
  Tty = 0
  UnicodeUTF8 = 1

class QAssistantClient(_Mock):
  pass


class QAuthenticator(_Mock):
  pass


class QBasicTimer(_Mock):
  pass


class QBitArray(_Mock):
  pass


class QBitmap(_Mock):
  pass
  ExplicitlyShared = 1
  ImplicitlyShared = 0
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QBoxLayout(_Mock):
  pass
  BottomToTop = 3
  Down = 2
  LeftToRight = 0
  RightToLeft = 1
  SetDefaultConstraint = 0
  SetFixedSize = 3
  SetMaximumSize = 4
  SetMinAndMaxSize = 5
  SetMinimumSize = 2
  SetNoConstraint = 1
  TopToBottom = 2
  Up = 3

class QBrush(_Mock):
  pass


class QBuffer(_Mock):
  pass
  Append = 4
  NotOpen = 0
  ReadOnly = 1
  ReadWrite = 3
  Text = 16
  Truncate = 8
  Unbuffered = 32
  WriteOnly = 2

class QButtonGroup(_Mock):
  pass


class QByteArray(_Mock):
  pass


class QByteArrayMatcher(_Mock):
  pass


class QCalendarWidget(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  ISOWeekNumbers = 1
  IgnoreMask = 4
  LongDayNames = 3
  NoHorizontalHeader = 0
  NoSelection = 0
  NoVerticalHeader = 0
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  ShortDayNames = 2
  SingleLetterDayNames = 1
  SingleSelection = 1

class QChar(_Mock):
  pass
  ByteOrderMark = 65279
  ByteOrderSwapped = 65534
  Canonical = 1
  Center = 3
  Circle = 8
  Combining_Above = 230
  Combining_AboveAttached = 214
  Combining_AboveLeft = 228
  Combining_AboveLeftAttached = 212
  Combining_AboveRight = 232
  Combining_AboveRightAttached = 216
  Combining_Below = 220
  Combining_BelowAttached = 202
  Combining_BelowLeft = 218
  Combining_BelowLeftAttached = 200
  Combining_BelowRight = 222
  Combining_BelowRightAttached = 204
  Combining_DoubleAbove = 234
  Combining_DoubleBelow = 233
  Combining_IotaSubscript = 240
  Combining_Left = 224
  Combining_LeftAttached = 208
  Combining_Right = 226
  Combining_RightAttached = 210
  Compat = 16
  DirAL = 13
  DirAN = 5
  DirB = 7
  DirBN = 18
  DirCS = 6
  DirEN = 2
  DirES = 3
  DirET = 4
  DirL = 0
  DirLRE = 11
  DirLRO = 12
  DirNSM = 17
  DirON = 10
  DirPDF = 16
  DirR = 1
  DirRLE = 14
  DirRLO = 15
  DirS = 8
  DirWS = 9
  Dual = 1
  Final = 6
  Font = 2
  Fraction = 17
  Initial = 4
  Isolated = 7
  Letter_Lowercase = 16
  Letter_Modifier = 18
  Letter_Other = 19
  Letter_Titlecase = 17
  Letter_Uppercase = 15
  LineSeparator = 8232
  Mark_Enclosing = 3
  Mark_NonSpacing = 1
  Mark_SpacingCombining = 2
  Medial = 5
  Narrow = 13
  Nbsp = 160
  NoBreak = 3
  NoCategory = 0
  NoDecomposition = 0
  Null = 0
  Number_DecimalDigit = 4
  Number_Letter = 5
  Number_Other = 6
  ObjectReplacementCharacter = 65532
  OtherJoining = 0
  Other_Control = 10
  Other_Format = 11
  Other_NotAssigned = 14
  Other_PrivateUse = 13
  Other_Surrogate = 12
  ParagraphSeparator = 8233
  Punctuation_Close = 23
  Punctuation_Connector = 20
  Punctuation_Dash = 21
  Punctuation_Dask = 21
  Punctuation_FinalQuote = 25
  Punctuation_InitialQuote = 24
  Punctuation_Open = 22
  Punctuation_Other = 26
  ReplacementCharacter = 65533
  Right = 2
  Separator_Line = 8
  Separator_Paragraph = 9
  Separator_Space = 7
  Small = 14
  Square = 15
  Sub = 10
  Super = 9
  Symbol_Currency = 28
  Symbol_Math = 27
  Symbol_Modifier = 29
  Symbol_Other = 30
  Unicode_1_1 = 1
  Unicode_2_0 = 2
  Unicode_2_1_2 = 3
  Unicode_3_0 = 4
  Unicode_3_1 = 5
  Unicode_3_2 = 6
  Unicode_4_0 = 7
  Unicode_4_1 = 8
  Unicode_5_0 = 9
  Unicode_Unassigned = 0
  Vertical = 11
  Wide = 12

class QCheckBox(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QChildEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QClipboard(_Mock):
  pass
  Clipboard = 0
  FindBuffer = 2
  Selection = 1

class QCloseEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QColor(_Mock):
  pass
  Cmyk = 3
  Hsl = 4
  Hsv = 2
  Invalid = 0
  Rgb = 1

class QColorDialog(_Mock):
  pass
  Accepted = 1
  DontUseNativeDialog = 4
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  NoButtons = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Rejected = 0
  ShowAlphaChannel = 1

class QColumnView(_Mock):
  pass
  AboveItem = 1
  AllEditTriggers = 31
  AnimatingState = 6
  AnyKeyPressed = 16
  BelowItem = 2
  Box = 1
  CollapsingState = 5
  ContiguousSelection = 4
  CurrentChanged = 1
  DoubleClicked = 2
  DragDrop = 3
  DragOnly = 1
  DragSelectingState = 2
  DraggingState = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  DropOnly = 2
  EditKeyPressed = 8
  EditingState = 3
  EnsureVisible = 0
  ExpandingState = 4
  ExtendedSelection = 3
  HLine = 4
  IgnoreMask = 4
  InternalMove = 4
  MoveDown = 1
  MoveEnd = 5
  MoveHome = 4
  MoveLeft = 2
  MoveNext = 8
  MovePageDown = 7
  MovePageUp = 6
  MovePrevious = 9
  MoveRight = 3
  MoveUp = 0
  MultiSelection = 2
  NoDragDrop = 0
  NoEditTriggers = 0
  NoFrame = 0
  NoSelection = 0
  NoState = 0
  OnItem = 0
  OnViewport = 3
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  PositionAtBottom = 2
  PositionAtCenter = 3
  PositionAtTop = 1
  Raised = 32
  ScrollPerItem = 0
  ScrollPerPixel = 1
  SelectColumns = 2
  SelectItems = 0
  SelectRows = 1
  SelectedClicked = 4
  Shadow_Mask = 240
  Shape_Mask = 15
  SingleSelection = 1
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QComboBox(_Mock):
  pass
  AdjustToContents = 0
  AdjustToContentsOnFirstShow = 1
  AdjustToMinimumContentsLength = 2
  AdjustToMinimumContentsLengthWithIcon = 3
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  InsertAfterCurrent = 4
  InsertAlphabetically = 6
  InsertAtBottom = 3
  InsertAtCurrent = 2
  InsertAtTop = 1
  InsertBeforeCurrent = 5
  NoInsert = 0
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QCommandLinkButton(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QCommonStyle(_Mock):
  pass
  CC_ComboBox = 1
  CC_CustomBase = -268435456
  CC_Dial = 7
  CC_GroupBox = 8
  CC_MdiControls = 9
  CC_Q3ListView = 6
  CC_ScrollBar = 2
  CC_Slider = 3
  CC_SpinBox = 0
  CC_TitleBar = 5
  CC_ToolButton = 4
  CE_CheckBox = 3
  CE_CheckBoxLabel = 4
  CE_ColumnViewGrip = 45
  CE_ComboBoxLabel = 40
  CE_CustomBase = -268435456
  CE_DockWidgetTitle = 31
  CE_FocusFrame = 39
  CE_Header = 23
  CE_HeaderEmptyArea = 44
  CE_HeaderLabel = 25
  CE_HeaderSection = 24
  CE_ItemViewItem = 46
  CE_MenuBarEmptyArea = 21
  CE_MenuBarItem = 20
  CE_MenuEmptyArea = 19
  CE_MenuHMargin = 17
  CE_MenuItem = 14
  CE_MenuScroller = 15
  CE_MenuTearoff = 18
  CE_MenuVMargin = 16
  CE_ProgressBar = 10
  CE_ProgressBarContents = 12
  CE_ProgressBarGroove = 11
  CE_ProgressBarLabel = 13
  CE_PushButton = 0
  CE_PushButtonBevel = 1
  CE_PushButtonLabel = 2
  CE_Q3DockWindowEmptyArea = 26
  CE_RadioButton = 5
  CE_RadioButtonLabel = 6
  CE_RubberBand = 30
  CE_ScrollBarAddLine = 32
  CE_ScrollBarAddPage = 34
  CE_ScrollBarFirst = 37
  CE_ScrollBarLast = 38
  CE_ScrollBarSlider = 36
  CE_ScrollBarSubLine = 33
  CE_ScrollBarSubPage = 35
  CE_ShapedFrame = 47
  CE_SizeGrip = 28
  CE_Splitter = 29
  CE_TabBarTab = 7
  CE_TabBarTabLabel = 9
  CE_TabBarTabShape = 8
  CE_ToolBar = 41
  CE_ToolBoxTab = 27
  CE_ToolBoxTabLabel = 43
  CE_ToolBoxTabShape = 42
  CE_ToolButtonLabel = 22
  CT_CheckBox = 1
  CT_ComboBox = 4
  CT_CustomBase = -268435456
  CT_DialogButtons = 20
  CT_GroupBox = 22
  CT_HeaderSection = 21
  CT_ItemViewItem = 24
  CT_LineEdit = 16
  CT_MdiControls = 23
  CT_Menu = 11
  CT_MenuBar = 10
  CT_MenuBarItem = 9
  CT_MenuItem = 8
  CT_ProgressBar = 7
  CT_PushButton = 0
  CT_Q3DockWindow = 6
  CT_Q3Header = 15
  CT_RadioButton = 2
  CT_ScrollBar = 14
  CT_SizeGrip = 18
  CT_Slider = 13
  CT_SpinBox = 17
  CT_Splitter = 5
  CT_TabBarTab = 12
  CT_TabWidget = 19
  CT_ToolButton = 3
  PE_CustomBase = 251658240
  PE_Frame = 5
  PE_FrameButtonBevel = 15
  PE_FrameButtonTool = 16
  PE_FrameDefaultButton = 6
  PE_FrameDockWidget = 7
  PE_FrameFocusRect = 8
  PE_FrameGroupBox = 9
  PE_FrameLineEdit = 10
  PE_FrameMenu = 11
  PE_FrameStatusBar = 12
  PE_FrameStatusBarItem = 12
  PE_FrameTabBarBase = 17
  PE_FrameTabWidget = 13
  PE_FrameWindow = 14
  PE_IndicatorArrowDown = 24
  PE_IndicatorArrowLeft = 25
  PE_IndicatorArrowRight = 26
  PE_IndicatorArrowUp = 27
  PE_IndicatorBranch = 28
  PE_IndicatorButtonDropDown = 29
  PE_IndicatorCheckBox = 31
  PE_IndicatorColumnViewArrow = 47
  PE_IndicatorDockWidgetResizeHandle = 32
  PE_IndicatorHeaderArrow = 33
  PE_IndicatorItemViewItemCheck = 30
  PE_IndicatorItemViewItemDrop = 48
  PE_IndicatorMenuCheckMark = 34
  PE_IndicatorProgressChunk = 35
  PE_IndicatorRadioButton = 36
  PE_IndicatorSpinDown = 37
  PE_IndicatorSpinMinus = 38
  PE_IndicatorSpinPlus = 39
  PE_IndicatorSpinUp = 40
  PE_IndicatorTabClose = 52
  PE_IndicatorTabTear = 44
  PE_IndicatorToolBarHandle = 41
  PE_IndicatorToolBarSeparator = 42
  PE_IndicatorViewItemCheck = 30
  PE_PanelButtonBevel = 19
  PE_PanelButtonCommand = 18
  PE_PanelButtonTool = 20
  PE_PanelItemViewItem = 49
  PE_PanelItemViewRow = 50
  PE_PanelLineEdit = 23
  PE_PanelMenu = 53
  PE_PanelMenuBar = 21
  PE_PanelScrollAreaCorner = 45
  PE_PanelStatusBar = 51
  PE_PanelTipLabel = 43
  PE_PanelToolBar = 22
  PE_Q3CheckListController = 0
  PE_Q3CheckListExclusiveIndicator = 1
  PE_Q3CheckListIndicator = 2
  PE_Q3DockWindowSeparator = 3
  PE_Q3Separator = 4
  PE_Widget = 46
  PM_ButtonDefaultIndicator = 1
  PM_ButtonIconSize = 77
  PM_ButtonMargin = 0
  PM_ButtonShiftHorizontal = 3
  PM_ButtonShiftVertical = 4
  PM_CheckBoxLabelSpacing = 72
  PM_CheckListButtonSize = 41
  PM_CheckListControllerSize = 42
  PM_ComboBoxFrameWidth = 7
  PM_CustomBase = -268435456
  PM_DefaultChildMargin = 62
  PM_DefaultFrameWidth = 5
  PM_DefaultLayoutSpacing = 63
  PM_DefaultTopLevelMargin = 61
  PM_DialogButtonsButtonHeight = 45
  PM_DialogButtonsButtonWidth = 44
  PM_DialogButtonsSeparator = 43
  PM_DockWidgetFrameWidth = 18
  PM_DockWidgetHandleExtent = 17
  PM_DockWidgetSeparatorExtent = 16
  PM_DockWidgetTitleBarButtonMargin = 78
  PM_DockWidgetTitleMargin = 75
  PM_ExclusiveIndicatorHeight = 40
  PM_ExclusiveIndicatorWidth = 39
  PM_FocusFrameHMargin = 70
  PM_FocusFrameVMargin = 69
  PM_HeaderGripMargin = 50
  PM_HeaderMargin = 48
  PM_HeaderMarkSize = 49
  PM_IconViewIconSize = 66
  PM_IndicatorHeight = 38
  PM_IndicatorWidth = 37
  PM_LargeIconSize = 68
  PM_LayoutBottomMargin = 83
  PM_LayoutHorizontalSpacing = 84
  PM_LayoutLeftMargin = 80
  PM_LayoutRightMargin = 82
  PM_LayoutTopMargin = 81
  PM_LayoutVerticalSpacing = 85
  PM_ListViewIconSize = 65
  PM_MDIFrameWidth = 46
  PM_MDIMinimizedWidth = 47
  PM_MaximumDragDistance = 8
  PM_MdiSubWindowFrameWidth = 46
  PM_MdiSubWindowMinimizedWidth = 47
  PM_MenuBarHMargin = 36
  PM_MenuBarItemSpacing = 34
  PM_MenuBarPanelWidth = 33
  PM_MenuBarVMargin = 35
  PM_MenuButtonIndicator = 2
  PM_MenuDesktopFrameWidth = 32
  PM_MenuHMargin = 28
  PM_MenuPanelWidth = 30
  PM_MenuScrollerHeight = 27
  PM_MenuTearoffHeight = 31
  PM_MenuVMargin = 29
  PM_MessageBoxIconSize = 76
  PM_ProgressBarChunkWidth = 24
  PM_RadioButtonLabelSpacing = 79
  PM_ScrollBarExtent = 9
  PM_ScrollBarSliderMin = 10
  PM_ScrollView_ScrollBarSpacing = 90
  PM_SizeGripSize = 74
  PM_SliderControlThickness = 12
  PM_SliderLength = 13
  PM_SliderSpaceAvailable = 15
  PM_SliderThickness = 11
  PM_SliderTickmarkOffset = 14
  PM_SmallIconSize = 67
  PM_SpinBoxFrameWidth = 6
  PM_SpinBoxSliderHeight = 60
  PM_SplitterWidth = 25
  PM_SubMenuOverlap = 91
  PM_TabBarBaseHeight = 22
  PM_TabBarBaseOverlap = 23
  PM_TabBarIconSize = 73
  PM_TabBarScrollButtonWidth = 53
  PM_TabBarTabHSpace = 20
  PM_TabBarTabOverlap = 19
  PM_TabBarTabShiftHorizontal = 51
  PM_TabBarTabShiftVertical = 52
  PM_TabBarTabVSpace = 21
  PM_TabBar_ScrollButtonOverlap = 86
  PM_TabCloseIndicatorHeight = 89
  PM_TabCloseIndicatorWidth = 88
  PM_TextCursorWidth = 87
  PM_TitleBarHeight = 26
  PM_ToolBarExtensionExtent = 59
  PM_ToolBarFrameWidth = 54
  PM_ToolBarHandleExtent = 55
  PM_ToolBarIconSize = 64
  PM_ToolBarItemMargin = 57
  PM_ToolBarItemSpacing = 56
  PM_ToolBarSeparatorExtent = 58
  PM_ToolTipLabelFrameWidth = 71
  RSIP_OnMouseClick = 1
  RSIP_OnMouseClickAndAlreadyFocused = 0
  SC_All = -1
  SC_ComboBoxArrow = 4
  SC_ComboBoxEditField = 2
  SC_ComboBoxFrame = 1
  SC_ComboBoxListBoxPopup = 8
  SC_CustomBase = -268435456
  SC_DialGroove = 1
  SC_DialHandle = 2
  SC_DialTickmarks = 4
  SC_GroupBoxCheckBox = 1
  SC_GroupBoxContents = 4
  SC_GroupBoxFrame = 8
  SC_GroupBoxLabel = 2
  SC_MdiCloseButton = 4
  SC_MdiMinButton = 1
  SC_MdiNormalButton = 2
  SC_None = 0
  SC_Q3ListView = 1
  SC_Q3ListViewBranch = 2
  SC_Q3ListViewExpand = 4
  SC_ScrollBarAddLine = 1
  SC_ScrollBarAddPage = 4
  SC_ScrollBarFirst = 16
  SC_ScrollBarGroove = 128
  SC_ScrollBarLast = 32
  SC_ScrollBarSlider = 64
  SC_ScrollBarSubLine = 2
  SC_ScrollBarSubPage = 8
  SC_SliderGroove = 1
  SC_SliderHandle = 2
  SC_SliderTickmarks = 4
  SC_SpinBoxDown = 2
  SC_SpinBoxEditField = 8
  SC_SpinBoxFrame = 4
  SC_SpinBoxUp = 1
  SC_TitleBarCloseButton = 8
  SC_TitleBarContextHelpButton = 128
  SC_TitleBarLabel = 256
  SC_TitleBarMaxButton = 4
  SC_TitleBarMinButton = 2
  SC_TitleBarNormalButton = 16
  SC_TitleBarShadeButton = 32
  SC_TitleBarSysMenu = 1
  SC_TitleBarUnshadeButton = 64
  SC_ToolButton = 1
  SC_ToolButtonMenu = 2
  SE_CheckBoxClickRect = 5
  SE_CheckBoxContents = 3
  SE_CheckBoxFocusRect = 4
  SE_CheckBoxIndicator = 2
  SE_CheckBoxLayoutItem = 42
  SE_ComboBoxFocusRect = 10
  SE_ComboBoxLayoutItem = 43
  SE_CustomBase = -268435456
  SE_DateTimeEditLayoutItem = 44
  SE_DialogButtonAbort = 21
  SE_DialogButtonAccept = 16
  SE_DialogButtonAll = 20
  SE_DialogButtonApply = 18
  SE_DialogButtonBoxLayoutItem = 45
  SE_DialogButtonCustom = 24
  SE_DialogButtonHelp = 19
  SE_DialogButtonIgnore = 22
  SE_DialogButtonReject = 17
  SE_DialogButtonRetry = 23
  SE_DockWidgetCloseButton = 38
  SE_DockWidgetFloatButton = 39
  SE_DockWidgetIcon = 41
  SE_DockWidgetTitleBarText = 40
  SE_FrameContents = 37
  SE_FrameLayoutItem = 53
  SE_GroupBoxLayoutItem = 54
  SE_HeaderArrow = 27
  SE_HeaderLabel = 26
  SE_ItemViewItemCheckIndicator = 33
  SE_ItemViewItemDecoration = 56
  SE_ItemViewItemFocusRect = 58
  SE_ItemViewItemText = 57
  SE_LabelLayoutItem = 46
  SE_LineEditContents = 36
  SE_ProgressBarContents = 14
  SE_ProgressBarGroove = 13
  SE_ProgressBarLabel = 15
  SE_ProgressBarLayoutItem = 47
  SE_PushButtonContents = 0
  SE_PushButtonFocusRect = 1
  SE_PushButtonLayoutItem = 48
  SE_Q3DockWindowHandleRect = 12
  SE_RadioButtonClickRect = 9
  SE_RadioButtonContents = 7
  SE_RadioButtonFocusRect = 8
  SE_RadioButtonIndicator = 6
  SE_RadioButtonLayoutItem = 49
  SE_ShapedFrameContents = 62
  SE_SliderFocusRect = 11
  SE_SliderLayoutItem = 50
  SE_SpinBoxLayoutItem = 51
  SE_TabBarTabLeftButton = 59
  SE_TabBarTabRightButton = 60
  SE_TabBarTabText = 61
  SE_TabBarTearIndicator = 34
  SE_TabWidgetLayoutItem = 55
  SE_TabWidgetLeftCorner = 31
  SE_TabWidgetRightCorner = 32
  SE_TabWidgetTabBar = 28
  SE_TabWidgetTabContents = 30
  SE_TabWidgetTabPane = 29
  SE_ToolBarHandle = 63
  SE_ToolBoxTabContents = 25
  SE_ToolButtonLayoutItem = 52
  SE_TreeViewDisclosureItem = 35
  SE_ViewItemCheckIndicator = 33
  SH_BlinkCursorWhenTextSelected = 28
  SH_Button_FocusPolicy = 49
  SH_ComboBox_LayoutDirection = 59
  SH_ComboBox_ListMouseTracking = 19
  SH_ComboBox_Popup = 25
  SH_ComboBox_PopupFrameStyle = 70
  SH_CustomBase = -268435456
  SH_Dial_BackgroundRole = 58
  SH_DialogButtonBox_ButtonsHaveIcons = 72
  SH_DialogButtonLayout = 69
  SH_DialogButtons_DefaultButton = 36
  SH_DitherDisabledText = 1
  SH_DockWidget_ButtonsHaveFrame = 95
  SH_DrawMenuBarSeparator = 47
  SH_EtchDisabledText = 0
  SH_FocusFrame_AboveWidget = 78
  SH_FocusFrame_Mask = 54
  SH_FontDialog_SelectAssociatedText = 13
  SH_FormLayoutFieldGrowthPolicy = 90
  SH_FormLayoutFormAlignment = 91
  SH_FormLayoutLabelAlignment = 92
  SH_FormLayoutWrapPolicy = 87
  SH_GroupBox_TextLabelColor = 32
  SH_GroupBox_TextLabelVerticalAlignment = 31
  SH_Header_ArrowAlignment = 6
  SH_ItemView_ActivateItemOnSingleClick = 62
  SH_ItemView_ArrowKeysNavigateIntoChildren = 81
  SH_ItemView_ChangeHighlightOnFocus = 22
  SH_ItemView_DrawDelegateFrame = 93
  SH_ItemView_EllipsisLocation = 60
  SH_ItemView_MovementWithoutUpdatingSelection = 76
  SH_ItemView_PaintAlternatingRowColorsForEmptyArea = 86
  SH_ItemView_ShowDecorationSelected = 61
  SH_LineEdit_PasswordCharacter = 35
  SH_MainWindow_SpaceBelowMenuBar = 12
  SH_MenuBar_AltKeyNavigation = 18
  SH_MenuBar_DismissOnSecondClick = 50
  SH_MenuBar_MouseTracking = 21
  SH_Menu_AllowActiveAndDisabled = 14
  SH_Menu_FadeOutOnHide = 84
  SH_Menu_FillScreenWithScroll = 45
  SH_Menu_FlashTriggeredItem = 83
  SH_Menu_KeyboardSearch = 67
  SH_Menu_Mask = 82
  SH_Menu_MouseTracking = 20
  SH_Menu_Scrollable = 30
  SH_Menu_SelectionWrap = 75
  SH_Menu_SloppySubMenus = 33
  SH_Menu_SpaceActivatesItem = 15
  SH_Menu_SubMenuPopupDelay = 16
  SH_MessageBox_CenterButtons = 74
  SH_MessageBox_TextInteractionFlags = 71
  SH_MessageBox_UseBorderForButtonSpacing = 51
  SH_PrintDialog_RightAlignButtons = 11
  SH_ProgressDialog_CenterCancelButton = 9
  SH_ProgressDialog_TextLabelAlignment = 10
  SH_Q3ListViewExpand_SelectMouseType = 40
  SH_RequestSoftwareInputPanel = 97
  SH_RichText_FullWidthSelection = 29
  SH_RubberBand_Mask = 55
  SH_ScrollBar_ContextMenu = 63
  SH_ScrollBar_LeftClickAbsolutePosition = 39
  SH_ScrollBar_MiddleClickAbsolutePosition = 2
  SH_ScrollBar_RollBetweenButtons = 64
  SH_ScrollBar_ScrollWhenPointerLeavesControl = 3
  SH_ScrollBar_StopMouseOverSlider = 27
  SH_ScrollView_FrameOnlyAroundContents = 17
  SH_Slider_AbsoluteSetButtons = 65
  SH_Slider_PageSetButtons = 66
  SH_Slider_SloppyKeyEvents = 8
  SH_Slider_SnapToValue = 7
  SH_Slider_StopMouseOverSlider = 27
  SH_SpellCheckUnderlineStyle = 73
  SH_SpinBox_AnimateButton = 42
  SH_SpinBox_ClickAutoRepeatRate = 44
  SH_SpinBox_ClickAutoRepeatThreshold = 85
  SH_SpinBox_KeyPressAutoRepeatRate = 43
  SH_SpinControls_DisableOnBounds = 57
  SH_TabBar_Alignment = 5
  SH_TabBar_CloseButtonPosition = 94
  SH_TabBar_ElideMode = 68
  SH_TabBar_PreferNoArrows = 38
  SH_TabBar_SelectMouseType = 4
  SH_TabWidget_DefaultTabPosition = 88
  SH_Table_GridLineColor = 34
  SH_TextControl_FocusIndicatorTextCharFormat = 79
  SH_TitleBar_AutoRaise = 52
  SH_TitleBar_ModifyNotification = 48
  SH_TitleBar_NoBorder = 26
  SH_ToolBar_Movable = 89
  SH_ToolBox_SelectedPageTitleBold = 37
  SH_ToolButtonStyle = 96
  SH_ToolButton_PopupDelay = 53
  SH_ToolTipLabel_Opacity = 46
  SH_ToolTip_Mask = 77
  SH_UnderlineShortcut = 41
  SH_Widget_ShareActivation = 23
  SH_WindowFrame_Mask = 56
  SH_WizardStyle = 80
  SH_Workspace_FillSpaceOnMaximize = 24
  SP_ArrowBack = 53
  SP_ArrowDown = 50
  SP_ArrowForward = 54
  SP_ArrowLeft = 51
  SP_ArrowRight = 52
  SP_ArrowUp = 49
  SP_BrowserReload = 58
  SP_BrowserStop = 59
  SP_CommandLink = 56
  SP_ComputerIcon = 15
  SP_CustomBase = -268435456
  SP_DesktopIcon = 13
  SP_DialogApplyButton = 44
  SP_DialogCancelButton = 39
  SP_DialogCloseButton = 43
  SP_DialogDiscardButton = 46
  SP_DialogHelpButton = 40
  SP_DialogNoButton = 48
  SP_DialogOkButton = 38
  SP_DialogOpenButton = 41
  SP_DialogResetButton = 45
  SP_DialogSaveButton = 42
  SP_DialogYesButton = 47
  SP_DirClosedIcon = 22
  SP_DirHomeIcon = 55
  SP_DirIcon = 37
  SP_DirLinkIcon = 23
  SP_DirOpenIcon = 21
  SP_DockWidgetCloseButton = 8
  SP_DriveCDIcon = 18
  SP_DriveDVDIcon = 19
  SP_DriveFDIcon = 16
  SP_DriveHDIcon = 17
  SP_DriveNetIcon = 20
  SP_FileDialogBack = 36
  SP_FileDialogContentsView = 34
  SP_FileDialogDetailedView = 32
  SP_FileDialogEnd = 29
  SP_FileDialogInfoView = 33
  SP_FileDialogListView = 35
  SP_FileDialogNewFolder = 31
  SP_FileDialogStart = 28
  SP_FileDialogToParent = 30
  SP_FileIcon = 24
  SP_FileLinkIcon = 25
  SP_MediaPause = 62
  SP_MediaPlay = 60
  SP_MediaSeekBackward = 66
  SP_MediaSeekForward = 65
  SP_MediaSkipBackward = 64
  SP_MediaSkipForward = 63
  SP_MediaStop = 61
  SP_MediaVolume = 67
  SP_MediaVolumeMuted = 68
  SP_MessageBoxCritical = 11
  SP_MessageBoxInformation = 9
  SP_MessageBoxQuestion = 12
  SP_MessageBoxWarning = 10
  SP_TitleBarCloseButton = 3
  SP_TitleBarContextHelpButton = 7
  SP_TitleBarMaxButton = 2
  SP_TitleBarMenuButton = 0
  SP_TitleBarMinButton = 1
  SP_TitleBarNormalButton = 4
  SP_TitleBarShadeButton = 5
  SP_TitleBarUnshadeButton = 6
  SP_ToolBarHorizontalExtensionButton = 26
  SP_ToolBarVerticalExtensionButton = 27
  SP_TrashIcon = 14
  SP_VistaShield = 57
  State_Active = 65536
  State_AutoRaise = 4096
  State_Bottom = 1024
  State_Children = 524288
  State_DownArrow = 64
  State_Editing = 4194304
  State_Enabled = 1
  State_FocusAtBorder = 2048
  State_HasFocus = 256
  State_Horizontal = 128
  State_Item = 1048576
  State_KeyboardFocusChange = 8388608
  State_Mini = 134217728
  State_MouseOver = 8192
  State_NoChange = 16
  State_None = 0
  State_Off = 8
  State_On = 32
  State_Open = 262144
  State_Raised = 2
  State_ReadOnly = 33554432
  State_Selected = 32768
  State_Sibling = 2097152
  State_Small = 67108864
  State_Sunken = 4
  State_Top = 512
  State_UpArrow = 16384
  State_Window = 131072

class QCompleter(_Mock):
  pass
  CaseInsensitivelySortedModel = 2
  CaseSensitivelySortedModel = 1
  InlineCompletion = 2
  PopupCompletion = 0
  UnfilteredPopupCompletion = 1
  UnsortedModel = 0

class QConicalGradient(_Mock):
  pass
  ConicalGradient = 2
  LinearGradient = 0
  LogicalMode = 0
  NoGradient = 3
  ObjectBoundingMode = 2
  PadSpread = 0
  RadialGradient = 1
  ReflectSpread = 1
  RepeatSpread = 2
  StretchToDeviceMode = 1

class QContextMenuEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  Keyboard = 1
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  Mouse = 0
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Other = 2
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QCoreApplication(_Mock):
  pass
  CodecForTr = 0
  DefaultCodec = 0
  UnicodeUTF8 = 1

class QCryptographicHash(_Mock):
  pass
  Md4 = 0
  Md5 = 1
  Sha1 = 2

class QCursor(_Mock):
  pass
  ArrowCursor = 0
  CrossCursor = 2
  PointingHandCursor = 13
  SizeHorCursor = 6
  SizeVerCursor = 5
  UpArrowCursor = 1
  WaitCursor = 3

class QDBus(_Mock):
  pass
  AutoDetect = 3
  Block = 1
  BlockWithGui = 2
  NoBlock = 0

class QDBusAbstractAdaptor(_Mock):
  pass


class QDBusAbstractInterface(_Mock):
  pass


class QDBusArgument(_Mock):
  pass


class QDBusConnection(_Mock):
  pass
  ActivationBus = 2
  ExportAdaptors = 1
  ExportAllContents = 4080
  ExportAllInvokables = 2176
  ExportAllProperties = 1088
  ExportAllSignal = 544
  ExportAllSignals = 544
  ExportAllSlots = 272
  ExportChildObjects = 4096
  ExportNonScriptableContents = 3840
  ExportNonScriptableInvokables = 2048
  ExportNonScriptableProperties = 1024
  ExportNonScriptableSignals = 512
  ExportNonScriptableSlots = 256
  ExportScriptableContents = 240
  ExportScriptableInvokables = 128
  ExportScriptableProperties = 64
  ExportScriptableSignals = 32
  ExportScriptableSlots = 16
  SessionBus = 0
  SystemBus = 1
  UnixFileDescriptorPassing = 1
  UnregisterNode = 0
  UnregisterTree = 1

class QDBusConnectionInterface(_Mock):
  pass
  AllowReplacement = 1
  DontAllowReplacement = 0
  DontQueueService = 0
  QueueService = 1
  ReplaceExistingService = 2
  ServiceNotRegistered = 0
  ServiceQueued = 2
  ServiceRegistered = 1

class QDBusError(_Mock):
  pass
  AccessDenied = 9
  AddressInUse = 13
  BadAddress = 6
  Disconnected = 14
  Failed = 2
  InternalError = 20
  InvalidArgs = 15
  InvalidInterface = 24
  InvalidMember = 25
  InvalidObjectPath = 23
  InvalidService = 22
  InvalidSignature = 18
  LimitsExceeded = 8
  NoError = 0
  NoMemory = 3
  NoNetwork = 12
  NoReply = 5
  NoServer = 10
  NotSupported = 7
  Other = 1
  ServiceUnknown = 4
  TimedOut = 17
  Timeout = 11
  UnknownInterface = 19
  UnknownMethod = 16
  UnknownObject = 21

class QDBusInterface(_Mock):
  pass


class QDBusMessage(_Mock):
  pass
  ErrorMessage = 3
  InvalidMessage = 0
  MethodCallMessage = 1
  ReplyMessage = 2
  SignalMessage = 4

class QDBusObjectPath(_Mock):
  pass


class QDBusPendingCall(_Mock):
  pass


class QDBusPendingCallWatcher(_Mock):
  pass


class QDBusPendingReply(_Mock):
  pass


class QDBusReply(_Mock):
  pass


class QDBusServiceWatcher(_Mock):
  pass
  WatchForOwnerChange = 3
  WatchForRegistration = 1
  WatchForUnregistration = 2

class QDBusSignature(_Mock):
  pass


class QDBusUnixFileDescriptor(_Mock):
  pass


class QDBusVariant(_Mock):
  pass


class QDataStream(_Mock):
  pass
  BigEndian = 0
  DoublePrecision = 1
  LittleEndian = 1
  Ok = 0
  Qt_1_0 = 1
  Qt_2_0 = 2
  Qt_2_1 = 3
  Qt_3_0 = 4
  Qt_3_1 = 5
  Qt_3_3 = 6
  Qt_4_0 = 7
  Qt_4_1 = 7
  Qt_4_2 = 8
  Qt_4_3 = 9
  Qt_4_4 = 10
  Qt_4_5 = 11
  Qt_4_6 = 12
  Qt_4_7 = 12
  Qt_4_8 = 12
  ReadCorruptData = 2
  ReadPastEnd = 1
  SinglePrecision = 0
  WriteFailed = 3

class QDataWidgetMapper(_Mock):
  pass
  AutoSubmit = 0
  ManualSubmit = 1

class QDate(_Mock):
  pass
  DateFormat = 0
  StandaloneFormat = 1

class QDateEdit(_Mock):
  pass
  AmPmSection = 1
  CorrectToNearestValue = 1
  CorrectToPreviousValue = 0
  DateSections_Mask = 1792
  DaySection = 256
  DrawChildren = 2
  DrawWindowBackground = 1
  HourSection = 16
  IgnoreMask = 4
  MSecSection = 2
  MinuteSection = 8
  MonthSection = 512
  NoButtons = 2
  NoSection = 0
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  PlusMinus = 1
  SecondSection = 4
  StepDownEnabled = 2
  StepNone = 0
  StepUpEnabled = 1
  TimeSections_Mask = 31
  UpDownArrows = 0
  YearSection = 1024

class QDateTime(_Mock):
  pass


class QDateTimeEdit(_Mock):
  pass
  AmPmSection = 1
  CorrectToNearestValue = 1
  CorrectToPreviousValue = 0
  DateSections_Mask = 1792
  DaySection = 256
  DrawChildren = 2
  DrawWindowBackground = 1
  HourSection = 16
  IgnoreMask = 4
  MSecSection = 2
  MinuteSection = 8
  MonthSection = 512
  NoButtons = 2
  NoSection = 0
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  PlusMinus = 1
  SecondSection = 4
  StepDownEnabled = 2
  StepNone = 0
  StepUpEnabled = 1
  TimeSections_Mask = 31
  UpDownArrows = 0
  YearSection = 1024

class QDeclarativeComponent(_Mock):
  pass
  Error = 3
  Loading = 2
  Null = 0
  Ready = 1

class QDeclarativeContext(_Mock):
  pass


class QDeclarativeEngine(_Mock):
  pass
  CppOwnership = 0
  JavaScriptOwnership = 1

class QDeclarativeError(_Mock):
  pass


class QDeclarativeExpression(_Mock):
  pass


class QDeclarativeExtensionPlugin(_Mock):
  pass


class QDeclarativeImageProvider(_Mock):
  pass
  Image = 0
  Pixmap = 1

class QDeclarativeItem(_Mock):
  pass
  Bottom = 7
  BottomLeft = 6
  BottomRight = 8
  Center = 4
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  Left = 3
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  Right = 5
  SceneModal = 2
  Top = 1
  TopLeft = 0
  TopRight = 2
  UserType = 65536

class QDeclarativeListReference(_Mock):
  pass


class QDeclarativeNetworkAccessManagerFactory(_Mock):
  pass


class QDeclarativeParserStatus(_Mock):
  pass


class QDeclarativeProperty(_Mock):
  pass
  Invalid = 0
  InvalidCategory = 0
  List = 1
  Normal = 3
  Object = 2
  Property = 1
  SignalProperty = 2

class QDeclarativePropertyMap(_Mock):
  pass


class QDeclarativePropertyValueSource(_Mock):
  pass


class QDeclarativeScriptString(_Mock):
  pass


class QDeclarativeView(_Mock):
  pass
  AnchorUnderMouse = 2
  AnchorViewCenter = 1
  BoundingRectViewportUpdate = 4
  Box = 1
  CacheBackground = 1
  CacheNone = 0
  DontAdjustForAntialiasing = 4
  DontClipPainter = 1
  DontSavePainterState = 2
  DrawChildren = 2
  DrawWindowBackground = 1
  Error = 3
  FullViewportUpdate = 0
  HLine = 4
  IgnoreMask = 4
  Loading = 2
  MinimalViewportUpdate = 1
  NoAnchor = 0
  NoDrag = 0
  NoFrame = 0
  NoViewportUpdate = 3
  Null = 0
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  Raised = 32
  Ready = 1
  RubberBandDrag = 2
  ScrollHandDrag = 1
  Shadow_Mask = 240
  Shape_Mask = 15
  SizeRootObjectToView = 1
  SizeViewToRootObject = 0
  SmartViewportUpdate = 2
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QDesignerActionEditorInterface(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QDesignerContainerExtension(_Mock):
  pass


class QDesignerCustomWidgetCollectionInterface(_Mock):
  pass


class QDesignerCustomWidgetInterface(_Mock):
  pass


class QDesignerFormEditorInterface(_Mock):
  pass


class QDesignerFormWindowCursorInterface(_Mock):
  pass
  Down = 8
  End = 2
  KeepAnchor = 1
  Left = 5
  MoveAnchor = 0
  Next = 3
  NoMove = 0
  Prev = 4
  Right = 6
  Start = 1
  Up = 7

class QDesignerFormWindowInterface(_Mock):
  pass
  DefaultFeature = 3
  DrawChildren = 2
  DrawWindowBackground = 1
  EditFeature = 1
  GridFeature = 2
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  TabOrderFeature = 4

class QDesignerFormWindowManagerInterface(_Mock):
  pass


class QDesignerMemberSheetExtension(_Mock):
  pass


class QDesignerObjectInspectorInterface(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QDesignerPropertyEditorInterface(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QDesignerPropertySheetExtension(_Mock):
  pass


class QDesignerTaskMenuExtension(_Mock):
  pass


class QDesignerWidgetBoxInterface(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QDesktopServices(_Mock):
  pass
  ApplicationsLocation = 3
  CacheLocation = 10
  DataLocation = 9
  DesktopLocation = 0
  DocumentsLocation = 1
  FontsLocation = 2
  HomeLocation = 8
  MoviesLocation = 5
  MusicLocation = 4
  PicturesLocation = 6
  TempLocation = 7

class QDesktopWidget(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QDial(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  SliderMove = 7
  SliderNoAction = 0
  SliderOrientationChange = 1
  SliderPageStepAdd = 3
  SliderPageStepSub = 4
  SliderRangeChange = 0
  SliderSingleStepAdd = 1
  SliderSingleStepSub = 2
  SliderStepsChange = 2
  SliderToMaximum = 6
  SliderToMinimum = 5
  SliderValueChange = 3

class QDialog(_Mock):
  pass
  Accepted = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Rejected = 0

class QDialogButtonBox(_Mock):
  pass
  Abort = 262144
  AcceptRole = 0
  ActionRole = 3
  Apply = 33554432
  ApplyRole = 8
  Cancel = 4194304
  Close = 2097152
  DestructiveRole = 2
  Discard = 8388608
  DrawChildren = 2
  DrawWindowBackground = 1
  GnomeLayout = 3
  Help = 16777216
  HelpRole = 4
  Ignore = 1048576
  IgnoreMask = 4
  InvalidRole = -1
  KdeLayout = 2
  MacLayout = 1
  No = 65536
  NoButton = 0
  NoRole = 6
  NoToAll = 131072
  Ok = 1024
  Open = 8192
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  RejectRole = 1
  Reset = 67108864
  ResetRole = 7
  RestoreDefaults = 134217728
  Retry = 524288
  Save = 2048
  SaveAll = 4096
  WinLayout = 0
  Yes = 16384
  YesRole = 5
  YesToAll = 32768

class QDir(_Mock):
  pass
  AccessMask = 1008
  AllDirs = 1024
  AllEntries = 7
  CaseSensitive = 2048
  Dirs = 1
  DirsFirst = 4
  DirsLast = 32
  Drives = 4
  Executable = 64
  Files = 2
  Hidden = 256
  IgnoreCase = 16
  LocaleAware = 64
  Modified = 128
  Name = 0
  NoDot = 8192
  NoDotAndDotDot = 4096
  NoDotDot = 16384
  NoFilter = -1
  NoSort = -1
  NoSymLinks = 8
  PermissionMask = 112
  Readable = 16
  Reversed = 8
  Size = 2
  SortByMask = 3
  System = 512
  Time = 1
  Type = 128
  TypeMask = 15
  Unsorted = 3
  Writable = 32

class QDirIterator(_Mock):
  pass
  FollowSymlinks = 1
  NoIteratorFlags = 0
  Subdirectories = 2

class QDirModel(_Mock):
  pass
  FileIconRole = 1
  FileNameRole = 34
  FilePathRole = 33

class QDockWidget(_Mock):
  pass
  AllDockWidgetFeatures = 7
  DockWidgetClosable = 1
  DockWidgetFloatable = 4
  DockWidgetMovable = 2
  DockWidgetVerticalTitleBar = 8
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  NoDockWidgetFeatures = 0
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QDomAttr(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomCDATASection(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomCharacterData(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomComment(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomDocument(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomDocumentFragment(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomDocumentType(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomElement(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomEntity(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomEntityReference(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomImplementation(_Mock):
  pass
  AcceptInvalidChars = 0
  DropInvalidChars = 1
  ReturnNullNode = 2

class QDomNamedNodeMap(_Mock):
  pass


class QDomNode(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomNodeList(_Mock):
  pass


class QDomNotation(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomProcessingInstruction(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDomText(_Mock):
  pass
  AttributeNode = 2
  BaseNode = 21
  CDATASectionNode = 4
  CharacterDataNode = 22
  CommentNode = 8
  DocumentFragmentNode = 11
  DocumentNode = 9
  DocumentTypeNode = 10
  ElementNode = 1
  EncodingFromDocument = 1
  EncodingFromTextStream = 2
  EntityNode = 6
  EntityReferenceNode = 5
  NotationNode = 12
  ProcessingInstructionNode = 7
  TextNode = 3

class QDoubleSpinBox(_Mock):
  pass
  CorrectToNearestValue = 1
  CorrectToPreviousValue = 0
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  NoButtons = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  PlusMinus = 1
  StepDownEnabled = 2
  StepNone = 0
  StepUpEnabled = 1
  UpDownArrows = 0

class QDoubleValidator(_Mock):
  pass
  Acceptable = 2
  Intermediate = 1
  Invalid = 0
  ScientificNotation = 1
  StandardNotation = 0

class QDrag(_Mock):
  pass


class QDragEnterEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QDragLeaveEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QDragMoveEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QDropEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QDynamicPropertyChangeEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QEasingCurve(_Mock):
  pass
  CosineCurve = 44
  Custom = 45
  InBack = 33
  InBounce = 37
  InCirc = 25
  InCubic = 5
  InCurve = 41
  InElastic = 29
  InExpo = 21
  InOutBack = 35
  InOutBounce = 39
  InOutCirc = 27
  InOutCubic = 7
  InOutElastic = 31
  InOutExpo = 23
  InOutQuad = 3
  InOutQuart = 11
  InOutQuint = 15
  InOutSine = 19
  InQuad = 1
  InQuart = 9
  InQuint = 13
  InSine = 17
  Linear = 0
  OutBack = 34
  OutBounce = 38
  OutCirc = 26
  OutCubic = 6
  OutCurve = 42
  OutElastic = 30
  OutExpo = 22
  OutInBack = 36
  OutInBounce = 40
  OutInCirc = 28
  OutInCubic = 8
  OutInElastic = 32
  OutInExpo = 24
  OutInQuad = 4
  OutInQuart = 12
  OutInQuint = 16
  OutInSine = 20
  OutQuad = 2
  OutQuart = 10
  OutQuint = 14
  OutSine = 18
  SineCurve = 43

class QElapsedTimer(_Mock):
  pass
  MachAbsoluteTime = 3
  MonotonicClock = 1
  PerformanceCounter = 4
  SystemTime = 0
  TickCounter = 2

class QErrorMessage(_Mock):
  pass
  Accepted = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Rejected = 0

class QEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QEventLoop(_Mock):
  pass
  AllEvents = 0
  DeferredDeletion = 16
  ExcludeSocketNotifiers = 2
  ExcludeUserInputEvents = 1
  WaitForMoreEvents = 4
  X11ExcludeTimers = 8

class QEventTransition(_Mock):
  pass


class QExtensionFactory(_Mock):
  pass


class QExtensionManager(_Mock):
  pass


class QFSFileEngine(_Mock):
  pass
  AbsoluteName = 3
  AbsolutePathName = 4
  AccessTime = 2
  BaseName = 1
  BundleName = 8
  BundleType = 524288
  CanonicalName = 6
  CanonicalPathName = 7
  CreationTime = 0
  DefaultName = 0
  DirectoryType = 262144
  ExeGroupPerm = 16
  ExeOtherPerm = 1
  ExeOwnerPerm = 4096
  ExeUserPerm = 256
  ExistsFlag = 4194304
  FileInfoAll = 268435455
  FileType = 131072
  FlagsMask = 267386880
  HiddenFlag = 1048576
  LinkName = 5
  LinkType = 65536
  LocalDiskFlag = 2097152
  ModificationTime = 1
  OwnerGroup = 1
  OwnerUser = 0
  PathName = 2
  PermsMask = 65535
  ReadGroupPerm = 64
  ReadOtherPerm = 4
  ReadOwnerPerm = 16384
  ReadUserPerm = 1024
  Refresh = 16777216
  RootFlag = 8388608
  TypesMask = 983040
  WriteGroupPerm = 32
  WriteOtherPerm = 2
  WriteOwnerPerm = 8192
  WriteUserPerm = 512

class QFile(_Mock):
  pass
  AbortError = 6
  Append = 4
  AutoCloseHandle = 1
  CopyError = 14
  DontCloseHandle = 0
  ExeGroup = 16
  ExeOther = 1
  ExeOwner = 4096
  ExeUser = 256
  FatalError = 3
  NoError = 0
  NoOptions = 0
  NotOpen = 0
  OpenError = 5
  PermissionsError = 13
  PositionError = 11
  ReadError = 1
  ReadGroup = 64
  ReadOnly = 1
  ReadOther = 4
  ReadOwner = 16384
  ReadUser = 1024
  ReadWrite = 3
  RemoveError = 9
  RenameError = 10
  ResizeError = 12
  ResourceError = 4
  Text = 16
  TimeOutError = 7
  Truncate = 8
  Unbuffered = 32
  UnspecifiedError = 8
  WriteError = 2
  WriteGroup = 32
  WriteOnly = 2
  WriteOther = 2
  WriteOwner = 8192
  WriteUser = 512

class QFileDialog(_Mock):
  pass
  Accept = 3
  AcceptOpen = 0
  AcceptSave = 1
  Accepted = 1
  AnyFile = 0
  Detail = 0
  Directory = 2
  DirectoryOnly = 4
  DontConfirmOverwrite = 4
  DontResolveSymlinks = 2
  DontUseCustomDirectoryIcons = 128
  DontUseNativeDialog = 16
  DontUseSheet = 8
  DrawChildren = 2
  DrawWindowBackground = 1
  ExistingFile = 1
  ExistingFiles = 3
  FileName = 1
  FileType = 2
  HideNameFilterDetails = 64
  IgnoreMask = 4
  List = 1
  LookIn = 0
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  ReadOnly = 32
  Reject = 4
  Rejected = 0
  ShowDirsOnly = 1

class QFileIconProvider(_Mock):
  pass
  Computer = 0
  Desktop = 1
  Drive = 4
  File = 6
  Folder = 5
  Network = 3
  Trashcan = 2

class QFileInfo(_Mock):
  pass


class QFileOpenEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QFileSystemModel(_Mock):
  pass
  FileIconRole = 1
  FileNameRole = 34
  FilePathRole = 33
  FilePermissions = 35

class QFileSystemWatcher(_Mock):
  pass


class QFinalState(_Mock):
  pass


class QFocusEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QFocusFrame(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QFont(_Mock):
  pass
  AbsoluteSpacing = 1
  AllLowercase = 2
  AllUppercase = 1
  AnyStyle = 5
  Black = 87
  Bold = 75
  Capitalize = 4
  Condensed = 75
  Courier = 2
  Cursive = 6
  Decorative = 3
  DemiBold = 63
  Expanded = 125
  ExtraCondensed = 62
  ExtraExpanded = 150
  Fantasy = 8
  ForceIntegerMetrics = 1024
  ForceOutline = 16
  Helvetica = 0
  Light = 25
  MixedCase = 0
  Monospace = 7
  NoAntialias = 256
  NoFontMerging = 32768
  Normal = 50
  OldEnglish = 3
  OpenGLCompatible = 512
  PercentageSpacing = 0
  PreferAntialias = 128
  PreferBitmap = 2
  PreferDefault = 1
  PreferDefaultHinting = 0
  PreferDevice = 4
  PreferFullHinting = 3
  PreferMatch = 32
  PreferNoHinting = 1
  PreferOutline = 8
  PreferQuality = 64
  PreferVerticalHinting = 2
  SansSerif = 0
  SemiCondensed = 87
  SemiExpanded = 112
  Serif = 1
  SmallCaps = 3
  StyleItalic = 1
  StyleNormal = 0
  StyleOblique = 2
  System = 4
  Times = 1
  TypeWriter = 2
  UltraCondensed = 50
  UltraExpanded = 200
  Unstretched = 100

class QFontComboBox(_Mock):
  pass
  AdjustToContents = 0
  AdjustToContentsOnFirstShow = 1
  AdjustToMinimumContentsLength = 2
  AdjustToMinimumContentsLengthWithIcon = 3
  AllFonts = 0
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  InsertAfterCurrent = 4
  InsertAlphabetically = 6
  InsertAtBottom = 3
  InsertAtCurrent = 2
  InsertAtTop = 1
  InsertBeforeCurrent = 5
  MonospacedFonts = 4
  NoInsert = 0
  NonScalableFonts = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  ProportionalFonts = 8
  ScalableFonts = 1

class QFontDatabase(_Mock):
  pass
  Any = 0
  Arabic = 6
  Armenian = 4
  Bengali = 10
  Cyrillic = 3
  Devanagari = 9
  Georgian = 23
  Greek = 2
  Gujarati = 12
  Gurmukhi = 11
  Hebrew = 5
  Japanese = 27
  Kannada = 16
  Khmer = 24
  Korean = 28
  Lao = 20
  Latin = 1
  Malayalam = 17
  Myanmar = 22
  Nko = 33
  Ogham = 31
  Oriya = 13
  Other = 30
  Runic = 32
  SimplifiedChinese = 25
  Sinhala = 18
  Symbol = 30
  Syriac = 7
  Tamil = 14
  Telugu = 15
  Thaana = 8
  Thai = 19
  Tibetan = 21
  TraditionalChinese = 26
  Vietnamese = 29

class QFontDialog(_Mock):
  pass
  Accepted = 1
  DontUseNativeDialog = 2
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  NoButtons = 1
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Rejected = 0

class QFontInfo(_Mock):
  pass


class QFontMetrics(_Mock):
  pass


class QFontMetricsF(_Mock):
  pass


class QFormBuilder(_Mock):
  pass


class QFormLayout(_Mock):
  pass
  AllNonFixedFieldsGrow = 2
  DontWrapRows = 0
  ExpandingFieldsGrow = 1
  FieldRole = 1
  FieldsStayAtSizeHint = 0
  LabelRole = 0
  SetDefaultConstraint = 0
  SetFixedSize = 3
  SetMaximumSize = 4
  SetMinAndMaxSize = 5
  SetMinimumSize = 2
  SetNoConstraint = 1
  SpanningRole = 2
  WrapAllRows = 2
  WrapLongRows = 1

class QFrame(_Mock):
  pass
  Box = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  HLine = 4
  IgnoreMask = 4
  NoFrame = 0
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  Raised = 32
  Shadow_Mask = 240
  Shape_Mask = 15
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QFtp(_Mock):
  pass
  Active = 0
  Ascii = 1
  Binary = 0
  Cd = 7
  Close = 5
  Closing = 5
  ConnectToHost = 3
  Connected = 3
  Connecting = 2
  ConnectionRefused = 3
  Get = 8
  HostLookup = 1
  HostNotFound = 2
  List = 6
  LoggedIn = 4
  Login = 4
  Mkdir = 11
  NoError = 0
  None_ = 0
  NotConnected = 4
  Passive = 1
  Put = 9
  RawCommand = 14
  Remove = 10
  Rename = 13
  Rmdir = 12
  SetProxy = 2
  SetTransferMode = 1
  Unconnected = 0
  UnknownError = 1

class QGL(_Mock):
  pass
  AccumBuffer = 16
  AlphaChannel = 8
  ColorIndex = 262144
  DeprecatedFunctions = 1024
  DepthBuffer = 2
  DirectRendering = 128
  DoubleBuffer = 1
  HasOverlay = 256
  IndirectRendering = 8388608
  NoAccumBuffer = 1048576
  NoAlphaChannel = 524288
  NoDeprecatedFunctions = 67108864
  NoDepthBuffer = 131072
  NoOverlay = 16777216
  NoSampleBuffers = 33554432
  NoStencilBuffer = 2097152
  NoStereoBuffers = 4194304
  Rgba = 4
  SampleBuffers = 512
  SingleBuffer = 65536
  StencilBuffer = 32
  StereoBuffers = 64

class QGLBuffer(_Mock):
  pass
  DynamicCopy = 35050
  DynamicDraw = 35048
  DynamicRead = 35049
  IndexBuffer = 34963
  PixelPackBuffer = 35051
  PixelUnpackBuffer = 35052
  ReadOnly = 35000
  ReadWrite = 35002
  StaticCopy = 35046
  StaticDraw = 35044
  StaticRead = 35045
  StreamCopy = 35042
  StreamDraw = 35040
  StreamRead = 35041
  VertexBuffer = 34962
  WriteOnly = 35001

class QGLColormap(_Mock):
  pass


class QGLContext(_Mock):
  pass
  DefaultBindOption = 11
  InvertedYBindOption = 1
  LinearFilteringBindOption = 8
  MipmapBindOption = 2
  NoBindOption = 0
  PremultipliedAlphaBindOption = 4

class QGLFormat(_Mock):
  pass
  CompatibilityProfile = 2
  CoreProfile = 1
  NoProfile = 0
  OpenGL_ES_CommonLite_Version_1_0 = 256
  OpenGL_ES_CommonLite_Version_1_1 = 1024
  OpenGL_ES_Common_Version_1_0 = 128
  OpenGL_ES_Common_Version_1_1 = 512
  OpenGL_ES_Version_2_0 = 2048
  OpenGL_Version_1_1 = 1
  OpenGL_Version_1_2 = 2
  OpenGL_Version_1_3 = 4
  OpenGL_Version_1_4 = 8
  OpenGL_Version_1_5 = 16
  OpenGL_Version_2_0 = 32
  OpenGL_Version_2_1 = 64
  OpenGL_Version_3_0 = 4096
  OpenGL_Version_3_1 = 8192
  OpenGL_Version_3_2 = 16384
  OpenGL_Version_3_3 = 32768
  OpenGL_Version_4_0 = 65536
  OpenGL_Version_None = 0

class QGLFramebufferObject(_Mock):
  pass
  CombinedDepthStencil = 1
  Depth = 2
  NoAttachment = 0
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QGLFramebufferObjectFormat(_Mock):
  pass


class QGLPixelBuffer(_Mock):
  pass
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QGLShader(_Mock):
  pass
  Fragment = 2
  Geometry = 4
  Vertex = 1

class QGLShaderProgram(_Mock):
  pass


class QGLWidget(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QGenericArgument(_Mock):
  pass


class QGenericReturnArgument(_Mock):
  pass


class QGesture(_Mock):
  pass
  CancelAllInContext = 1
  CancelNone = 0

class QGestureEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QGestureRecognizer(_Mock):
  pass
  CancelGesture = 16
  ConsumeEventHint = 256
  FinishGesture = 8
  Ignore = 1
  MayBeGesture = 2
  TriggerGesture = 4

class QGlyphRun(_Mock):
  pass


class QGradient(_Mock):
  pass
  ConicalGradient = 2
  LinearGradient = 0
  LogicalMode = 0
  NoGradient = 3
  ObjectBoundingMode = 2
  PadSpread = 0
  RadialGradient = 1
  ReflectSpread = 1
  RepeatSpread = 2
  StretchToDeviceMode = 1

class QGraphicsAnchor(_Mock):
  pass


class QGraphicsAnchorLayout(_Mock):
  pass


class QGraphicsBlurEffect(_Mock):
  pass
  AnimationHint = 2
  NoPad = 0
  PadToEffectiveBoundingRect = 2
  PadToTransparentBorder = 1
  PerformanceHint = 0
  QualityHint = 1
  SourceAttached = 1
  SourceBoundingRectChanged = 4
  SourceDetached = 2
  SourceInvalidated = 8

class QGraphicsColorizeEffect(_Mock):
  pass
  NoPad = 0
  PadToEffectiveBoundingRect = 2
  PadToTransparentBorder = 1
  SourceAttached = 1
  SourceBoundingRectChanged = 4
  SourceDetached = 2
  SourceInvalidated = 8

class QGraphicsDropShadowEffect(_Mock):
  pass
  NoPad = 0
  PadToEffectiveBoundingRect = 2
  PadToTransparentBorder = 1
  SourceAttached = 1
  SourceBoundingRectChanged = 4
  SourceDetached = 2
  SourceInvalidated = 8

class QGraphicsEffect(_Mock):
  pass
  NoPad = 0
  PadToEffectiveBoundingRect = 2
  PadToTransparentBorder = 1
  SourceAttached = 1
  SourceBoundingRectChanged = 4
  SourceDetached = 2
  SourceInvalidated = 8

class QGraphicsEllipseItem(_Mock):
  pass
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QGraphicsGridLayout(_Mock):
  pass


class QGraphicsItem(_Mock):
  pass
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QGraphicsItemAnimation(_Mock):
  pass


class QGraphicsItemGroup(_Mock):
  pass
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QGraphicsLayout(_Mock):
  pass


class QGraphicsLayoutItem(_Mock):
  pass


class QGraphicsLineItem(_Mock):
  pass
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QGraphicsLinearLayout(_Mock):
  pass


class QGraphicsObject(_Mock):
  pass
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QGraphicsOpacityEffect(_Mock):
  pass
  NoPad = 0
  PadToEffectiveBoundingRect = 2
  PadToTransparentBorder = 1
  SourceAttached = 1
  SourceBoundingRectChanged = 4
  SourceDetached = 2
  SourceInvalidated = 8

class QGraphicsPathItem(_Mock):
  pass
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QGraphicsPixmapItem(_Mock):
  pass
  BoundingRectShape = 1
  DeviceCoordinateCache = 2
  HeuristicMaskShape = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  MaskShape = 0
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QGraphicsPolygonItem(_Mock):
  pass
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QGraphicsProxyWidget(_Mock):
  pass
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QGraphicsRectItem(_Mock):
  pass
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QGraphicsRotation(_Mock):
  pass


class QGraphicsScale(_Mock):
  pass


class QGraphicsScene(_Mock):
  pass
  AllLayers = 65535
  BackgroundLayer = 2
  BspTreeIndex = 0
  ForegroundLayer = 4
  ItemLayer = 1
  NoIndex = -1

class QGraphicsSceneContextMenuEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  Keyboard = 1
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  Mouse = 0
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Other = 2
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QGraphicsSceneDragDropEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QGraphicsSceneEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QGraphicsSceneHelpEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QGraphicsSceneHoverEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QGraphicsSceneMouseEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QGraphicsSceneMoveEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QGraphicsSceneResizeEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QGraphicsSceneWheelEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QGraphicsSimpleTextItem(_Mock):
  pass
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QGraphicsSvgItem(_Mock):
  pass
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QGraphicsTextItem(_Mock):
  pass
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QGraphicsTransform(_Mock):
  pass


class QGraphicsView(_Mock):
  pass
  AnchorUnderMouse = 2
  AnchorViewCenter = 1
  BoundingRectViewportUpdate = 4
  Box = 1
  CacheBackground = 1
  CacheNone = 0
  DontAdjustForAntialiasing = 4
  DontClipPainter = 1
  DontSavePainterState = 2
  DrawChildren = 2
  DrawWindowBackground = 1
  FullViewportUpdate = 0
  HLine = 4
  IgnoreMask = 4
  MinimalViewportUpdate = 1
  NoAnchor = 0
  NoDrag = 0
  NoFrame = 0
  NoViewportUpdate = 3
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  Raised = 32
  RubberBandDrag = 2
  ScrollHandDrag = 1
  Shadow_Mask = 240
  Shape_Mask = 15
  SmartViewportUpdate = 2
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QGraphicsWebView(_Mock):
  pass
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QGraphicsWidget(_Mock):
  pass
  DeviceCoordinateCache = 2
  ItemAcceptsInputMethod = 4096
  ItemChildAddedChange = 6
  ItemChildRemovedChange = 7
  ItemClipsChildrenToShape = 16
  ItemClipsToShape = 8
  ItemCoordinateCache = 1
  ItemCursorChange = 17
  ItemCursorHasChanged = 18
  ItemDoesntPropagateOpacityToChildren = 128
  ItemEnabledChange = 3
  ItemEnabledHasChanged = 13
  ItemFlagsChange = 21
  ItemFlagsHaveChanged = 22
  ItemHasNoContents = 1024
  ItemIgnoresParentOpacity = 64
  ItemIgnoresTransformations = 32
  ItemIsFocusable = 4
  ItemIsMovable = 1
  ItemIsPanel = 16384
  ItemIsSelectable = 2
  ItemMatrixChange = 1
  ItemNegativeZStacksBehindParent = 8192
  ItemOpacityChange = 25
  ItemOpacityHasChanged = 26
  ItemParentChange = 5
  ItemParentHasChanged = 15
  ItemPositionChange = 0
  ItemPositionHasChanged = 9
  ItemRotationChange = 28
  ItemRotationHasChanged = 29
  ItemScaleChange = 30
  ItemScaleHasChanged = 31
  ItemSceneChange = 11
  ItemSceneHasChanged = 16
  ItemScenePositionHasChanged = 27
  ItemSelectedChange = 4
  ItemSelectedHasChanged = 14
  ItemSendsGeometryChanges = 2048
  ItemSendsScenePositionChanges = 65536
  ItemStacksBehindParent = 256
  ItemToolTipChange = 19
  ItemToolTipHasChanged = 20
  ItemTransformChange = 8
  ItemTransformHasChanged = 10
  ItemTransformOriginPointChange = 32
  ItemTransformOriginPointHasChanged = 33
  ItemUsesExtendedStyleOption = 512
  ItemVisibleChange = 2
  ItemVisibleHasChanged = 12
  ItemZValueChange = 23
  ItemZValueHasChanged = 24
  NoCache = 0
  NonModal = 0
  PanelModal = 1
  SceneModal = 2
  UserType = 65536

class QGridLayout(_Mock):
  pass
  SetDefaultConstraint = 0
  SetFixedSize = 3
  SetMaximumSize = 4
  SetMinAndMaxSize = 5
  SetMinimumSize = 2
  SetNoConstraint = 1

class QGroupBox(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QHBoxLayout(_Mock):
  pass
  BottomToTop = 3
  Down = 2
  LeftToRight = 0
  RightToLeft = 1
  SetDefaultConstraint = 0
  SetFixedSize = 3
  SetMaximumSize = 4
  SetMinAndMaxSize = 5
  SetMinimumSize = 2
  SetNoConstraint = 1
  TopToBottom = 2
  Up = 3

class QHeaderView(_Mock):
  pass
  AboveItem = 1
  AllEditTriggers = 31
  AnimatingState = 6
  AnyKeyPressed = 16
  BelowItem = 2
  Box = 1
  CollapsingState = 5
  ContiguousSelection = 4
  CurrentChanged = 1
  Custom = 2
  DoubleClicked = 2
  DragDrop = 3
  DragOnly = 1
  DragSelectingState = 2
  DraggingState = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  DropOnly = 2
  EditKeyPressed = 8
  EditingState = 3
  EnsureVisible = 0
  ExpandingState = 4
  ExtendedSelection = 3
  Fixed = 2
  HLine = 4
  IgnoreMask = 4
  Interactive = 0
  InternalMove = 4
  MoveDown = 1
  MoveEnd = 5
  MoveHome = 4
  MoveLeft = 2
  MoveNext = 8
  MovePageDown = 7
  MovePageUp = 6
  MovePrevious = 9
  MoveRight = 3
  MoveUp = 0
  MultiSelection = 2
  NoDragDrop = 0
  NoEditTriggers = 0
  NoFrame = 0
  NoSelection = 0
  NoState = 0
  OnItem = 0
  OnViewport = 3
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  PositionAtBottom = 2
  PositionAtCenter = 3
  PositionAtTop = 1
  Raised = 32
  ResizeToContents = 3
  ScrollPerItem = 0
  ScrollPerPixel = 1
  SelectColumns = 2
  SelectItems = 0
  SelectRows = 1
  SelectedClicked = 4
  Shadow_Mask = 240
  Shape_Mask = 15
  SingleSelection = 1
  Stretch = 1
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QHelpContentItem(_Mock):
  pass


class QHelpContentModel(_Mock):
  pass


class QHelpContentWidget(_Mock):
  pass
  AboveItem = 1
  AllEditTriggers = 31
  AnimatingState = 6
  AnyKeyPressed = 16
  BelowItem = 2
  Box = 1
  CollapsingState = 5
  ContiguousSelection = 4
  CurrentChanged = 1
  DoubleClicked = 2
  DragDrop = 3
  DragOnly = 1
  DragSelectingState = 2
  DraggingState = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  DropOnly = 2
  EditKeyPressed = 8
  EditingState = 3
  EnsureVisible = 0
  ExpandingState = 4
  ExtendedSelection = 3
  HLine = 4
  IgnoreMask = 4
  InternalMove = 4
  MoveDown = 1
  MoveEnd = 5
  MoveHome = 4
  MoveLeft = 2
  MoveNext = 8
  MovePageDown = 7
  MovePageUp = 6
  MovePrevious = 9
  MoveRight = 3
  MoveUp = 0
  MultiSelection = 2
  NoDragDrop = 0
  NoEditTriggers = 0
  NoFrame = 0
  NoSelection = 0
  NoState = 0
  OnItem = 0
  OnViewport = 3
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  PositionAtBottom = 2
  PositionAtCenter = 3
  PositionAtTop = 1
  Raised = 32
  ScrollPerItem = 0
  ScrollPerPixel = 1
  SelectColumns = 2
  SelectItems = 0
  SelectRows = 1
  SelectedClicked = 4
  Shadow_Mask = 240
  Shape_Mask = 15
  SingleSelection = 1
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QHelpEngine(_Mock):
  pass


class QHelpEngineCore(_Mock):
  pass


class QHelpEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QHelpIndexModel(_Mock):
  pass


class QHelpIndexWidget(_Mock):
  pass
  AboveItem = 1
  Adjust = 1
  AllEditTriggers = 31
  AnimatingState = 6
  AnyKeyPressed = 16
  Batched = 1
  BelowItem = 2
  Box = 1
  CollapsingState = 5
  ContiguousSelection = 4
  CurrentChanged = 1
  DoubleClicked = 2
  DragDrop = 3
  DragOnly = 1
  DragSelectingState = 2
  DraggingState = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  DropOnly = 2
  EditKeyPressed = 8
  EditingState = 3
  EnsureVisible = 0
  ExpandingState = 4
  ExtendedSelection = 3
  Fixed = 0
  Free = 1
  HLine = 4
  IconMode = 1
  IgnoreMask = 4
  InternalMove = 4
  LeftToRight = 0
  ListMode = 0
  MoveDown = 1
  MoveEnd = 5
  MoveHome = 4
  MoveLeft = 2
  MoveNext = 8
  MovePageDown = 7
  MovePageUp = 6
  MovePrevious = 9
  MoveRight = 3
  MoveUp = 0
  MultiSelection = 2
  NoDragDrop = 0
  NoEditTriggers = 0
  NoFrame = 0
  NoSelection = 0
  NoState = 0
  OnItem = 0
  OnViewport = 3
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  PositionAtBottom = 2
  PositionAtCenter = 3
  PositionAtTop = 1
  Raised = 32
  ScrollPerItem = 0
  ScrollPerPixel = 1
  SelectColumns = 2
  SelectItems = 0
  SelectRows = 1
  SelectedClicked = 4
  Shadow_Mask = 240
  Shape_Mask = 15
  SinglePass = 0
  SingleSelection = 1
  Snap = 2
  Static = 0
  StyledPanel = 6
  Sunken = 48
  TopToBottom = 1
  VLine = 5
  WinPanel = 3

class QHelpSearchEngine(_Mock):
  pass


class QHelpSearchQuery(_Mock):
  pass
  ALL = 4
  ATLEAST = 5
  DEFAULT = 0
  FUZZY = 1
  PHRASE = 3
  WITHOUT = 2

class QHelpSearchQueryWidget(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QHelpSearchResultWidget(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QHideEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QHistoryState(_Mock):
  pass
  DeepHistory = 1
  ShallowHistory = 0

class QHostAddress(_Mock):
  pass
  Any = 4
  AnyIPv6 = 5
  Broadcast = 1
  LocalHost = 2
  LocalHostIPv6 = 3
  Null = 0

class QHostInfo(_Mock):
  pass
  HostNotFound = 1
  NoError = 0
  UnknownError = 2

class QHoverEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QHttp(_Mock):
  pass
  Aborted = 7
  AuthenticationRequiredError = 8
  Closing = 6
  Connected = 5
  Connecting = 2
  ConnectionModeHttp = 0
  ConnectionModeHttps = 1
  ConnectionRefused = 3
  HostLookup = 1
  HostNotFound = 2
  InvalidResponseHeader = 5
  NoError = 0
  ProxyAuthenticationRequiredError = 9
  Reading = 4
  Sending = 3
  Unconnected = 0
  UnexpectedClose = 4
  UnknownError = 1
  WrongContentLength = 6

class QHttpHeader(_Mock):
  pass


class QHttpMultiPart(_Mock):
  pass
  AlternativeType = 3
  FormDataType = 2
  MixedType = 0
  RelatedType = 1

class QHttpPart(_Mock):
  pass


class QHttpRequestHeader(_Mock):
  pass


class QHttpResponseHeader(_Mock):
  pass


class QIODevice(_Mock):
  pass
  Append = 4
  NotOpen = 0
  ReadOnly = 1
  ReadWrite = 3
  Text = 16
  Truncate = 8
  Unbuffered = 32
  WriteOnly = 2

class QIcon(_Mock):
  pass
  Active = 2
  Disabled = 1
  Normal = 0
  Off = 1
  On = 0
  Selected = 3

class QIconDragEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QIconEngine(_Mock):
  pass


class QIconEngineV2(_Mock):
  pass
  AvailableSizesHook = 1
  IconNameHook = 2

class QIdentityProxyModel(_Mock):
  pass


class QImage(_Mock):
  pass
  Format_ARGB32 = 5
  Format_ARGB32_Premultiplied = 6
  Format_ARGB4444_Premultiplied = 15
  Format_ARGB6666_Premultiplied = 10
  Format_ARGB8555_Premultiplied = 12
  Format_ARGB8565_Premultiplied = 8
  Format_Indexed8 = 3
  Format_Invalid = 0
  Format_Mono = 1
  Format_MonoLSB = 2
  Format_RGB16 = 7
  Format_RGB32 = 4
  Format_RGB444 = 14
  Format_RGB555 = 11
  Format_RGB666 = 9
  Format_RGB888 = 13
  InvertRgb = 0
  InvertRgba = 1
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QImageIOHandler(_Mock):
  pass
  Animation = 12
  BackgroundColor = 13
  ClipRect = 1
  CompressionRatio = 5
  Description = 2
  Endianness = 11
  Gamma = 6
  IncrementalReading = 10
  Name = 8
  Quality = 7
  ScaledClipRect = 3
  ScaledSize = 4
  Size = 0
  SubType = 9

class QImageReader(_Mock):
  pass
  DeviceError = 2
  FileNotFoundError = 1
  InvalidDataError = 4
  UnknownError = 0
  UnsupportedFormatError = 3

class QImageWriter(_Mock):
  pass
  DeviceError = 1
  UnknownError = 0
  UnsupportedFormatError = 2

class QInputContext(_Mock):
  pass
  PreeditFormat = 0
  SelectionFormat = 1

class QInputContextFactory(_Mock):
  pass


class QInputDialog(_Mock):
  pass
  Accepted = 1
  DoubleInput = 2
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  IntInput = 1
  NoButtons = 1
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Rejected = 0
  TextInput = 0
  UseListViewForComboBoxItems = 2

class QInputEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QInputMethodEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  Cursor = 1
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  Language = 2
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Ruby = 3
  Selection = 4
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  TextFormat = 0
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QIntValidator(_Mock):
  pass
  Acceptable = 2
  Intermediate = 1
  Invalid = 0

class QItemDelegate(_Mock):
  pass
  EditNextItem = 1
  EditPreviousItem = 2
  NoHint = 0
  RevertModelCache = 4
  SubmitModelCache = 3

class QItemEditorCreatorBase(_Mock):
  pass


class QItemEditorFactory(_Mock):
  pass


class QItemSelection(_Mock):
  pass


class QItemSelectionModel(_Mock):
  pass
  Clear = 1
  ClearAndSelect = 3
  Columns = 64
  Current = 16
  Deselect = 4
  NoUpdate = 0
  Rows = 32
  Select = 2
  SelectCurrent = 18
  Toggle = 8
  ToggleCurrent = 24

class QItemSelectionRange(_Mock):
  pass


class QKeyEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QKeyEventTransition(_Mock):
  pass


class QKeySequence(_Mock):
  pass
  AddTab = 19
  Back = 13
  Bold = 27
  Close = 4
  Copy = 9
  Cut = 8
  Delete = 7
  DeleteEndOfLine = 60
  DeleteEndOfWord = 59
  DeleteStartOfWord = 58
  ExactMatch = 2
  Find = 22
  FindNext = 23
  FindPrevious = 24
  Forward = 14
  HelpContents = 1
  InsertLineSeparator = 62
  InsertParagraphSeparator = 61
  Italic = 28
  MoveToEndOfBlock = 41
  MoveToEndOfDocument = 43
  MoveToEndOfLine = 39
  MoveToNextChar = 30
  MoveToNextLine = 34
  MoveToNextPage = 36
  MoveToNextWord = 32
  MoveToPreviousChar = 31
  MoveToPreviousLine = 35
  MoveToPreviousPage = 37
  MoveToPreviousWord = 33
  MoveToStartOfBlock = 40
  MoveToStartOfDocument = 42
  MoveToStartOfLine = 38
  NativeText = 0
  New = 6
  NextChild = 20
  NoMatch = 0
  Open = 3
  PartialMatch = 1
  Paste = 10
  PortableText = 1
  Preferences = 64
  PreviousChild = 21
  Print = 18
  Quit = 65
  Redo = 12
  Refresh = 15
  Replace = 25
  Save = 5
  SaveAs = 63
  SelectAll = 26
  SelectEndOfBlock = 55
  SelectEndOfDocument = 57
  SelectEndOfLine = 53
  SelectNextChar = 44
  SelectNextLine = 48
  SelectNextPage = 50
  SelectNextWord = 46
  SelectPreviousChar = 45
  SelectPreviousLine = 49
  SelectPreviousPage = 51
  SelectPreviousWord = 47
  SelectStartOfBlock = 54
  SelectStartOfDocument = 56
  SelectStartOfLine = 52
  Underline = 29
  Undo = 11
  UnknownKey = 0
  WhatsThis = 2
  ZoomIn = 16
  ZoomOut = 17

class QLCDNumber(_Mock):
  pass
  Bin = 3
  Box = 1
  Dec = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  Filled = 1
  Flat = 2
  HLine = 4
  Hex = 0
  IgnoreMask = 4
  NoFrame = 0
  Oct = 2
  Outline = 0
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  Raised = 32
  Shadow_Mask = 240
  Shape_Mask = 15
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QLabel(_Mock):
  pass
  AlignCenter = 132
  AlignRight = 2
  AlignVCenter = 128
  Box = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  HLine = 4
  IgnoreMask = 4
  NoFrame = 0
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  Raised = 32
  Shadow_Mask = 240
  Shape_Mask = 15
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QLatin1Char(_Mock):
  pass


class QLatin1String(_Mock):
  pass


class QLayout(_Mock):
  pass
  SetDefaultConstraint = 0
  SetFixedSize = 3
  SetMaximumSize = 4
  SetMinAndMaxSize = 5
  SetMinimumSize = 2
  SetNoConstraint = 1

class QLayoutItem(_Mock):
  pass


class QLibrary(_Mock):
  pass
  ExportExternalSymbolsHint = 2
  LoadArchiveMemberHint = 4
  ResolveAllSymbolsHint = 1

class QLibraryInfo(_Mock):
  pass
  BinariesPath = 4
  DataPath = 6
  DemosPath = 9
  DocumentationPath = 1
  ExamplesPath = 10
  HeadersPath = 2
  ImportsPath = 11
  LibrariesPath = 3
  PluginsPath = 5
  PrefixPath = 0
  SettingsPath = 8
  TranslationsPath = 7

class QLine(_Mock):
  pass


class QLineEdit(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  NoEcho = 1
  Normal = 0
  Password = 2
  PasswordEchoOnEdit = 3
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QLineF(_Mock):
  pass
  BoundedIntersection = 1
  NoIntersection = 0
  UnboundedIntersection = 2

class QLinearGradient(_Mock):
  pass
  ConicalGradient = 2
  LinearGradient = 0
  LogicalMode = 0
  NoGradient = 3
  ObjectBoundingMode = 2
  PadSpread = 0
  RadialGradient = 1
  ReflectSpread = 1
  RepeatSpread = 2
  StretchToDeviceMode = 1

class QListView(_Mock):
  pass
  AboveItem = 1
  Adjust = 1
  AllEditTriggers = 31
  AnimatingState = 6
  AnyKeyPressed = 16
  Batched = 1
  BelowItem = 2
  Box = 1
  CollapsingState = 5
  ContiguousSelection = 4
  CurrentChanged = 1
  DoubleClicked = 2
  DragDrop = 3
  DragOnly = 1
  DragSelectingState = 2
  DraggingState = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  DropOnly = 2
  EditKeyPressed = 8
  EditingState = 3
  EnsureVisible = 0
  ExpandingState = 4
  ExtendedSelection = 3
  Fixed = 0
  Free = 1
  HLine = 4
  IconMode = 1
  IgnoreMask = 4
  InternalMove = 4
  LeftToRight = 0
  ListMode = 0
  MoveDown = 1
  MoveEnd = 5
  MoveHome = 4
  MoveLeft = 2
  MoveNext = 8
  MovePageDown = 7
  MovePageUp = 6
  MovePrevious = 9
  MoveRight = 3
  MoveUp = 0
  MultiSelection = 2
  NoDragDrop = 0
  NoEditTriggers = 0
  NoFrame = 0
  NoSelection = 0
  NoState = 0
  OnItem = 0
  OnViewport = 3
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  PositionAtBottom = 2
  PositionAtCenter = 3
  PositionAtTop = 1
  Raised = 32
  ScrollPerItem = 0
  ScrollPerPixel = 1
  SelectColumns = 2
  SelectItems = 0
  SelectRows = 1
  SelectedClicked = 4
  Shadow_Mask = 240
  Shape_Mask = 15
  SinglePass = 0
  SingleSelection = 1
  Snap = 2
  Static = 0
  StyledPanel = 6
  Sunken = 48
  TopToBottom = 1
  VLine = 5
  WinPanel = 3

class QListWidget(_Mock):
  pass
  AboveItem = 1
  Adjust = 1
  AllEditTriggers = 31
  AnimatingState = 6
  AnyKeyPressed = 16
  Batched = 1
  BelowItem = 2
  Box = 1
  CollapsingState = 5
  ContiguousSelection = 4
  CurrentChanged = 1
  DoubleClicked = 2
  DragDrop = 3
  DragOnly = 1
  DragSelectingState = 2
  DraggingState = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  DropOnly = 2
  EditKeyPressed = 8
  EditingState = 3
  EnsureVisible = 0
  ExpandingState = 4
  ExtendedSelection = 3
  Fixed = 0
  Free = 1
  HLine = 4
  IconMode = 1
  IgnoreMask = 4
  InternalMove = 4
  LeftToRight = 0
  ListMode = 0
  MoveDown = 1
  MoveEnd = 5
  MoveHome = 4
  MoveLeft = 2
  MoveNext = 8
  MovePageDown = 7
  MovePageUp = 6
  MovePrevious = 9
  MoveRight = 3
  MoveUp = 0
  MultiSelection = 2
  NoDragDrop = 0
  NoEditTriggers = 0
  NoFrame = 0
  NoSelection = 0
  NoState = 0
  OnItem = 0
  OnViewport = 3
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  PositionAtBottom = 2
  PositionAtCenter = 3
  PositionAtTop = 1
  Raised = 32
  ScrollPerItem = 0
  ScrollPerPixel = 1
  SelectColumns = 2
  SelectItems = 0
  SelectRows = 1
  SelectedClicked = 4
  Shadow_Mask = 240
  Shape_Mask = 15
  SinglePass = 0
  SingleSelection = 1
  Snap = 2
  Static = 0
  StyledPanel = 6
  Sunken = 48
  TopToBottom = 1
  VLine = 5
  WinPanel = 3

class QListWidgetItem(_Mock):
  pass
  Type = 0
  UserType = 1000

class QLocalServer(_Mock):
  pass


class QLocalSocket(_Mock):
  pass
  Append = 4
  ClosingState = 6
  ConnectedState = 3
  ConnectingState = 2
  ConnectionError = 7
  ConnectionRefusedError = 0
  DatagramTooLargeError = 6
  NotOpen = 0
  PeerClosedError = 1
  ReadOnly = 1
  ReadWrite = 3
  ServerNotFoundError = 2
  SocketAccessError = 3
  SocketResourceError = 4
  SocketTimeoutError = 5
  Text = 16
  Truncate = 8
  Unbuffered = 32
  UnconnectedState = 0
  UnknownSocketError = -1
  UnsupportedSocketOperationError = 10
  WriteOnly = 2

class QLocale(_Mock):
  pass
  Abkhazian = 2
  Afan = 3
  Afar = 4
  Afghanistan = 1
  Afrikaans = 5
  Aghem = 216
  Akan = 146
  Albania = 2
  Albanian = 6
  Algeria = 3
  AlternateQuotation = 1
  AmericanSamoa = 4
  Amharic = 7
  Andorra = 5
  Angola = 6
  Anguilla = 7
  Antarctica = 8
  AntiguaAndBarbuda = 9
  AnyCountry = 0
  AnyLanguage = 0
  AnyScript = 0
  Arabic = 8
  ArabicScript = 1
  Argentina = 10
  Armenia = 11
  Armenian = 9
  Aruba = 12
  Assamese = 10
  Asu = 205
  Atsam = 156
  Australia = 13
  Austria = 14
  Aymara = 11
  Azerbaijan = 15
  Azerbaijani = 12
  Bafia = 222
  Bahamas = 16
  Bahrain = 17
  Bambara = 188
  Bangladesh = 18
  Barbados = 19
  Basaa = 217
  Bashkir = 13
  Basque = 14
  Belarus = 20
  Belgium = 21
  Belize = 22
  Bemba = 195
  Bena = 186
  Bengali = 15
  Benin = 23
  Bermuda = 24
  Bhutan = 25
  Bhutani = 16
  Bihari = 17
  Bislama = 18
  Blin = 152
  Bodo = 215
  Bolivia = 26
  BosniaAndHerzegowina = 27
  Bosnian = 142
  Botswana = 28
  BouvetIsland = 29
  Brazil = 30
  Breton = 19
  BritishIndianOceanTerritory = 31
  BritishVirginIslands = 233
  BruneiDarussalam = 32
  Bulgaria = 33
  Bulgarian = 20
  BurkinaFaso = 34
  Burmese = 21
  Burundi = 35
  Byelorussian = 22
  C = 1
  Cambodia = 36
  Cambodian = 23
  Cameroon = 37
  Canada = 38
  CapeVerde = 39
  Catalan = 24
  CaymanIslands = 40
  CentralAfricanRepublic = 41
  CentralMoroccoTamazight = 212
  Chad = 42
  Cherokee = 190
  Chewa = 165
  Chiga = 211
  Chile = 43
  China = 44
  Chinese = 25
  ChristmasIsland = 45
  CocosIslands = 46
  Colognian = 201
  Colombia = 47
  Comoros = 48
  CongoSwahili = 230
  CookIslands = 51
  Cornish = 145
  Corsican = 26
  CostaRica = 52
  Croatia = 54
  Croatian = 27
  Cuba = 55
  CurrencyDisplayName = 2
  CurrencyIsoCode = 0
  CurrencySymbol = 1
  Cyprus = 56
  CyrillicScript = 2
  Czech = 28
  CzechRepublic = 57
  Danish = 29
  DemocraticRepublicOfCongo = 49
  DemocraticRepublicOfKorea = 113
  Denmark = 58
  DeseretScript = 3
  Divehi = 143
  Djibouti = 59
  Dominica = 60
  DominicanRepublic = 61
  Duala = 219
  Dutch = 30
  EastTimor = 62
  Ecuador = 63
  Egypt = 64
  ElSalvador = 65
  Embu = 189
  English = 31
  EquatorialGuinea = 66
  Eritrea = 67
  Esperanto = 32
  Estonia = 68
  Estonian = 33
  Ethiopia = 69
  Ewe = 161
  Ewondo = 221
  FalklandIslands = 70
  FaroeIslands = 71
  Faroese = 34
  FijiCountry = 72
  FijiLanguage = 35
  Filipino = 166
  Finland = 73
  Finnish = 36
  France = 74
  French = 37
  FrenchGuiana = 76
  FrenchPolynesia = 77
  FrenchSouthernTerritories = 78
  Frisian = 38
  Friulian = 159
  Fulah = 177
  Ga = 148
  Gabon = 79
  Gaelic = 39
  Galician = 40
  Gambia = 80
  Ganda = 194
  Geez = 153
  Georgia = 81
  Georgian = 41
  German = 42
  Germany = 82
  Ghana = 83
  Gibraltar = 84
  Greece = 85
  Greek = 43
  Greenland = 86
  Greenlandic = 44
  Grenada = 87
  Guadeloupe = 88
  Guam = 89
  Guarani = 45
  Guatemala = 90
  Guinea = 91
  GuineaBissau = 92
  Gujarati = 46
  GurmukhiScript = 4
  Gusii = 175
  Guyana = 93
  Haiti = 94
  Hausa = 47
  Hawaiian = 163
  HeardAndMcDonaldIslands = 95
  Hebrew = 48
  Hindi = 49
  Honduras = 96
  HongKong = 97
  Hungarian = 50
  Hungary = 98
  Iceland = 99
  Icelandic = 51
  Igbo = 149
  ImperialSystem = 1
  India = 100
  Indonesia = 101
  Indonesian = 52
  Interlingua = 53
  Interlingue = 54
  Inuktitut = 55
  Inupiak = 56
  Iran = 102
  Iraq = 103
  Ireland = 104
  Irish = 57
  Israel = 105
  Italian = 58
  Italy = 106
  IvoryCoast = 53
  Jamaica = 107
  Japan = 108
  Japanese = 59
  Javanese = 60
  Jju = 158
  JolaFonyi = 220
  Jordan = 109
  Kabuverdianu = 196
  Kabyle = 184
  Kalenjin = 198
  Kamba = 150
  Kannada = 61
  Kashmiri = 62
  Kazakh = 63
  Kazakhstan = 110
  Kenya = 111
  Kikuyu = 178
  Kinyarwanda = 64
  Kirghiz = 65
  Kiribati = 112
  Konkani = 147
  Korean = 66
  Koro = 154
  KoyraChiini = 208
  KoyraboroSenni = 213
  Kpelle = 169
  Kurdish = 67
  Kurundi = 68
  Kuwait = 115
  Kwasio = 226
  Kyrgyzstan = 116
  Langi = 193
  Lao = 117
  Laothian = 69
  LastCountry = 246
  LastLanguage = 234
  Latin = 70
  LatinAmericaAndTheCaribbean = 246
  LatinScript = 7
  Latvia = 118
  Latvian = 71
  Lebanon = 119
  Lesotho = 120
  Liberia = 121
  LibyanArabJamahiriya = 122
  Liechtenstein = 123
  Lingala = 72
  Lithuania = 124
  Lithuanian = 73
  LongFormat = 0
  LowGerman = 170
  LubaKatanga = 223
  Luo = 210
  Luxembourg = 125
  Luyia = 204
  Macau = 126
  Macedonia = 127
  Macedonian = 74
  Machame = 200
  Madagascar = 128
  MakhuwaMeetto = 224
  Makonde = 192
  Malagasy = 75
  Malawi = 129
  Malay = 76
  Malayalam = 77
  Malaysia = 130
  Maldives = 131
  Mali = 132
  Malta = 133
  Maltese = 78
  Manx = 144
  Maori = 79
  Marathi = 80
  MarshallIslands = 134
  Martinique = 135
  Masai = 202
  Mauritania = 136
  Mauritius = 137
  Mayotte = 138
  Meru = 197
  MetricSystem = 0
  MetropolitanFrance = 75
  Mexico = 139
  Micronesia = 140
  Moldavian = 81
  Moldova = 141
  Monaco = 142
  Mongolia = 143
  Mongolian = 82
  MongolianScript = 8
  Montenegro = 242
  Montserrat = 144
  Morisyen = 191
  Morocco = 145
  Mozambique = 146
  Mundang = 225
  Myanmar = 147
  Nama = 199
  Namibia = 148
  NarrowFormat = 2
  NauruCountry = 149
  NauruLanguage = 83
  Nepal = 150
  Nepali = 84
  Netherlands = 151
  NetherlandsAntilles = 152
  NewCaledonia = 153
  NewZealand = 154
  Nicaragua = 155
  Niger = 156
  Nigeria = 157
  Niue = 158
  NorfolkIsland = 159
  NorthNdebele = 181
  NorthernMarianaIslands = 160
  NorthernSami = 173
  NorthernSotho = 172
  Norway = 161
  Norwegian = 85
  NorwegianBokmal = 85
  NorwegianNynorsk = 141
  Nuer = 227
  Nyankole = 185
  Nynorsk = 141
  Occitan = 86
  Oman = 162
  OmitGroupSeparator = 1
  Oriya = 87
  Pakistan = 163
  Palau = 164
  PalestinianTerritory = 165
  Panama = 166
  PapuaNewGuinea = 167
  Paraguay = 168
  Pashto = 88
  PeoplesRepublicOfCongo = 50
  Persian = 89
  Peru = 169
  Philippines = 170
  Pitcairn = 171
  Poland = 172
  Polish = 90
  Portugal = 173
  Portuguese = 91
  PuertoRico = 174
  Punjabi = 92
  Qatar = 175
  Quechua = 93
  RejectGroupSeparator = 2
  RepublicOfKorea = 114
  Reunion = 176
  RhaetoRomance = 94
  Romania = 177
  Romanian = 95
  Rombo = 182
  Rundi = 68
  Russian = 96
  RussianFederation = 178
  Rwa = 209
  Rwanda = 179
  Saho = 207
  SaintBarthelemy = 244
  SaintKittsAndNevis = 180
  SaintMartin = 245
  Sakha = 228
  Samburu = 179
  Samoa = 183
  Samoan = 97
  SanMarino = 184
  Sangho = 98
  Sangu = 229
  Sanskrit = 99
  SaoTomeAndPrincipe = 185
  SaudiArabia = 186
  Sena = 180
  Senegal = 187
  Serbia = 243
  SerbiaAndMontenegro = 241
  Serbian = 100
  SerboCroatian = 101
  Sesotho = 102
  Setswana = 103
  Seychelles = 188
  Shambala = 214
  Shona = 104
  ShortFormat = 1
  SichuanYi = 168
  Sidamo = 155
  SierraLeone = 189
  SimplifiedChineseScript = 5
  SimplifiedHanScript = 5
  Sindhi = 105
  Singapore = 190
  Singhalese = 106
  Siswati = 107
  Slovak = 108
  Slovakia = 191
  Slovenia = 192
  Slovenian = 109
  Soga = 203
  SolomonIslands = 193
  Somali = 110
  Somalia = 194
  SouthAfrica = 195
  SouthGeorgiaAndTheSouthSandwichIslands = 196
  SouthNdebele = 171
  Spain = 197
  Spanish = 111
  SriLanka = 198
  StHelena = 199
  StLucia = 181
  StPierreAndMiquelon = 200
  StVincentAndTheGrenadines = 182
  StandardQuotation = 0
  Sudan = 201
  Sundanese = 112
  Suriname = 202
  SvalbardAndJanMayenIslands = 203
  Swahili = 113
  Swaziland = 204
  Sweden = 205
  Swedish = 114
  SwissGerman = 167
  Switzerland = 206
  Syriac = 151
  SyrianArabRepublic = 207
  Tachelhit = 183
  Tagalog = 115
  Taita = 176
  Taiwan = 208
  Tajik = 116
  Tajikistan = 209
  Tamil = 117
  Tanzania = 210
  Taroko = 174
  Tasawaq = 231
  Tatar = 118
  Telugu = 119
  Teso = 206
  Thai = 120
  Thailand = 211
  Tibetan = 121
  TifinaghScript = 9
  Tigre = 157
  Tigrinya = 122
  Togo = 212
  Tokelau = 213
  TongaCountry = 214
  TongaLanguage = 123
  TraditionalChineseScript = 6
  TraditionalHanScript = 6
  TrinidadAndTobago = 215
  Tsonga = 124
  Tunisia = 216
  Turkey = 217
  Turkish = 125
  Turkmen = 126
  Turkmenistan = 218
  TurksAndCaicosIslands = 219
  Tuvalu = 220
  Twi = 127
  Tyap = 164
  USVirginIslands = 234
  Uganda = 221
  Uigur = 128
  Ukraine = 222
  Ukrainian = 129
  UnitedArabEmirates = 223
  UnitedKingdom = 224
  UnitedStates = 225
  UnitedStatesMinorOutlyingIslands = 226
  Urdu = 130
  Uruguay = 227
  Uzbek = 131
  Uzbekistan = 228
  Vai = 232
  Vanuatu = 229
  VaticanCityState = 230
  Venda = 160
  Venezuela = 231
  VietNam = 232
  Vietnamese = 132
  Volapuk = 133
  Vunjo = 187
  Walamo = 162
  WallisAndFutunaIslands = 235
  Walser = 233
  Welsh = 134
  WesternSahara = 236
  Wolof = 135
  Xhosa = 136
  Yangben = 234
  Yemen = 237
  Yiddish = 137
  Yoruba = 138
  Yugoslavia = 238
  Zambia = 239
  Zarma = 218
  Zhuang = 139
  Zimbabwe = 240
  Zulu = 140

class QMainWindow(_Mock):
  pass
  AllowNestedDocks = 2
  AllowTabbedDocks = 4
  AnimatedDocks = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  ForceTabbedDocks = 8
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  VerticalTabs = 16

class QMargins(_Mock):
  pass


class QMatrix(_Mock):
  pass


class QMatrix2x2(_Mock):
  pass


class QMatrix2x3(_Mock):
  pass


class QMatrix2x4(_Mock):
  pass


class QMatrix3x2(_Mock):
  pass


class QMatrix3x3(_Mock):
  pass


class QMatrix3x4(_Mock):
  pass


class QMatrix4x2(_Mock):
  pass


class QMatrix4x3(_Mock):
  pass


class QMatrix4x4(_Mock):
  pass


class QMdiArea(_Mock):
  pass
  ActivationHistoryOrder = 2
  Box = 1
  CreationOrder = 0
  DontMaximizeSubWindowOnActivation = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  HLine = 4
  IgnoreMask = 4
  NoFrame = 0
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  Raised = 32
  Shadow_Mask = 240
  Shape_Mask = 15
  StackingOrder = 1
  StyledPanel = 6
  SubWindowView = 0
  Sunken = 48
  TabbedView = 1
  VLine = 5
  WinPanel = 3

class QMdiSubWindow(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  RubberBandMove = 8
  RubberBandResize = 4

class QMenu(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QMenuBar(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QMessageBox(_Mock):
  pass
  Abort = 262144
  AcceptRole = 0
  Accepted = 1
  ActionRole = 3
  Apply = 33554432
  ApplyRole = 8
  ButtonMask = -769
  Cancel = 4194304
  Close = 2097152
  Critical = 3
  Default = 256
  DestructiveRole = 2
  Discard = 8388608
  DrawChildren = 2
  DrawWindowBackground = 1
  Escape = 512
  FirstButton = 1024
  FlagMask = 768
  Help = 16777216
  HelpRole = 4
  Ignore = 1048576
  IgnoreMask = 4
  Information = 1
  InvalidRole = -1
  LastButton = 134217728
  No = 65536
  NoAll = 131072
  NoButton = 0
  NoIcon = 0
  NoRole = 6
  NoToAll = 131072
  Ok = 1024
  Open = 8192
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Question = 4
  RejectRole = 1
  Rejected = 0
  Reset = 67108864
  ResetRole = 7
  RestoreDefaults = 134217728
  Retry = 524288
  Save = 2048
  SaveAll = 4096
  Warning = 2
  Yes = 16384
  YesAll = 32768
  YesRole = 5
  YesToAll = 32768

class QMetaClassInfo(_Mock):
  pass


class QMetaEnum(_Mock):
  pass


class QMetaMethod(_Mock):
  pass
  Constructor = 3
  Method = 0
  Private = 0
  Protected = 1
  Public = 2
  Signal = 1
  Slot = 2

class QMetaObject(_Mock):
  pass


class QMetaProperty(_Mock):
  pass


class QMetaType(_Mock):
  pass
  Bool = 1
  Char = 131
  Double = 6
  FirstGuiType = 63
  Float = 135
  Int = 2
  LastCoreType = 29
  Long = 129
  LongLong = 4
  QBitArray = 13
  QBitmap = 73
  QBrush = 66
  QByteArray = 12
  QChar = 7
  QColor = 67
  QCursor = 74
  QDate = 14
  QDateTime = 16
  QEasingCurve = 29
  QFont = 64
  QIcon = 69
  QImage = 70
  QKeySequence = 76
  QLine = 23
  QLineF = 24
  QLocale = 18
  QMatrix = 80
  QMatrix4x4 = 82
  QObjectStar = 136
  QPalette = 68
  QPen = 77
  QPixmap = 65
  QPoint = 25
  QPointF = 26
  QPolygon = 71
  QQuaternion = 86
  QRect = 19
  QRectF = 20
  QRegExp = 27
  QRegion = 72
  QSize = 21
  QSizeF = 22
  QSizePolicy = 75
  QString = 10
  QStringList = 11
  QTextFormat = 79
  QTextLength = 78
  QTime = 15
  QTransform = 81
  QUrl = 17
  QVariant = 138
  QVariantHash = 28
  QVariantList = 9
  QVariantMap = 8
  QVector2D = 83
  QVector3D = 84
  QVector4D = 85
  QWidgetStar = 137
  Short = 130
  UChar = 134
  UInt = 3
  ULong = 132
  ULongLong = 5
  UShort = 133
  User = 256
  Void = 0
  VoidStar = 128

class QMimeData(_Mock):
  pass


class QMimeSource(_Mock):
  pass


class QModelIndex(_Mock):
  pass


class QMouseEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QMouseEventTransition(_Mock):
  pass


class QMoveEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QMovie(_Mock):
  pass
  CacheAll = 1
  CacheNone = 0
  NotRunning = 0
  Paused = 1
  Running = 2

class QMutex(_Mock):
  pass
  NonRecursive = 0
  Recursive = 1

class QMutexLocker(_Mock):
  pass


class QNetworkAccessManager(_Mock):
  pass
  Accessible = 1
  CustomOperation = 6
  DeleteOperation = 5
  GetOperation = 2
  HeadOperation = 1
  NotAccessible = 0
  PostOperation = 4
  PutOperation = 3
  UnknownAccessibility = -1

class QNetworkAddressEntry(_Mock):
  pass


class QNetworkCacheMetaData(_Mock):
  pass


class QNetworkConfiguration(_Mock):
  pass
  Active = 14
  Bearer2G = 3
  BearerBluetooth = 7
  BearerCDMA2000 = 4
  BearerEthernet = 1
  BearerHSPA = 6
  BearerUnknown = 0
  BearerWCDMA = 5
  BearerWLAN = 2
  BearerWiMAX = 8
  Defined = 2
  Discovered = 6
  InternetAccessPoint = 0
  Invalid = 3
  PrivatePurpose = 2
  PublicPurpose = 1
  ServiceNetwork = 1
  ServiceSpecificPurpose = 3
  Undefined = 1
  UnknownPurpose = 0
  UserChoice = 2

class QNetworkConfigurationManager(_Mock):
  pass
  ApplicationLevelRoaming = 8
  CanStartAndStopInterfaces = 1
  DataStatistics = 32
  DirectConnectionRouting = 2
  ForcedRoaming = 16
  NetworkSessionRequired = 64
  SystemSessionSupport = 4

class QNetworkCookie(_Mock):
  pass
  Full = 1
  NameAndValueOnly = 0

class QNetworkCookieJar(_Mock):
  pass


class QNetworkDiskCache(_Mock):
  pass


class QNetworkInterface(_Mock):
  pass
  CanBroadcast = 4
  CanMulticast = 32
  IsLoopBack = 8
  IsPointToPoint = 16
  IsRunning = 2
  IsUp = 1

class QNetworkProxy(_Mock):
  pass
  CachingCapability = 8
  DefaultProxy = 0
  FtpCachingProxy = 5
  HostNameLookupCapability = 16
  HttpCachingProxy = 4
  HttpProxy = 3
  ListeningCapability = 2
  NoProxy = 2
  Socks5Proxy = 1
  TunnelingCapability = 1
  UdpTunnelingCapability = 4

class QNetworkProxyFactory(_Mock):
  pass


class QNetworkProxyQuery(_Mock):
  pass
  TcpServer = 100
  TcpSocket = 0
  UdpSocket = 1
  UrlRequest = 101

class QNetworkReply(_Mock):
  pass
  Append = 4
  AuthenticationRequiredError = 204
  ConnectionRefusedError = 1
  ContentAccessDenied = 201
  ContentNotFoundError = 203
  ContentOperationNotPermittedError = 202
  ContentReSendError = 205
  HostNotFoundError = 3
  NoError = 0
  NotOpen = 0
  OperationCanceledError = 5
  ProtocolFailure = 399
  ProtocolInvalidOperationError = 302
  ProtocolUnknownError = 301
  ProxyAuthenticationRequiredError = 105
  ProxyConnectionClosedError = 102
  ProxyConnectionRefusedError = 101
  ProxyNotFoundError = 103
  ProxyTimeoutError = 104
  ReadOnly = 1
  ReadWrite = 3
  RemoteHostClosedError = 2
  SslHandshakeFailedError = 6
  TemporaryNetworkFailureError = 7
  Text = 16
  TimeoutError = 4
  Truncate = 8
  Unbuffered = 32
  UnknownContentError = 299
  UnknownNetworkError = 99
  UnknownProxyError = 199
  WriteOnly = 2

class QNetworkRequest(_Mock):
  pass
  AlwaysCache = 3
  AlwaysNetwork = 0
  AuthenticationReuseAttribute = 12
  Automatic = 0
  CacheLoadControlAttribute = 4
  CacheSaveControlAttribute = 5
  ConnectionEncryptedAttribute = 3
  ContentDispositionHeader = 6
  ContentLengthHeader = 1
  ContentTypeHeader = 0
  CookieHeader = 4
  CookieLoadControlAttribute = 11
  CookieSaveControlAttribute = 13
  CustomVerbAttribute = 10
  DoNotBufferUploadDataAttribute = 7
  HighPriority = 1
  HttpPipeliningAllowedAttribute = 8
  HttpPipeliningWasUsedAttribute = 9
  HttpReasonPhraseAttribute = 1
  HttpStatusCodeAttribute = 0
  LastModifiedHeader = 3
  LocationHeader = 2
  LowPriority = 5
  Manual = 1
  NormalPriority = 3
  PreferCache = 2
  PreferNetwork = 1
  RedirectionTargetAttribute = 2
  SetCookieHeader = 5
  SourceIsFromCacheAttribute = 6
  User = 1000
  UserMax = 32767

class QNetworkSession(_Mock):
  pass
  Closing = 4
  Connected = 3
  Connecting = 2
  Disconnected = 5
  Invalid = 0
  InvalidConfigurationError = 4
  NotAvailable = 1
  OperationNotSupportedError = 3
  Roaming = 6
  RoamingError = 2
  SessionAbortedError = 1
  UnknownSessionError = 0

class QObject(_Mock):
  pass


class QObjectCleanupHandler(_Mock):
  pass


class QPageSetupDialog(_Mock):
  pass
  Accepted = 1
  DontUseSheet = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Rejected = 0

class QPaintDevice(_Mock):
  pass
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QPaintEngine(_Mock):
  pass
  AllDirty = 65535
  AllFeatures = -1
  AlphaBlend = 128
  Antialiasing = 1024
  BlendModes = 32768
  Blitter = 16
  BrushStroke = 2048
  ConicalGradientFill = 64
  ConstantOpacity = 4096
  ConvexMode = 2
  CoreGraphics = 3
  Direct3D = 11
  DirtyBackground = 16
  DirtyBackgroundMode = 32
  DirtyBrush = 2
  DirtyBrushOrigin = 4
  DirtyClipEnabled = 2048
  DirtyClipPath = 256
  DirtyClipRegion = 128
  DirtyCompositionMode = 1024
  DirtyFont = 8
  DirtyHints = 512
  DirtyOpacity = 4096
  DirtyPen = 1
  DirtyTransform = 64
  LinearGradientFill = 16
  MacPrinter = 4
  MaskedBrush = 8192
  MaxUser = 100
  ObjectBoundingModeGradients = 65536
  OddEvenMode = 0
  OpenGL = 7
  OpenGL2 = 14
  OpenVG = 13
  PaintBuffer = 15
  PaintOutsidePaintEvent = 536870912
  PainterPaths = 512
  PatternBrush = 8
  PatternTransform = 2
  Pdf = 12
  PerspectiveTransform = 16384
  Picture = 8
  PixmapTransform = 4
  PolylineMode = 3
  PorterDuff = 256
  PostScript = 6
  PrimitiveTransform = 1
  QWindowSystem = 5
  QuickDraw = 2
  RadialGradientFill = 32
  Raster = 10
  RasterOpModes = 131072
  SVG = 9
  User = 50
  WindingMode = 1
  Windows = 1
  X11 = 0

class QPaintEngineState(_Mock):
  pass


class QPaintEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QPainter(_Mock):
  pass
  Antialiasing = 1
  CompositionMode_Clear = 2
  CompositionMode_ColorBurn = 19
  CompositionMode_ColorDodge = 18
  CompositionMode_Darken = 16
  CompositionMode_Destination = 4
  CompositionMode_DestinationAtop = 10
  CompositionMode_DestinationIn = 6
  CompositionMode_DestinationOut = 8
  CompositionMode_DestinationOver = 1
  CompositionMode_Difference = 22
  CompositionMode_Exclusion = 23
  CompositionMode_HardLight = 20
  CompositionMode_Lighten = 17
  CompositionMode_Multiply = 13
  CompositionMode_Overlay = 15
  CompositionMode_Plus = 12
  CompositionMode_Screen = 14
  CompositionMode_SoftLight = 21
  CompositionMode_Source = 3
  CompositionMode_SourceAtop = 9
  CompositionMode_SourceIn = 5
  CompositionMode_SourceOut = 7
  CompositionMode_SourceOver = 0
  CompositionMode_Xor = 11
  HighQualityAntialiasing = 8
  NonCosmeticDefaultPen = 16
  OpaqueHint = 1
  RasterOp_NotSource = 30
  RasterOp_NotSourceAndDestination = 31
  RasterOp_NotSourceAndNotDestination = 27
  RasterOp_NotSourceOrNotDestination = 28
  RasterOp_NotSourceXorDestination = 29
  RasterOp_SourceAndDestination = 25
  RasterOp_SourceAndNotDestination = 32
  RasterOp_SourceOrDestination = 24
  RasterOp_SourceXorDestination = 26
  SmoothPixmapTransform = 4
  TextAntialiasing = 2

class QPainterPath(_Mock):
  pass
  CurveToDataElement = 3
  CurveToElement = 2
  LineToElement = 1
  MoveToElement = 0

class QPainterPathStroker(_Mock):
  pass


class QPalette(_Mock):
  pass
  Active = 0
  All = 5
  AlternateBase = 16
  Background = 10
  Base = 9
  BrightText = 7
  Button = 1
  ButtonText = 8
  Current = 4
  Dark = 4
  Disabled = 1
  Foreground = 0
  Highlight = 12
  HighlightedText = 13
  Inactive = 2
  Light = 2
  Link = 14
  LinkVisited = 15
  Mid = 5
  Midlight = 3
  NColorGroups = 3
  NColorRoles = 20
  NoRole = 17
  Normal = 0
  Shadow = 11
  Text = 6
  ToolTipBase = 18
  ToolTipText = 19
  Window = 10
  WindowText = 0

class QPanGesture(_Mock):
  pass
  CancelAllInContext = 1
  CancelNone = 0

class QParallelAnimationGroup(_Mock):
  pass
  Backward = 1
  DeleteWhenStopped = 1
  Forward = 0
  KeepWhenStopped = 0
  Paused = 1
  Running = 2
  Stopped = 0

class QPauseAnimation(_Mock):
  pass
  Backward = 1
  DeleteWhenStopped = 1
  Forward = 0
  KeepWhenStopped = 0
  Paused = 1
  Running = 2
  Stopped = 0

class QPen(_Mock):
  pass


class QPersistentModelIndex(_Mock):
  pass


class QPicture(_Mock):
  pass
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QPictureIO(_Mock):
  pass


class QPinchGesture(_Mock):
  pass
  CancelAllInContext = 1
  CancelNone = 0
  CenterPointChanged = 4
  RotationAngleChanged = 2
  ScaleFactorChanged = 1

class QPixmap(_Mock):
  pass
  ExplicitlyShared = 1
  ImplicitlyShared = 0
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QPixmapCache(_Mock):
  pass


class QPlainTextDocumentLayout(_Mock):
  pass


class QPlainTextEdit(_Mock):
  pass
  Box = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  HLine = 4
  IgnoreMask = 4
  NoFrame = 0
  NoWrap = 0
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  Raised = 32
  Shadow_Mask = 240
  Shape_Mask = 15
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WidgetWidth = 1
  WinPanel = 3

class QPluginLoader(_Mock):
  pass


class QPoint(_Mock):
  pass


class QPointF(_Mock):
  pass


class QPolygon(_Mock):
  pass


class QPolygonF(_Mock):
  pass


class QPrintDialog(_Mock):
  pass
  Accepted = 1
  AllPages = 0
  CurrentPage = 3
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  None_ = 0
  PageRange = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  PrintCollateCopies = 16
  PrintCurrentPage = 64
  PrintPageRange = 4
  PrintSelection = 2
  PrintShowPageSize = 8
  PrintToFile = 1
  Rejected = 0
  Selection = 1

class QPrintEngine(_Mock):
  pass
  PPK_CollateCopies = 0
  PPK_ColorMode = 1
  PPK_CopyCount = 25
  PPK_Creator = 2
  PPK_CustomBase = 65280
  PPK_CustomPaperSize = 23
  PPK_DocumentName = 3
  PPK_Duplex = 21
  PPK_FontEmbedding = 19
  PPK_FullPage = 4
  PPK_NumberOfCopies = 5
  PPK_Orientation = 6
  PPK_OutputFileName = 7
  PPK_PageMargins = 24
  PPK_PageOrder = 8
  PPK_PageRect = 9
  PPK_PageSize = 10
  PPK_PaperRect = 11
  PPK_PaperSize = 10
  PPK_PaperSource = 12
  PPK_PaperSources = 22
  PPK_PrinterName = 13
  PPK_PrinterProgram = 14
  PPK_Resolution = 15
  PPK_SelectionOption = 16
  PPK_SupportedResolutions = 17
  PPK_SupportsMultipleCopies = 26
  PPK_SuppressSystemPrintStatus = 20
  PPK_WindowsPageSize = 18

class QPrintPreviewDialog(_Mock):
  pass
  Accepted = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Rejected = 0

class QPrintPreviewWidget(_Mock):
  pass
  AllPagesView = 2
  CustomZoom = 0
  DrawChildren = 2
  DrawWindowBackground = 1
  FacingPagesView = 1
  FitInView = 2
  FitToWidth = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  SinglePageView = 0

class QPrinter(_Mock):
  pass
  A0 = 5
  A1 = 6
  A2 = 7
  A3 = 8
  A4 = 0
  A5 = 9
  A6 = 10
  A7 = 11
  A8 = 12
  A9 = 13
  Aborted = 2
  Active = 1
  AllPages = 0
  Auto = 6
  B0 = 14
  B1 = 15
  B10 = 16
  B2 = 17
  B3 = 18
  B4 = 19
  B5 = 1
  B6 = 20
  B7 = 21
  B8 = 22
  B9 = 23
  C5E = 24
  Cassette = 11
  Cicero = 5
  Color = 1
  Comm10E = 25
  CurrentPage = 3
  Custom = 30
  DLE = 26
  DevicePixel = 6
  Didot = 4
  DuplexAuto = 1
  DuplexLongSide = 2
  DuplexNone = 0
  DuplexShortSide = 3
  Envelope = 4
  EnvelopeManual = 5
  Error = 3
  Executive = 4
  FirstPageFirst = 0
  Folio = 27
  FormSource = 12
  GrayScale = 0
  HighResolution = 2
  Idle = 0
  Inch = 2
  Landscape = 1
  LargeCapacity = 10
  LargeFormat = 9
  LastPageFirst = 1
  Ledger = 28
  Legal = 3
  Letter = 2
  Lower = 1
  Manual = 3
  MaxPageSource = 13
  Middle = 2
  Millimeter = 0
  NativeFormat = 0
  OnlyOne = 0
  PageRange = 2
  PdfFormat = 1
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Pica = 3
  Point = 1
  Portrait = 0
  PostScriptFormat = 2
  PrinterResolution = 1
  ScreenResolution = 0
  Selection = 1
  SmallFormat = 8
  Tabloid = 29
  Tractor = 7

class QPrinterInfo(_Mock):
  pass


class QProcess(_Mock):
  pass
  Append = 4
  CrashExit = 1
  Crashed = 1
  FailedToStart = 0
  ForwardedChannels = 2
  MergedChannels = 1
  NormalExit = 0
  NotOpen = 0
  NotRunning = 0
  ReadError = 3
  ReadOnly = 1
  ReadWrite = 3
  Running = 2
  SeparateChannels = 0
  StandardError = 1
  StandardOutput = 0
  Starting = 1
  Text = 16
  Timedout = 2
  Truncate = 8
  Unbuffered = 32
  UnknownError = 5
  WriteError = 4
  WriteOnly = 2

class QProcessEnvironment(_Mock):
  pass


class QProgressBar(_Mock):
  pass
  BottomToTop = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  TopToBottom = 0

class QProgressDialog(_Mock):
  pass
  Accepted = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Rejected = 0

class QPropertyAnimation(_Mock):
  pass
  Backward = 1
  DeleteWhenStopped = 1
  Forward = 0
  KeepWhenStopped = 0
  Paused = 1
  Running = 2
  Stopped = 0

class QProxyModel(_Mock):
  pass


class QPushButton(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QPyDeclarativePropertyValueSource(_Mock):
  pass


class QPyDesignerContainerExtension(_Mock):
  pass


class QPyDesignerCustomWidgetCollectionPlugin(_Mock):
  pass


class QPyDesignerCustomWidgetPlugin(_Mock):
  pass


class QPyDesignerMemberSheetExtension(_Mock):
  pass


class QPyDesignerPropertySheetExtension(_Mock):
  pass


class QPyDesignerTaskMenuExtension(_Mock):
  pass


class QPyTextObject(_Mock):
  pass


class QQuaternion(_Mock):
  pass


class QRadialGradient(_Mock):
  pass
  ConicalGradient = 2
  LinearGradient = 0
  LogicalMode = 0
  NoGradient = 3
  ObjectBoundingMode = 2
  PadSpread = 0
  RadialGradient = 1
  ReflectSpread = 1
  RepeatSpread = 2
  StretchToDeviceMode = 1

class QRadioButton(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QRawFont(_Mock):
  pass
  PixelAntialiasing = 0
  SubPixelAntialiasing = 1

class QReadLocker(_Mock):
  pass


class QReadWriteLock(_Mock):
  pass
  NonRecursive = 0
  Recursive = 1

class QRect(_Mock):
  pass


class QRectF(_Mock):
  pass


class QRegExp(_Mock):
  pass
  CaretAtOffset = 1
  CaretAtZero = 0
  CaretWontMatch = 2
  FixedString = 2
  RegExp = 0
  RegExp2 = 3
  W3CXmlSchema11 = 5
  Wildcard = 1
  WildcardUnix = 4

class QRegExpValidator(_Mock):
  pass
  Acceptable = 2
  Intermediate = 1
  Invalid = 0

class QRegion(_Mock):
  pass
  Ellipse = 1
  Rectangle = 0

class QResizeEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QResource(_Mock):
  pass


class QRubberBand(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  Line = 0
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Rectangle = 1

class QRunnable(_Mock):
  pass


class QScriptClass(_Mock):
  pass
  Callable = 0
  HandlesReadAccess = 1
  HandlesWriteAccess = 2
  HasInstance = 1

class QScriptClassPropertyIterator(_Mock):
  pass


class QScriptContext(_Mock):
  pass
  ExceptionState = 1
  NormalState = 0
  RangeError = 4
  ReferenceError = 1
  SyntaxError = 2
  TypeError = 3
  URIError = 5
  UnknownError = 0

class QScriptContextInfo(_Mock):
  pass
  NativeFunction = 3
  QtFunction = 1
  QtPropertyFunction = 2
  ScriptFunction = 0

class QScriptEngine(_Mock):
  pass
  AutoCreateDynamicProperties = 256
  AutoOwnership = 2
  ExcludeChildObjects = 1
  ExcludeDeleteLater = 16
  ExcludeSlots = 32
  ExcludeSuperClassContents = 6
  ExcludeSuperClassMethods = 2
  ExcludeSuperClassProperties = 4
  PreferExistingWrapperObject = 512
  QtOwnership = 0
  ScriptOwnership = 1
  SkipMethodsInEnumeration = 8

class QScriptEngineAgent(_Mock):
  pass
  DebuggerInvocationRequest = 0

class QScriptEngineDebugger(_Mock):
  pass
  BreakpointsWidget = 6
  ClearConsoleAction = 10
  ClearDebugOutputAction = 8
  ClearErrorLogAction = 9
  CodeFinderWidget = 5
  CodeWidget = 4
  ConsoleWidget = 0
  ContinueAction = 1
  DebugOutputWidget = 7
  ErrorLogWidget = 8
  FindInScriptAction = 11
  FindNextInScriptAction = 12
  FindPreviousInScriptAction = 13
  GoToLineAction = 14
  InterruptAction = 0
  LocalsWidget = 3
  RunToCursorAction = 5
  RunToNewScriptAction = 6
  RunningState = 0
  ScriptsWidget = 2
  StackWidget = 1
  StepIntoAction = 2
  StepOutAction = 4
  StepOverAction = 3
  SuspendedState = 1
  ToggleBreakpointAction = 7

class QScriptString(_Mock):
  pass


class QScriptSyntaxCheckResult(_Mock):
  pass
  Error = 0
  Intermediate = 1
  Valid = 2

class QScriptValue(_Mock):
  pass
  KeepExistingFlags = 2048
  NullValue = 0
  PropertyGetter = 8
  PropertySetter = 16
  QObjectMember = 32
  ReadOnly = 1
  ResolveFull = 3
  ResolveLocal = 0
  ResolvePrototype = 1
  ResolveScope = 2
  SkipInEnumeration = 4
  UndefinedValue = 1
  Undeletable = 2
  UserRange = -16777216

class QScriptValueIterator(_Mock):
  pass


class QScrollArea(_Mock):
  pass
  Box = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  HLine = 4
  IgnoreMask = 4
  NoFrame = 0
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  Raised = 32
  Shadow_Mask = 240
  Shape_Mask = 15
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QScrollBar(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  SliderMove = 7
  SliderNoAction = 0
  SliderOrientationChange = 1
  SliderPageStepAdd = 3
  SliderPageStepSub = 4
  SliderRangeChange = 0
  SliderSingleStepAdd = 1
  SliderSingleStepSub = 2
  SliderStepsChange = 2
  SliderToMaximum = 6
  SliderToMinimum = 5
  SliderValueChange = 3

class QSemaphore(_Mock):
  pass


class QSequentialAnimationGroup(_Mock):
  pass
  Backward = 1
  DeleteWhenStopped = 1
  Forward = 0
  KeepWhenStopped = 0
  Paused = 1
  Running = 2
  Stopped = 0

class QSessionManager(_Mock):
  pass
  RestartAnyway = 1
  RestartIfRunning = 0
  RestartImmediately = 2
  RestartNever = 3

class QSettings(_Mock):
  pass
  AccessError = 1
  FormatError = 2
  IniFormat = 1
  InvalidFormat = 16
  NativeFormat = 0
  NoError = 0
  SystemScope = 1
  UserScope = 0

class QSharedMemory(_Mock):
  pass
  AlreadyExists = 4
  InvalidSize = 2
  KeyError = 3
  LockError = 6
  NoError = 0
  NotFound = 5
  OutOfResources = 7
  PermissionDenied = 1
  ReadOnly = 0
  ReadWrite = 1
  UnknownError = 8

class QShortcut(_Mock):
  pass


class QShortcutEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QShowEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QSignalMapper(_Mock):
  pass


class QSignalTransition(_Mock):
  pass


class QSimpleXmlNodeModel(_Mock):
  pass
  FirstChild = 1
  NextSibling = 3
  Parent = 0
  PreviousSibling = 2

class QSize(_Mock):
  pass


class QSizeF(_Mock):
  pass


class QSizeGrip(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QSizePolicy(_Mock):
  pass
  ButtonBox = 2
  CheckBox = 4
  ComboBox = 8
  DefaultType = 1
  ExpandFlag = 2
  Expanding = 7
  Fixed = 0
  Frame = 16
  GroupBox = 32
  GrowFlag = 1
  IgnoreFlag = 8
  Ignored = 13
  Label = 64
  Line = 128
  LineEdit = 256
  Maximum = 4
  Minimum = 1
  MinimumExpanding = 3
  Preferred = 5
  PushButton = 512
  RadioButton = 1024
  ShrinkFlag = 4
  Slider = 2048
  SpinBox = 4096
  TabWidget = 8192
  ToolButton = 16384

class QSlider(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  NoTicks = 0
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  SliderMove = 7
  SliderNoAction = 0
  SliderOrientationChange = 1
  SliderPageStepAdd = 3
  SliderPageStepSub = 4
  SliderRangeChange = 0
  SliderSingleStepAdd = 1
  SliderSingleStepSub = 2
  SliderStepsChange = 2
  SliderToMaximum = 6
  SliderToMinimum = 5
  SliderValueChange = 3
  TicksAbove = 1
  TicksBelow = 2
  TicksBothSides = 3
  TicksLeft = 1
  TicksRight = 2

class QSocketNotifier(_Mock):
  pass
  Exception = 2
  Read = 0
  Write = 1

class QSortFilterProxyModel(_Mock):
  pass


class QSound(_Mock):
  pass


class QSourceLocation(_Mock):
  pass


class QSpacerItem(_Mock):
  pass


class QSpinBox(_Mock):
  pass
  CorrectToNearestValue = 1
  CorrectToPreviousValue = 0
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  NoButtons = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  PlusMinus = 1
  StepDownEnabled = 2
  StepNone = 0
  StepUpEnabled = 1
  UpDownArrows = 0

class QSplashScreen(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QSplitter(_Mock):
  pass
  Box = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  HLine = 4
  IgnoreMask = 4
  NoFrame = 0
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  Raised = 32
  Shadow_Mask = 240
  Shape_Mask = 15
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QSplitterHandle(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QSsl(_Mock):
  pass
  AnyProtocol = 3
  Der = 1
  DnsEntry = 1
  Dsa = 1
  EmailEntry = 0
  Pem = 0
  PrivateKey = 0
  PublicKey = 1
  Rsa = 0
  SecureProtocols = 5
  SslOptionDisableCompression = 4
  SslOptionDisableEmptyFragments = 1
  SslOptionDisableLegacyRenegotiation = 16
  SslOptionDisableServerNameIndication = 8
  SslOptionDisableSessionTickets = 2
  SslV2 = 1
  SslV3 = 0
  TlsV1 = 2
  TlsV1SslV3 = 4
  UnknownProtocol = -1

class QSslCertificate(_Mock):
  pass
  CommonName = 1
  CountryName = 4
  LocalityName = 2
  Organization = 0
  OrganizationalUnitName = 3
  StateOrProvinceName = 5

class QSslCipher(_Mock):
  pass


class QSslConfiguration(_Mock):
  pass


class QSslError(_Mock):
  pass
  AuthorityIssuerSerialNumberMismatch = 20
  CertificateBlacklisted = 24
  CertificateExpired = 6
  CertificateNotYetValid = 5
  CertificateRejected = 18
  CertificateRevoked = 13
  CertificateSignatureFailed = 4
  CertificateUntrusted = 17
  HostNameMismatch = 22
  InvalidCaCertificate = 14
  InvalidNotAfterField = 8
  InvalidNotBeforeField = 7
  InvalidPurpose = 16
  NoError = 0
  NoPeerCertificate = 21
  NoSslSupport = 23
  PathLengthExceeded = 15
  SelfSignedCertificate = 9
  SelfSignedCertificateInChain = 10
  SubjectIssuerMismatch = 19
  UnableToDecodeIssuerPublicKey = 3
  UnableToDecryptCertificateSignature = 2
  UnableToGetIssuerCertificate = 1
  UnableToGetLocalIssuerCertificate = 11
  UnableToVerifyFirstCertificate = 12
  UnspecifiedError = -1

class QSslKey(_Mock):
  pass


class QSslSocket(_Mock):
  pass
  AddressInUseError = 8
  Append = 4
  AutoVerifyPeer = 3
  BoundState = 4
  ClosingState = 6
  ConnectedState = 3
  ConnectingState = 2
  ConnectionRefusedError = 0
  DatagramTooLargeError = 6
  HostLookupState = 1
  HostNotFoundError = 2
  IPv4Protocol = 0
  IPv6Protocol = 1
  KeepAliveOption = 1
  ListeningState = 5
  LowDelayOption = 0
  MulticastLoopbackOption = 3
  MulticastTtlOption = 2
  NetworkError = 7
  NotOpen = 0
  ProxyAuthenticationRequiredError = 12
  ProxyConnectionClosedError = 15
  ProxyConnectionRefusedError = 14
  ProxyConnectionTimeoutError = 16
  ProxyNotFoundError = 17
  ProxyProtocolError = 18
  QueryPeer = 1
  ReadOnly = 1
  ReadWrite = 3
  RemoteHostClosedError = 1
  SocketAccessError = 3
  SocketAddressNotAvailableError = 9
  SocketResourceError = 4
  SocketTimeoutError = 5
  SslClientMode = 1
  SslHandshakeFailedError = 13
  SslServerMode = 2
  TcpSocket = 0
  Text = 16
  Truncate = 8
  UdpSocket = 1
  Unbuffered = 32
  UnconnectedState = 0
  UnencryptedMode = 0
  UnfinishedSocketOperationError = 11
  UnknownNetworkLayerProtocol = -1
  UnknownSocketError = -1
  UnknownSocketType = -1
  UnsupportedSocketOperationError = 10
  VerifyNone = 0
  VerifyPeer = 2
  WriteOnly = 2

class QStackedLayout(_Mock):
  pass
  SetDefaultConstraint = 0
  SetFixedSize = 3
  SetMaximumSize = 4
  SetMinAndMaxSize = 5
  SetMinimumSize = 2
  SetNoConstraint = 1
  StackAll = 1
  StackOne = 0

class QStackedWidget(_Mock):
  pass
  Box = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  HLine = 4
  IgnoreMask = 4
  NoFrame = 0
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  Raised = 32
  Shadow_Mask = 240
  Shape_Mask = 15
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QStandardItem(_Mock):
  pass
  Type = 0
  UserType = 1000

class QStandardItemModel(_Mock):
  pass


class QState(_Mock):
  pass
  ExclusiveStates = 0
  ParallelStates = 1

class QStateMachine(_Mock):
  pass
  DontRestoreProperties = 0
  ExclusiveStates = 0
  HighPriority = 1
  NoCommonAncestorForTransitionError = 3
  NoDefaultStateInHistoryStateError = 2
  NoError = 0
  NoInitialStateError = 1
  NormalPriority = 0
  ParallelStates = 1
  RestoreProperties = 1

class QStaticText(_Mock):
  pass
  AggressiveCaching = 1
  ModerateCaching = 0

class QStatusBar(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QStatusTipEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QString(_Mock):
  pass
  KeepEmptyParts = 0
  NormalizationForm_C = 1
  NormalizationForm_D = 0
  NormalizationForm_KC = 3
  NormalizationForm_KD = 2
  SectionCaseInsensitiveSeps = 8
  SectionDefault = 0
  SectionIncludeLeadingSep = 2
  SectionIncludeTrailingSep = 4
  SectionSkipEmpty = 1
  SkipEmptyParts = 1

class QStringList(_Mock):
  pass


class QStringListModel(_Mock):
  pass


class QStringMatcher(_Mock):
  pass


class QStringRef(_Mock):
  pass


class QStyle(_Mock):
  pass
  CC_ComboBox = 1
  CC_CustomBase = -268435456
  CC_Dial = 7
  CC_GroupBox = 8
  CC_MdiControls = 9
  CC_Q3ListView = 6
  CC_ScrollBar = 2
  CC_Slider = 3
  CC_SpinBox = 0
  CC_TitleBar = 5
  CC_ToolButton = 4
  CE_CheckBox = 3
  CE_CheckBoxLabel = 4
  CE_ColumnViewGrip = 45
  CE_ComboBoxLabel = 40
  CE_CustomBase = -268435456
  CE_DockWidgetTitle = 31
  CE_FocusFrame = 39
  CE_Header = 23
  CE_HeaderEmptyArea = 44
  CE_HeaderLabel = 25
  CE_HeaderSection = 24
  CE_ItemViewItem = 46
  CE_MenuBarEmptyArea = 21
  CE_MenuBarItem = 20
  CE_MenuEmptyArea = 19
  CE_MenuHMargin = 17
  CE_MenuItem = 14
  CE_MenuScroller = 15
  CE_MenuTearoff = 18
  CE_MenuVMargin = 16
  CE_ProgressBar = 10
  CE_ProgressBarContents = 12
  CE_ProgressBarGroove = 11
  CE_ProgressBarLabel = 13
  CE_PushButton = 0
  CE_PushButtonBevel = 1
  CE_PushButtonLabel = 2
  CE_Q3DockWindowEmptyArea = 26
  CE_RadioButton = 5
  CE_RadioButtonLabel = 6
  CE_RubberBand = 30
  CE_ScrollBarAddLine = 32
  CE_ScrollBarAddPage = 34
  CE_ScrollBarFirst = 37
  CE_ScrollBarLast = 38
  CE_ScrollBarSlider = 36
  CE_ScrollBarSubLine = 33
  CE_ScrollBarSubPage = 35
  CE_ShapedFrame = 47
  CE_SizeGrip = 28
  CE_Splitter = 29
  CE_TabBarTab = 7
  CE_TabBarTabLabel = 9
  CE_TabBarTabShape = 8
  CE_ToolBar = 41
  CE_ToolBoxTab = 27
  CE_ToolBoxTabLabel = 43
  CE_ToolBoxTabShape = 42
  CE_ToolButtonLabel = 22
  CT_CheckBox = 1
  CT_ComboBox = 4
  CT_CustomBase = -268435456
  CT_DialogButtons = 20
  CT_GroupBox = 22
  CT_HeaderSection = 21
  CT_ItemViewItem = 24
  CT_LineEdit = 16
  CT_MdiControls = 23
  CT_Menu = 11
  CT_MenuBar = 10
  CT_MenuBarItem = 9
  CT_MenuItem = 8
  CT_ProgressBar = 7
  CT_PushButton = 0
  CT_Q3DockWindow = 6
  CT_Q3Header = 15
  CT_RadioButton = 2
  CT_ScrollBar = 14
  CT_SizeGrip = 18
  CT_Slider = 13
  CT_SpinBox = 17
  CT_Splitter = 5
  CT_TabBarTab = 12
  CT_TabWidget = 19
  CT_ToolButton = 3
  PE_CustomBase = 251658240
  PE_Frame = 5
  PE_FrameButtonBevel = 15
  PE_FrameButtonTool = 16
  PE_FrameDefaultButton = 6
  PE_FrameDockWidget = 7
  PE_FrameFocusRect = 8
  PE_FrameGroupBox = 9
  PE_FrameLineEdit = 10
  PE_FrameMenu = 11
  PE_FrameStatusBar = 12
  PE_FrameStatusBarItem = 12
  PE_FrameTabBarBase = 17
  PE_FrameTabWidget = 13
  PE_FrameWindow = 14
  PE_IndicatorArrowDown = 24
  PE_IndicatorArrowLeft = 25
  PE_IndicatorArrowRight = 26
  PE_IndicatorArrowUp = 27
  PE_IndicatorBranch = 28
  PE_IndicatorButtonDropDown = 29
  PE_IndicatorCheckBox = 31
  PE_IndicatorColumnViewArrow = 47
  PE_IndicatorDockWidgetResizeHandle = 32
  PE_IndicatorHeaderArrow = 33
  PE_IndicatorItemViewItemCheck = 30
  PE_IndicatorItemViewItemDrop = 48
  PE_IndicatorMenuCheckMark = 34
  PE_IndicatorProgressChunk = 35
  PE_IndicatorRadioButton = 36
  PE_IndicatorSpinDown = 37
  PE_IndicatorSpinMinus = 38
  PE_IndicatorSpinPlus = 39
  PE_IndicatorSpinUp = 40
  PE_IndicatorTabClose = 52
  PE_IndicatorTabTear = 44
  PE_IndicatorToolBarHandle = 41
  PE_IndicatorToolBarSeparator = 42
  PE_IndicatorViewItemCheck = 30
  PE_PanelButtonBevel = 19
  PE_PanelButtonCommand = 18
  PE_PanelButtonTool = 20
  PE_PanelItemViewItem = 49
  PE_PanelItemViewRow = 50
  PE_PanelLineEdit = 23
  PE_PanelMenu = 53
  PE_PanelMenuBar = 21
  PE_PanelScrollAreaCorner = 45
  PE_PanelStatusBar = 51
  PE_PanelTipLabel = 43
  PE_PanelToolBar = 22
  PE_Q3CheckListController = 0
  PE_Q3CheckListExclusiveIndicator = 1
  PE_Q3CheckListIndicator = 2
  PE_Q3DockWindowSeparator = 3
  PE_Q3Separator = 4
  PE_Widget = 46
  PM_ButtonDefaultIndicator = 1
  PM_ButtonIconSize = 77
  PM_ButtonMargin = 0
  PM_ButtonShiftHorizontal = 3
  PM_ButtonShiftVertical = 4
  PM_CheckBoxLabelSpacing = 72
  PM_CheckListButtonSize = 41
  PM_CheckListControllerSize = 42
  PM_ComboBoxFrameWidth = 7
  PM_CustomBase = -268435456
  PM_DefaultChildMargin = 62
  PM_DefaultFrameWidth = 5
  PM_DefaultLayoutSpacing = 63
  PM_DefaultTopLevelMargin = 61
  PM_DialogButtonsButtonHeight = 45
  PM_DialogButtonsButtonWidth = 44
  PM_DialogButtonsSeparator = 43
  PM_DockWidgetFrameWidth = 18
  PM_DockWidgetHandleExtent = 17
  PM_DockWidgetSeparatorExtent = 16
  PM_DockWidgetTitleBarButtonMargin = 78
  PM_DockWidgetTitleMargin = 75
  PM_ExclusiveIndicatorHeight = 40
  PM_ExclusiveIndicatorWidth = 39
  PM_FocusFrameHMargin = 70
  PM_FocusFrameVMargin = 69
  PM_HeaderGripMargin = 50
  PM_HeaderMargin = 48
  PM_HeaderMarkSize = 49
  PM_IconViewIconSize = 66
  PM_IndicatorHeight = 38
  PM_IndicatorWidth = 37
  PM_LargeIconSize = 68
  PM_LayoutBottomMargin = 83
  PM_LayoutHorizontalSpacing = 84
  PM_LayoutLeftMargin = 80
  PM_LayoutRightMargin = 82
  PM_LayoutTopMargin = 81
  PM_LayoutVerticalSpacing = 85
  PM_ListViewIconSize = 65
  PM_MDIFrameWidth = 46
  PM_MDIMinimizedWidth = 47
  PM_MaximumDragDistance = 8
  PM_MdiSubWindowFrameWidth = 46
  PM_MdiSubWindowMinimizedWidth = 47
  PM_MenuBarHMargin = 36
  PM_MenuBarItemSpacing = 34
  PM_MenuBarPanelWidth = 33
  PM_MenuBarVMargin = 35
  PM_MenuButtonIndicator = 2
  PM_MenuDesktopFrameWidth = 32
  PM_MenuHMargin = 28
  PM_MenuPanelWidth = 30
  PM_MenuScrollerHeight = 27
  PM_MenuTearoffHeight = 31
  PM_MenuVMargin = 29
  PM_MessageBoxIconSize = 76
  PM_ProgressBarChunkWidth = 24
  PM_RadioButtonLabelSpacing = 79
  PM_ScrollBarExtent = 9
  PM_ScrollBarSliderMin = 10
  PM_ScrollView_ScrollBarSpacing = 90
  PM_SizeGripSize = 74
  PM_SliderControlThickness = 12
  PM_SliderLength = 13
  PM_SliderSpaceAvailable = 15
  PM_SliderThickness = 11
  PM_SliderTickmarkOffset = 14
  PM_SmallIconSize = 67
  PM_SpinBoxFrameWidth = 6
  PM_SpinBoxSliderHeight = 60
  PM_SplitterWidth = 25
  PM_SubMenuOverlap = 91
  PM_TabBarBaseHeight = 22
  PM_TabBarBaseOverlap = 23
  PM_TabBarIconSize = 73
  PM_TabBarScrollButtonWidth = 53
  PM_TabBarTabHSpace = 20
  PM_TabBarTabOverlap = 19
  PM_TabBarTabShiftHorizontal = 51
  PM_TabBarTabShiftVertical = 52
  PM_TabBarTabVSpace = 21
  PM_TabBar_ScrollButtonOverlap = 86
  PM_TabCloseIndicatorHeight = 89
  PM_TabCloseIndicatorWidth = 88
  PM_TextCursorWidth = 87
  PM_TitleBarHeight = 26
  PM_ToolBarExtensionExtent = 59
  PM_ToolBarFrameWidth = 54
  PM_ToolBarHandleExtent = 55
  PM_ToolBarIconSize = 64
  PM_ToolBarItemMargin = 57
  PM_ToolBarItemSpacing = 56
  PM_ToolBarSeparatorExtent = 58
  PM_ToolTipLabelFrameWidth = 71
  RSIP_OnMouseClick = 1
  RSIP_OnMouseClickAndAlreadyFocused = 0
  SC_All = -1
  SC_ComboBoxArrow = 4
  SC_ComboBoxEditField = 2
  SC_ComboBoxFrame = 1
  SC_ComboBoxListBoxPopup = 8
  SC_CustomBase = -268435456
  SC_DialGroove = 1
  SC_DialHandle = 2
  SC_DialTickmarks = 4
  SC_GroupBoxCheckBox = 1
  SC_GroupBoxContents = 4
  SC_GroupBoxFrame = 8
  SC_GroupBoxLabel = 2
  SC_MdiCloseButton = 4
  SC_MdiMinButton = 1
  SC_MdiNormalButton = 2
  SC_None = 0
  SC_Q3ListView = 1
  SC_Q3ListViewBranch = 2
  SC_Q3ListViewExpand = 4
  SC_ScrollBarAddLine = 1
  SC_ScrollBarAddPage = 4
  SC_ScrollBarFirst = 16
  SC_ScrollBarGroove = 128
  SC_ScrollBarLast = 32
  SC_ScrollBarSlider = 64
  SC_ScrollBarSubLine = 2
  SC_ScrollBarSubPage = 8
  SC_SliderGroove = 1
  SC_SliderHandle = 2
  SC_SliderTickmarks = 4
  SC_SpinBoxDown = 2
  SC_SpinBoxEditField = 8
  SC_SpinBoxFrame = 4
  SC_SpinBoxUp = 1
  SC_TitleBarCloseButton = 8
  SC_TitleBarContextHelpButton = 128
  SC_TitleBarLabel = 256
  SC_TitleBarMaxButton = 4
  SC_TitleBarMinButton = 2
  SC_TitleBarNormalButton = 16
  SC_TitleBarShadeButton = 32
  SC_TitleBarSysMenu = 1
  SC_TitleBarUnshadeButton = 64
  SC_ToolButton = 1
  SC_ToolButtonMenu = 2
  SE_CheckBoxClickRect = 5
  SE_CheckBoxContents = 3
  SE_CheckBoxFocusRect = 4
  SE_CheckBoxIndicator = 2
  SE_CheckBoxLayoutItem = 42
  SE_ComboBoxFocusRect = 10
  SE_ComboBoxLayoutItem = 43
  SE_CustomBase = -268435456
  SE_DateTimeEditLayoutItem = 44
  SE_DialogButtonAbort = 21
  SE_DialogButtonAccept = 16
  SE_DialogButtonAll = 20
  SE_DialogButtonApply = 18
  SE_DialogButtonBoxLayoutItem = 45
  SE_DialogButtonCustom = 24
  SE_DialogButtonHelp = 19
  SE_DialogButtonIgnore = 22
  SE_DialogButtonReject = 17
  SE_DialogButtonRetry = 23
  SE_DockWidgetCloseButton = 38
  SE_DockWidgetFloatButton = 39
  SE_DockWidgetIcon = 41
  SE_DockWidgetTitleBarText = 40
  SE_FrameContents = 37
  SE_FrameLayoutItem = 53
  SE_GroupBoxLayoutItem = 54
  SE_HeaderArrow = 27
  SE_HeaderLabel = 26
  SE_ItemViewItemCheckIndicator = 33
  SE_ItemViewItemDecoration = 56
  SE_ItemViewItemFocusRect = 58
  SE_ItemViewItemText = 57
  SE_LabelLayoutItem = 46
  SE_LineEditContents = 36
  SE_ProgressBarContents = 14
  SE_ProgressBarGroove = 13
  SE_ProgressBarLabel = 15
  SE_ProgressBarLayoutItem = 47
  SE_PushButtonContents = 0
  SE_PushButtonFocusRect = 1
  SE_PushButtonLayoutItem = 48
  SE_Q3DockWindowHandleRect = 12
  SE_RadioButtonClickRect = 9
  SE_RadioButtonContents = 7
  SE_RadioButtonFocusRect = 8
  SE_RadioButtonIndicator = 6
  SE_RadioButtonLayoutItem = 49
  SE_ShapedFrameContents = 62
  SE_SliderFocusRect = 11
  SE_SliderLayoutItem = 50
  SE_SpinBoxLayoutItem = 51
  SE_TabBarTabLeftButton = 59
  SE_TabBarTabRightButton = 60
  SE_TabBarTabText = 61
  SE_TabBarTearIndicator = 34
  SE_TabWidgetLayoutItem = 55
  SE_TabWidgetLeftCorner = 31
  SE_TabWidgetRightCorner = 32
  SE_TabWidgetTabBar = 28
  SE_TabWidgetTabContents = 30
  SE_TabWidgetTabPane = 29
  SE_ToolBarHandle = 63
  SE_ToolBoxTabContents = 25
  SE_ToolButtonLayoutItem = 52
  SE_TreeViewDisclosureItem = 35
  SE_ViewItemCheckIndicator = 33
  SH_BlinkCursorWhenTextSelected = 28
  SH_Button_FocusPolicy = 49
  SH_ComboBox_LayoutDirection = 59
  SH_ComboBox_ListMouseTracking = 19
  SH_ComboBox_Popup = 25
  SH_ComboBox_PopupFrameStyle = 70
  SH_CustomBase = -268435456
  SH_Dial_BackgroundRole = 58
  SH_DialogButtonBox_ButtonsHaveIcons = 72
  SH_DialogButtonLayout = 69
  SH_DialogButtons_DefaultButton = 36
  SH_DitherDisabledText = 1
  SH_DockWidget_ButtonsHaveFrame = 95
  SH_DrawMenuBarSeparator = 47
  SH_EtchDisabledText = 0
  SH_FocusFrame_AboveWidget = 78
  SH_FocusFrame_Mask = 54
  SH_FontDialog_SelectAssociatedText = 13
  SH_FormLayoutFieldGrowthPolicy = 90
  SH_FormLayoutFormAlignment = 91
  SH_FormLayoutLabelAlignment = 92
  SH_FormLayoutWrapPolicy = 87
  SH_GroupBox_TextLabelColor = 32
  SH_GroupBox_TextLabelVerticalAlignment = 31
  SH_Header_ArrowAlignment = 6
  SH_ItemView_ActivateItemOnSingleClick = 62
  SH_ItemView_ArrowKeysNavigateIntoChildren = 81
  SH_ItemView_ChangeHighlightOnFocus = 22
  SH_ItemView_DrawDelegateFrame = 93
  SH_ItemView_EllipsisLocation = 60
  SH_ItemView_MovementWithoutUpdatingSelection = 76
  SH_ItemView_PaintAlternatingRowColorsForEmptyArea = 86
  SH_ItemView_ShowDecorationSelected = 61
  SH_LineEdit_PasswordCharacter = 35
  SH_MainWindow_SpaceBelowMenuBar = 12
  SH_MenuBar_AltKeyNavigation = 18
  SH_MenuBar_DismissOnSecondClick = 50
  SH_MenuBar_MouseTracking = 21
  SH_Menu_AllowActiveAndDisabled = 14
  SH_Menu_FadeOutOnHide = 84
  SH_Menu_FillScreenWithScroll = 45
  SH_Menu_FlashTriggeredItem = 83
  SH_Menu_KeyboardSearch = 67
  SH_Menu_Mask = 82
  SH_Menu_MouseTracking = 20
  SH_Menu_Scrollable = 30
  SH_Menu_SelectionWrap = 75
  SH_Menu_SloppySubMenus = 33
  SH_Menu_SpaceActivatesItem = 15
  SH_Menu_SubMenuPopupDelay = 16
  SH_MessageBox_CenterButtons = 74
  SH_MessageBox_TextInteractionFlags = 71
  SH_MessageBox_UseBorderForButtonSpacing = 51
  SH_PrintDialog_RightAlignButtons = 11
  SH_ProgressDialog_CenterCancelButton = 9
  SH_ProgressDialog_TextLabelAlignment = 10
  SH_Q3ListViewExpand_SelectMouseType = 40
  SH_RequestSoftwareInputPanel = 97
  SH_RichText_FullWidthSelection = 29
  SH_RubberBand_Mask = 55
  SH_ScrollBar_ContextMenu = 63
  SH_ScrollBar_LeftClickAbsolutePosition = 39
  SH_ScrollBar_MiddleClickAbsolutePosition = 2
  SH_ScrollBar_RollBetweenButtons = 64
  SH_ScrollBar_ScrollWhenPointerLeavesControl = 3
  SH_ScrollBar_StopMouseOverSlider = 27
  SH_ScrollView_FrameOnlyAroundContents = 17
  SH_Slider_AbsoluteSetButtons = 65
  SH_Slider_PageSetButtons = 66
  SH_Slider_SloppyKeyEvents = 8
  SH_Slider_SnapToValue = 7
  SH_Slider_StopMouseOverSlider = 27
  SH_SpellCheckUnderlineStyle = 73
  SH_SpinBox_AnimateButton = 42
  SH_SpinBox_ClickAutoRepeatRate = 44
  SH_SpinBox_ClickAutoRepeatThreshold = 85
  SH_SpinBox_KeyPressAutoRepeatRate = 43
  SH_SpinControls_DisableOnBounds = 57
  SH_TabBar_Alignment = 5
  SH_TabBar_CloseButtonPosition = 94
  SH_TabBar_ElideMode = 68
  SH_TabBar_PreferNoArrows = 38
  SH_TabBar_SelectMouseType = 4
  SH_TabWidget_DefaultTabPosition = 88
  SH_Table_GridLineColor = 34
  SH_TextControl_FocusIndicatorTextCharFormat = 79
  SH_TitleBar_AutoRaise = 52
  SH_TitleBar_ModifyNotification = 48
  SH_TitleBar_NoBorder = 26
  SH_ToolBar_Movable = 89
  SH_ToolBox_SelectedPageTitleBold = 37
  SH_ToolButtonStyle = 96
  SH_ToolButton_PopupDelay = 53
  SH_ToolTipLabel_Opacity = 46
  SH_ToolTip_Mask = 77
  SH_UnderlineShortcut = 41
  SH_Widget_ShareActivation = 23
  SH_WindowFrame_Mask = 56
  SH_WizardStyle = 80
  SH_Workspace_FillSpaceOnMaximize = 24
  SP_ArrowBack = 53
  SP_ArrowDown = 50
  SP_ArrowForward = 54
  SP_ArrowLeft = 51
  SP_ArrowRight = 52
  SP_ArrowUp = 49
  SP_BrowserReload = 58
  SP_BrowserStop = 59
  SP_CommandLink = 56
  SP_ComputerIcon = 15
  SP_CustomBase = -268435456
  SP_DesktopIcon = 13
  SP_DialogApplyButton = 44
  SP_DialogCancelButton = 39
  SP_DialogCloseButton = 43
  SP_DialogDiscardButton = 46
  SP_DialogHelpButton = 40
  SP_DialogNoButton = 48
  SP_DialogOkButton = 38
  SP_DialogOpenButton = 41
  SP_DialogResetButton = 45
  SP_DialogSaveButton = 42
  SP_DialogYesButton = 47
  SP_DirClosedIcon = 22
  SP_DirHomeIcon = 55
  SP_DirIcon = 37
  SP_DirLinkIcon = 23
  SP_DirOpenIcon = 21
  SP_DockWidgetCloseButton = 8
  SP_DriveCDIcon = 18
  SP_DriveDVDIcon = 19
  SP_DriveFDIcon = 16
  SP_DriveHDIcon = 17
  SP_DriveNetIcon = 20
  SP_FileDialogBack = 36
  SP_FileDialogContentsView = 34
  SP_FileDialogDetailedView = 32
  SP_FileDialogEnd = 29
  SP_FileDialogInfoView = 33
  SP_FileDialogListView = 35
  SP_FileDialogNewFolder = 31
  SP_FileDialogStart = 28
  SP_FileDialogToParent = 30
  SP_FileIcon = 24
  SP_FileLinkIcon = 25
  SP_MediaPause = 62
  SP_MediaPlay = 60
  SP_MediaSeekBackward = 66
  SP_MediaSeekForward = 65
  SP_MediaSkipBackward = 64
  SP_MediaSkipForward = 63
  SP_MediaStop = 61
  SP_MediaVolume = 67
  SP_MediaVolumeMuted = 68
  SP_MessageBoxCritical = 11
  SP_MessageBoxInformation = 9
  SP_MessageBoxQuestion = 12
  SP_MessageBoxWarning = 10
  SP_TitleBarCloseButton = 3
  SP_TitleBarContextHelpButton = 7
  SP_TitleBarMaxButton = 2
  SP_TitleBarMenuButton = 0
  SP_TitleBarMinButton = 1
  SP_TitleBarNormalButton = 4
  SP_TitleBarShadeButton = 5
  SP_TitleBarUnshadeButton = 6
  SP_ToolBarHorizontalExtensionButton = 26
  SP_ToolBarVerticalExtensionButton = 27
  SP_TrashIcon = 14
  SP_VistaShield = 57
  State_Active = 65536
  State_AutoRaise = 4096
  State_Bottom = 1024
  State_Children = 524288
  State_DownArrow = 64
  State_Editing = 4194304
  State_Enabled = 1
  State_FocusAtBorder = 2048
  State_HasFocus = 256
  State_Horizontal = 128
  State_Item = 1048576
  State_KeyboardFocusChange = 8388608
  State_Mini = 134217728
  State_MouseOver = 8192
  State_NoChange = 16
  State_None = 0
  State_Off = 8
  State_On = 32
  State_Open = 262144
  State_Raised = 2
  State_ReadOnly = 33554432
  State_Selected = 32768
  State_Sibling = 2097152
  State_Small = 67108864
  State_Sunken = 4
  State_Top = 512
  State_UpArrow = 16384
  State_Window = 131072

class QStyleFactory(_Mock):
  pass


class QStyleHintReturn(_Mock):
  pass
  SH_Default = 61440
  SH_Mask = 61441
  SH_Variant = 61442
  Type = 61440
  Version = 1

class QStyleHintReturnMask(_Mock):
  pass
  SH_Default = 61440
  SH_Mask = 61441
  SH_Variant = 61442
  Type = 61441
  Version = 1

class QStyleHintReturnVariant(_Mock):
  pass
  SH_Default = 61440
  SH_Mask = 61441
  SH_Variant = 61442
  Type = 61442
  Version = 1

class QStyleOption(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 0
  Version = 1

class QStyleOptionButton(_Mock):
  pass
  AutoDefaultButton = 8
  CommandLinkButton = 16
  DefaultButton = 4
  Flat = 1
  HasMenu = 2
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 2
  Version = 1

class QStyleOptionComboBox(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 983044
  Version = 1

class QStyleOptionComplex(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 983040
  Version = 1

class QStyleOptionDockWidget(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 10
  Version = 1

class QStyleOptionDockWidgetV2(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 10
  Version = 2

class QStyleOptionFocusRect(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 1
  Version = 1

class QStyleOptionFrame(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 5
  Version = 1

class QStyleOptionFrameV2(_Mock):
  pass
  Flat = 1
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 5
  Version = 2

class QStyleOptionFrameV3(_Mock):
  pass
  Flat = 1
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 5
  Version = 3

class QStyleOptionGraphicsItem(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 17
  Version = 1

class QStyleOptionGroupBox(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 983047
  Version = 1

class QStyleOptionHeader(_Mock):
  pass
  Beginning = 0
  End = 2
  Middle = 1
  NextAndPreviousAreSelected = 3
  NextIsSelected = 1
  NotAdjacent = 0
  OnlyOneSection = 3
  PreviousIsSelected = 2
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  SortDown = 2
  SortUp = 1
  Type = 8
  Version = 1

class QStyleOptionMenuItem(_Mock):
  pass
  DefaultItem = 1
  EmptyArea = 7
  Exclusive = 1
  Margin = 6
  NonExclusive = 2
  Normal = 0
  NotCheckable = 0
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Scroller = 4
  Separator = 2
  SubMenu = 3
  TearOff = 5
  Type = 4
  Version = 1

class QStyleOptionProgressBar(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 6
  Version = 1

class QStyleOptionProgressBarV2(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 6
  Version = 2

class QStyleOptionRubberBand(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 15
  Version = 1

class QStyleOptionSizeGrip(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 983048
  Version = 1

class QStyleOptionSlider(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 983041
  Version = 1

class QStyleOptionSpinBox(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 983042
  Version = 1

class QStyleOptionTab(_Mock):
  pass
  Beginning = 0
  End = 2
  LeftCornerWidget = 1
  Middle = 1
  NextIsSelected = 1
  NoCornerWidgets = 0
  NotAdjacent = 0
  OnlyOneTab = 3
  PreviousIsSelected = 2
  RightCornerWidget = 2
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 3
  Version = 1

class QStyleOptionTabBarBase(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 14
  Version = 1

class QStyleOptionTabBarBaseV2(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 14
  Version = 2

class QStyleOptionTabV2(_Mock):
  pass
  Beginning = 0
  End = 2
  LeftCornerWidget = 1
  Middle = 1
  NextIsSelected = 1
  NoCornerWidgets = 0
  NotAdjacent = 0
  OnlyOneTab = 3
  PreviousIsSelected = 2
  RightCornerWidget = 2
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 3
  Version = 2

class QStyleOptionTabV3(_Mock):
  pass
  Beginning = 0
  End = 2
  LeftCornerWidget = 1
  Middle = 1
  NextIsSelected = 1
  NoCornerWidgets = 0
  NotAdjacent = 0
  OnlyOneTab = 3
  PreviousIsSelected = 2
  RightCornerWidget = 2
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 3
  Version = 3

class QStyleOptionTabWidgetFrame(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 13
  Version = 1

class QStyleOptionTabWidgetFrameV2(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 13
  Version = 2

class QStyleOptionTitleBar(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 983046
  Version = 1

class QStyleOptionToolBar(_Mock):
  pass
  Beginning = 0
  End = 2
  Middle = 1
  Movable = 1
  OnlyOne = 3
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 16
  Version = 1

class QStyleOptionToolBox(_Mock):
  pass
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 7
  Version = 1

class QStyleOptionToolBoxV2(_Mock):
  pass
  Beginning = 0
  End = 2
  Middle = 1
  NextIsSelected = 1
  NotAdjacent = 0
  OnlyOneTab = 3
  PreviousIsSelected = 2
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 7
  Version = 2

class QStyleOptionToolButton(_Mock):
  pass
  Arrow = 1
  HasMenu = 16
  Menu = 4
  MenuButtonPopup = 4
  PopupDelay = 8
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Type = 983043
  Version = 1

class QStyleOptionViewItem(_Mock):
  pass
  Bottom = 3
  Left = 0
  Right = 1
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Top = 2
  Type = 12
  Version = 1

class QStyleOptionViewItemV2(_Mock):
  pass
  Alternate = 2
  Bottom = 3
  HasCheckIndicator = 4
  HasDecoration = 16
  HasDisplay = 8
  Left = 0
  Right = 1
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Top = 2
  Type = 12
  Version = 2
  WrapText = 1

class QStyleOptionViewItemV3(_Mock):
  pass
  Alternate = 2
  Bottom = 3
  HasCheckIndicator = 4
  HasDecoration = 16
  HasDisplay = 8
  Left = 0
  Right = 1
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Top = 2
  Type = 12
  Version = 3
  WrapText = 1

class QStyleOptionViewItemV4(_Mock):
  pass
  Alternate = 2
  Beginning = 1
  Bottom = 3
  End = 3
  HasCheckIndicator = 4
  HasDecoration = 16
  HasDisplay = 8
  Invalid = 0
  Left = 0
  Middle = 2
  OnlyOne = 4
  Right = 1
  SO_Button = 2
  SO_ComboBox = 983044
  SO_Complex = 983040
  SO_ComplexCustomBase = 251658240
  SO_CustomBase = 3840
  SO_Default = 0
  SO_DockWidget = 10
  SO_FocusRect = 1
  SO_Frame = 5
  SO_GraphicsItem = 17
  SO_GroupBox = 983047
  SO_Header = 8
  SO_MenuItem = 4
  SO_ProgressBar = 6
  SO_Q3DockWindow = 9
  SO_Q3ListView = 983045
  SO_Q3ListViewItem = 11
  SO_RubberBand = 15
  SO_SizeGrip = 983048
  SO_Slider = 983041
  SO_SpinBox = 983042
  SO_Tab = 3
  SO_TabBarBase = 14
  SO_TabWidgetFrame = 13
  SO_TitleBar = 983046
  SO_ToolBar = 16
  SO_ToolBox = 7
  SO_ToolButton = 983043
  SO_ViewItem = 12
  Top = 2
  Type = 12
  Version = 4
  WrapText = 1

class QStylePainter(_Mock):
  pass
  Antialiasing = 1
  CompositionMode_Clear = 2
  CompositionMode_ColorBurn = 19
  CompositionMode_ColorDodge = 18
  CompositionMode_Darken = 16
  CompositionMode_Destination = 4
  CompositionMode_DestinationAtop = 10
  CompositionMode_DestinationIn = 6
  CompositionMode_DestinationOut = 8
  CompositionMode_DestinationOver = 1
  CompositionMode_Difference = 22
  CompositionMode_Exclusion = 23
  CompositionMode_HardLight = 20
  CompositionMode_Lighten = 17
  CompositionMode_Multiply = 13
  CompositionMode_Overlay = 15
  CompositionMode_Plus = 12
  CompositionMode_Screen = 14
  CompositionMode_SoftLight = 21
  CompositionMode_Source = 3
  CompositionMode_SourceAtop = 9
  CompositionMode_SourceIn = 5
  CompositionMode_SourceOut = 7
  CompositionMode_SourceOver = 0
  CompositionMode_Xor = 11
  HighQualityAntialiasing = 8
  NonCosmeticDefaultPen = 16
  OpaqueHint = 1
  RasterOp_NotSource = 30
  RasterOp_NotSourceAndDestination = 31
  RasterOp_NotSourceAndNotDestination = 27
  RasterOp_NotSourceOrNotDestination = 28
  RasterOp_NotSourceXorDestination = 29
  RasterOp_SourceAndDestination = 25
  RasterOp_SourceAndNotDestination = 32
  RasterOp_SourceOrDestination = 24
  RasterOp_SourceXorDestination = 26
  SmoothPixmapTransform = 4
  TextAntialiasing = 2

class QStyledItemDelegate(_Mock):
  pass
  EditNextItem = 1
  EditPreviousItem = 2
  NoHint = 0
  RevertModelCache = 4
  SubmitModelCache = 3

class QSvgGenerator(_Mock):
  pass
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QSvgRenderer(_Mock):
  pass


class QSvgWidget(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QSwipeGesture(_Mock):
  pass
  CancelAllInContext = 1
  CancelNone = 0
  Down = 4
  Left = 1
  NoDirection = 0
  Right = 2
  Up = 3

class QSyntaxHighlighter(_Mock):
  pass


class QSysInfo(_Mock):
  pass
  BigEndian = 0
  ByteOrder = 1
  LittleEndian = 1
  WordSize = 64

class QSystemLocale(_Mock):
  pass
  AMText = 24
  CountryId = 1
  CurrencySymbol = 28
  CurrencyToString = 29
  DateFormatLong = 6
  DateFormatShort = 7
  DateTimeFormatLong = 18
  DateTimeFormatShort = 19
  DateTimeToStringLong = 20
  DateTimeToStringShort = 21
  DateToStringLong = 14
  DateToStringShort = 15
  DayNameLong = 10
  DayNameShort = 11
  DecimalPoint = 2
  FirstDayOfWeek = 26
  GroupSeparator = 3
  LanguageId = 0
  ListToSeparatedString = 34
  LocaleChanged = 35
  MeasurementSystem = 22
  MonthNameLong = 12
  MonthNameShort = 13
  NativeCountryName = 37
  NativeLanguageName = 36
  NegativeSign = 5
  PMText = 25
  PositiveSign = 23
  ScriptId = 33
  StringToAlternateQuotation = 32
  StringToStandardQuotation = 31
  TimeFormatLong = 8
  TimeFormatShort = 9
  TimeToStringLong = 16
  TimeToStringShort = 17
  UILanguages = 30
  Weekdays = 27
  ZeroDigit = 4

class QSystemSemaphore(_Mock):
  pass
  AlreadyExists = 3
  Create = 1
  KeyError = 2
  NoError = 0
  NotFound = 4
  Open = 0
  OutOfResources = 5
  PermissionDenied = 1
  UnknownError = 6

class QSystemTrayIcon(_Mock):
  pass
  Context = 1
  Critical = 3
  DoubleClick = 2
  Information = 1
  MiddleClick = 4
  NoIcon = 0
  Trigger = 3
  Unknown = 0
  Warning = 2

class QTabBar(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  LeftSide = 0
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  RightSide = 1
  RoundedEast = 3
  RoundedNorth = 0
  RoundedSouth = 1
  RoundedWest = 2
  SelectLeftTab = 0
  SelectPreviousTab = 2
  SelectRightTab = 1
  TriangularEast = 7
  TriangularNorth = 4
  TriangularSouth = 5
  TriangularWest = 6

class QTabWidget(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  East = 3
  IgnoreMask = 4
  North = 0
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Rounded = 0
  South = 1
  Triangular = 1
  West = 2

class QTableView(_Mock):
  pass
  AboveItem = 1
  AllEditTriggers = 31
  AnimatingState = 6
  AnyKeyPressed = 16
  BelowItem = 2
  Box = 1
  CollapsingState = 5
  ContiguousSelection = 4
  CurrentChanged = 1
  DoubleClicked = 2
  DragDrop = 3
  DragOnly = 1
  DragSelectingState = 2
  DraggingState = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  DropOnly = 2
  EditKeyPressed = 8
  EditingState = 3
  EnsureVisible = 0
  ExpandingState = 4
  ExtendedSelection = 3
  HLine = 4
  IgnoreMask = 4
  InternalMove = 4
  MoveDown = 1
  MoveEnd = 5
  MoveHome = 4
  MoveLeft = 2
  MoveNext = 8
  MovePageDown = 7
  MovePageUp = 6
  MovePrevious = 9
  MoveRight = 3
  MoveUp = 0
  MultiSelection = 2
  NoDragDrop = 0
  NoEditTriggers = 0
  NoFrame = 0
  NoSelection = 0
  NoState = 0
  OnItem = 0
  OnViewport = 3
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  PositionAtBottom = 2
  PositionAtCenter = 3
  PositionAtTop = 1
  Raised = 32
  ScrollPerItem = 0
  ScrollPerPixel = 1
  SelectColumns = 2
  SelectItems = 0
  SelectRows = 1
  SelectedClicked = 4
  Shadow_Mask = 240
  Shape_Mask = 15
  SingleSelection = 1
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QTableWidget(_Mock):
  pass
  AboveItem = 1
  AllEditTriggers = 31
  AnimatingState = 6
  AnyKeyPressed = 16
  BelowItem = 2
  Box = 1
  CollapsingState = 5
  ContiguousSelection = 4
  CurrentChanged = 1
  DoubleClicked = 2
  DragDrop = 3
  DragOnly = 1
  DragSelectingState = 2
  DraggingState = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  DropOnly = 2
  EditKeyPressed = 8
  EditingState = 3
  EnsureVisible = 0
  ExpandingState = 4
  ExtendedSelection = 3
  HLine = 4
  IgnoreMask = 4
  InternalMove = 4
  MoveDown = 1
  MoveEnd = 5
  MoveHome = 4
  MoveLeft = 2
  MoveNext = 8
  MovePageDown = 7
  MovePageUp = 6
  MovePrevious = 9
  MoveRight = 3
  MoveUp = 0
  MultiSelection = 2
  NoDragDrop = 0
  NoEditTriggers = 0
  NoFrame = 0
  NoSelection = 0
  NoState = 0
  OnItem = 0
  OnViewport = 3
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  PositionAtBottom = 2
  PositionAtCenter = 3
  PositionAtTop = 1
  Raised = 32
  ScrollPerItem = 0
  ScrollPerPixel = 1
  SelectColumns = 2
  SelectItems = 0
  SelectRows = 1
  SelectedClicked = 4
  Shadow_Mask = 240
  Shape_Mask = 15
  SingleSelection = 1
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QTableWidgetItem(_Mock):
  pass
  Type = 0
  UserType = 1000

class QTableWidgetSelectionRange(_Mock):
  pass


class QTabletEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  Airbrush = 3
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  Cursor = 2
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  Eraser = 3
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  FourDMouse = 4
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  NoDevice = 0
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  Pen = 1
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  Puck = 1
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  RotationStylus = 6
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  Stylus = 2
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UnknownPointer = 0
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  XFreeEraser = 5
  ZOrderChange = 126

class QTapAndHoldGesture(_Mock):
  pass
  CancelAllInContext = 1
  CancelNone = 0

class QTapGesture(_Mock):
  pass
  CancelAllInContext = 1
  CancelNone = 0

class QTcpServer(_Mock):
  pass


class QTcpSocket(_Mock):
  pass
  AddressInUseError = 8
  Append = 4
  BoundState = 4
  ClosingState = 6
  ConnectedState = 3
  ConnectingState = 2
  ConnectionRefusedError = 0
  DatagramTooLargeError = 6
  HostLookupState = 1
  HostNotFoundError = 2
  IPv4Protocol = 0
  IPv6Protocol = 1
  KeepAliveOption = 1
  ListeningState = 5
  LowDelayOption = 0
  MulticastLoopbackOption = 3
  MulticastTtlOption = 2
  NetworkError = 7
  NotOpen = 0
  ProxyAuthenticationRequiredError = 12
  ProxyConnectionClosedError = 15
  ProxyConnectionRefusedError = 14
  ProxyConnectionTimeoutError = 16
  ProxyNotFoundError = 17
  ProxyProtocolError = 18
  ReadOnly = 1
  ReadWrite = 3
  RemoteHostClosedError = 1
  SocketAccessError = 3
  SocketAddressNotAvailableError = 9
  SocketResourceError = 4
  SocketTimeoutError = 5
  SslHandshakeFailedError = 13
  TcpSocket = 0
  Text = 16
  Truncate = 8
  UdpSocket = 1
  Unbuffered = 32
  UnconnectedState = 0
  UnfinishedSocketOperationError = 11
  UnknownNetworkLayerProtocol = -1
  UnknownSocketError = -1
  UnknownSocketType = -1
  UnsupportedSocketOperationError = 10
  WriteOnly = 2

class QTemporaryFile(_Mock):
  pass
  AbortError = 6
  Append = 4
  AutoCloseHandle = 1
  CopyError = 14
  DontCloseHandle = 0
  ExeGroup = 16
  ExeOther = 1
  ExeOwner = 4096
  ExeUser = 256
  FatalError = 3
  NoError = 0
  NoOptions = 0
  NotOpen = 0
  OpenError = 5
  PermissionsError = 13
  PositionError = 11
  ReadError = 1
  ReadGroup = 64
  ReadOnly = 1
  ReadOther = 4
  ReadOwner = 16384
  ReadUser = 1024
  ReadWrite = 3
  RemoveError = 9
  RenameError = 10
  ResizeError = 12
  ResourceError = 4
  Text = 16
  TimeOutError = 7
  Truncate = 8
  Unbuffered = 32
  UnspecifiedError = 8
  WriteError = 2
  WriteGroup = 32
  WriteOnly = 2
  WriteOther = 2
  WriteOwner = 8192
  WriteUser = 512

class QTest(_Mock):
  pass
  Click = 2
  MouseClick = 2
  MouseDClick = 3
  MouseMove = 4
  MousePress = 0
  MouseRelease = 1
  Press = 0
  Release = 1

class QTextBlock(_Mock):
  pass


class QTextBlockFormat(_Mock):
  pass
  AnchorHref = 8241
  AnchorName = 8242
  BackgroundBrush = 2080
  BackgroundImageUrl = 2083
  BlockAlignment = 4112
  BlockBottomMargin = 4145
  BlockFormat = 1
  BlockIndent = 4160
  BlockLeftMargin = 4146
  BlockNonBreakableLines = 4176
  BlockRightMargin = 4147
  BlockTopMargin = 4144
  BlockTrailingHorizontalRulerWidth = 4192
  CharFormat = 2
  CssFloat = 2048
  FirstFontProperty = 8160
  FixedHeight = 2
  FontCapitalization = 8160
  FontFamily = 8192
  FontFixedPitch = 8200
  FontHintingPreference = 8166
  FontItalic = 8196
  FontKerning = 8165
  FontLetterSpacing = 8161
  FontOverline = 8198
  FontPixelSize = 8201
  FontPointSize = 8193
  FontSizeAdjustment = 8194
  FontSizeIncrement = 8194
  FontStrikeOut = 8199
  FontStyleHint = 8163
  FontStyleStrategy = 8164
  FontUnderline = 8197
  FontWeight = 8195
  FontWordSpacing = 8162
  ForegroundBrush = 2081
  FrameBorder = 16384
  FrameBorderBrush = 16393
  FrameBorderStyle = 16400
  FrameBottomMargin = 16390
  FrameFormat = 5
  FrameHeight = 16388
  FrameLeftMargin = 16391
  FrameMargin = 16385
  FramePadding = 16386
  FrameRightMargin = 16392
  FrameTopMargin = 16389
  FrameWidth = 16387
  FullWidthSelection = 24576
  ImageHeight = 20497
  ImageName = 20480
  ImageObject = 1
  ImageWidth = 20496
  InvalidFormat = -1
  IsAnchor = 8240
  LastFontProperty = 8201
  LayoutDirection = 2049
  LineDistanceHeight = 4
  LineHeight = 4168
  LineHeightType = 4169
  ListFormat = 3
  ListIndent = 12289
  ListNumberPrefix = 12290
  ListNumberSuffix = 12291
  ListStyle = 12288
  MinimumHeight = 3
  NoObject = 0
  ObjectIndex = 0
  ObjectType = 12032
  OutlinePen = 2064
  PageBreakPolicy = 28672
  PageBreak_AlwaysAfter = 16
  PageBreak_AlwaysBefore = 1
  PageBreak_Auto = 0
  ProportionalHeight = 1
  SingleHeight = 0
  TabPositions = 4149
  TableCellBottomPadding = 18451
  TableCellColumnSpan = 18449
  TableCellLeftPadding = 18452
  TableCellObject = 3
  TableCellPadding = 16643
  TableCellRightPadding = 18453
  TableCellRowSpan = 18448
  TableCellSpacing = 16642
  TableCellTopPadding = 18450
  TableColumnWidthConstraints = 16641
  TableColumns = 16640
  TableFormat = 4
  TableHeaderRowCount = 16644
  TableObject = 2
  TextIndent = 4148
  TextOutline = 8226
  TextToolTip = 8228
  TextUnderlineColor = 8208
  TextUnderlineStyle = 8227
  TextVerticalAlignment = 8225
  UserFormat = 100
  UserObject = 4096
  UserProperty = 1048576

class QTextBlockGroup(_Mock):
  pass


class QTextBlockUserData(_Mock):
  pass


class QTextBoundaryFinder(_Mock):
  pass
  EndWord = 2
  Grapheme = 0
  Line = 2
  NotAtBoundary = 0
  Sentence = 3
  StartWord = 1
  Word = 1

class QTextBrowser(_Mock):
  pass
  AutoAll = -1
  AutoBulletList = 1
  AutoNone = 0
  Box = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  FixedColumnWidth = 3
  FixedPixelWidth = 2
  HLine = 4
  IgnoreMask = 4
  NoFrame = 0
  NoWrap = 0
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  Raised = 32
  Shadow_Mask = 240
  Shape_Mask = 15
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WidgetWidth = 1
  WinPanel = 3

class QTextCharFormat(_Mock):
  pass
  AlignBaseline = 6
  AlignBottom = 5
  AlignMiddle = 3
  AlignNormal = 0
  AlignSubScript = 2
  AlignSuperScript = 1
  AlignTop = 4
  AnchorHref = 8241
  AnchorName = 8242
  BackgroundBrush = 2080
  BackgroundImageUrl = 2083
  BlockAlignment = 4112
  BlockBottomMargin = 4145
  BlockFormat = 1
  BlockIndent = 4160
  BlockLeftMargin = 4146
  BlockNonBreakableLines = 4176
  BlockRightMargin = 4147
  BlockTopMargin = 4144
  BlockTrailingHorizontalRulerWidth = 4192
  CharFormat = 2
  CssFloat = 2048
  DashDotDotLine = 5
  DashDotLine = 4
  DashUnderline = 2
  DotLine = 3
  FirstFontProperty = 8160
  FontCapitalization = 8160
  FontFamily = 8192
  FontFixedPitch = 8200
  FontHintingPreference = 8166
  FontItalic = 8196
  FontKerning = 8165
  FontLetterSpacing = 8161
  FontOverline = 8198
  FontPixelSize = 8201
  FontPointSize = 8193
  FontSizeAdjustment = 8194
  FontSizeIncrement = 8194
  FontStrikeOut = 8199
  FontStyleHint = 8163
  FontStyleStrategy = 8164
  FontUnderline = 8197
  FontWeight = 8195
  FontWordSpacing = 8162
  ForegroundBrush = 2081
  FrameBorder = 16384
  FrameBorderBrush = 16393
  FrameBorderStyle = 16400
  FrameBottomMargin = 16390
  FrameFormat = 5
  FrameHeight = 16388
  FrameLeftMargin = 16391
  FrameMargin = 16385
  FramePadding = 16386
  FrameRightMargin = 16392
  FrameTopMargin = 16389
  FrameWidth = 16387
  FullWidthSelection = 24576
  ImageHeight = 20497
  ImageName = 20480
  ImageObject = 1
  ImageWidth = 20496
  InvalidFormat = -1
  IsAnchor = 8240
  LastFontProperty = 8201
  LayoutDirection = 2049
  LineHeight = 4168
  LineHeightType = 4169
  ListFormat = 3
  ListIndent = 12289
  ListNumberPrefix = 12290
  ListNumberSuffix = 12291
  ListStyle = 12288
  NoObject = 0
  NoUnderline = 0
  ObjectIndex = 0
  ObjectType = 12032
  OutlinePen = 2064
  PageBreakPolicy = 28672
  PageBreak_AlwaysAfter = 16
  PageBreak_AlwaysBefore = 1
  PageBreak_Auto = 0
  SingleUnderline = 1
  SpellCheckUnderline = 7
  TabPositions = 4149
  TableCellBottomPadding = 18451
  TableCellColumnSpan = 18449
  TableCellLeftPadding = 18452
  TableCellObject = 3
  TableCellPadding = 16643
  TableCellRightPadding = 18453
  TableCellRowSpan = 18448
  TableCellSpacing = 16642
  TableCellTopPadding = 18450
  TableColumnWidthConstraints = 16641
  TableColumns = 16640
  TableFormat = 4
  TableHeaderRowCount = 16644
  TableObject = 2
  TextIndent = 4148
  TextOutline = 8226
  TextToolTip = 8228
  TextUnderlineColor = 8208
  TextUnderlineStyle = 8227
  TextVerticalAlignment = 8225
  UserFormat = 100
  UserObject = 4096
  UserProperty = 1048576
  WaveUnderline = 6

class QTextCodec(_Mock):
  pass
  ConvertInvalidToNull = -2147483648
  DefaultConversion = 0
  IgnoreHeader = 1

class QTextCursor(_Mock):
  pass
  BlockUnderCursor = 2
  Document = 3
  Down = 12
  End = 11
  EndOfBlock = 15
  EndOfLine = 13
  EndOfWord = 14
  KeepAnchor = 1
  Left = 9
  LineUnderCursor = 1
  MoveAnchor = 0
  NextBlock = 16
  NextCell = 21
  NextCharacter = 17
  NextRow = 23
  NextWord = 18
  NoMove = 0
  PreviousBlock = 6
  PreviousCell = 22
  PreviousCharacter = 7
  PreviousRow = 24
  PreviousWord = 8
  Right = 19
  Start = 1
  StartOfBlock = 4
  StartOfLine = 3
  StartOfWord = 5
  Up = 2
  WordLeft = 10
  WordRight = 20
  WordUnderCursor = 0

class QTextDecoder(_Mock):
  pass


class QTextDocument(_Mock):
  pass
  DocumentTitle = 0
  DocumentUrl = 1
  FindBackward = 1
  FindCaseSensitively = 2
  FindWholeWords = 4
  HtmlResource = 1
  ImageResource = 2
  RedoStack = 2
  StyleSheetResource = 3
  UndoAndRedoStacks = 3
  UndoStack = 1
  UserResource = 100

class QTextDocumentFragment(_Mock):
  pass


class QTextDocumentWriter(_Mock):
  pass


class QTextEdit(_Mock):
  pass
  AutoAll = -1
  AutoBulletList = 1
  AutoNone = 0
  Box = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  FixedColumnWidth = 3
  FixedPixelWidth = 2
  HLine = 4
  IgnoreMask = 4
  NoFrame = 0
  NoWrap = 0
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  Raised = 32
  Shadow_Mask = 240
  Shape_Mask = 15
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WidgetWidth = 1
  WinPanel = 3

class QTextEncoder(_Mock):
  pass


class QTextFormat(_Mock):
  pass
  AnchorHref = 8241
  AnchorName = 8242
  BackgroundBrush = 2080
  BackgroundImageUrl = 2083
  BlockAlignment = 4112
  BlockBottomMargin = 4145
  BlockFormat = 1
  BlockIndent = 4160
  BlockLeftMargin = 4146
  BlockNonBreakableLines = 4176
  BlockRightMargin = 4147
  BlockTopMargin = 4144
  BlockTrailingHorizontalRulerWidth = 4192
  CharFormat = 2
  CssFloat = 2048
  FirstFontProperty = 8160
  FontCapitalization = 8160
  FontFamily = 8192
  FontFixedPitch = 8200
  FontHintingPreference = 8166
  FontItalic = 8196
  FontKerning = 8165
  FontLetterSpacing = 8161
  FontOverline = 8198
  FontPixelSize = 8201
  FontPointSize = 8193
  FontSizeAdjustment = 8194
  FontSizeIncrement = 8194
  FontStrikeOut = 8199
  FontStyleHint = 8163
  FontStyleStrategy = 8164
  FontUnderline = 8197
  FontWeight = 8195
  FontWordSpacing = 8162
  ForegroundBrush = 2081
  FrameBorder = 16384
  FrameBorderBrush = 16393
  FrameBorderStyle = 16400
  FrameBottomMargin = 16390
  FrameFormat = 5
  FrameHeight = 16388
  FrameLeftMargin = 16391
  FrameMargin = 16385
  FramePadding = 16386
  FrameRightMargin = 16392
  FrameTopMargin = 16389
  FrameWidth = 16387
  FullWidthSelection = 24576
  ImageHeight = 20497
  ImageName = 20480
  ImageObject = 1
  ImageWidth = 20496
  InvalidFormat = -1
  IsAnchor = 8240
  LastFontProperty = 8201
  LayoutDirection = 2049
  LineHeight = 4168
  LineHeightType = 4169
  ListFormat = 3
  ListIndent = 12289
  ListNumberPrefix = 12290
  ListNumberSuffix = 12291
  ListStyle = 12288
  NoObject = 0
  ObjectIndex = 0
  ObjectType = 12032
  OutlinePen = 2064
  PageBreakPolicy = 28672
  PageBreak_AlwaysAfter = 16
  PageBreak_AlwaysBefore = 1
  PageBreak_Auto = 0
  TabPositions = 4149
  TableCellBottomPadding = 18451
  TableCellColumnSpan = 18449
  TableCellLeftPadding = 18452
  TableCellObject = 3
  TableCellPadding = 16643
  TableCellRightPadding = 18453
  TableCellRowSpan = 18448
  TableCellSpacing = 16642
  TableCellTopPadding = 18450
  TableColumnWidthConstraints = 16641
  TableColumns = 16640
  TableFormat = 4
  TableHeaderRowCount = 16644
  TableObject = 2
  TextIndent = 4148
  TextOutline = 8226
  TextToolTip = 8228
  TextUnderlineColor = 8208
  TextUnderlineStyle = 8227
  TextVerticalAlignment = 8225
  UserFormat = 100
  UserObject = 4096
  UserProperty = 1048576

class QTextFragment(_Mock):
  pass


class QTextFrame(_Mock):
  pass


class QTextFrameFormat(_Mock):
  pass
  AnchorHref = 8241
  AnchorName = 8242
  BackgroundBrush = 2080
  BackgroundImageUrl = 2083
  BlockAlignment = 4112
  BlockBottomMargin = 4145
  BlockFormat = 1
  BlockIndent = 4160
  BlockLeftMargin = 4146
  BlockNonBreakableLines = 4176
  BlockRightMargin = 4147
  BlockTopMargin = 4144
  BlockTrailingHorizontalRulerWidth = 4192
  BorderStyle_Dashed = 2
  BorderStyle_DotDash = 5
  BorderStyle_DotDotDash = 6
  BorderStyle_Dotted = 1
  BorderStyle_Double = 4
  BorderStyle_Groove = 7
  BorderStyle_Inset = 9
  BorderStyle_None = 0
  BorderStyle_Outset = 10
  BorderStyle_Ridge = 8
  BorderStyle_Solid = 3
  CharFormat = 2
  CssFloat = 2048
  FirstFontProperty = 8160
  FloatLeft = 1
  FloatRight = 2
  FontCapitalization = 8160
  FontFamily = 8192
  FontFixedPitch = 8200
  FontHintingPreference = 8166
  FontItalic = 8196
  FontKerning = 8165
  FontLetterSpacing = 8161
  FontOverline = 8198
  FontPixelSize = 8201
  FontPointSize = 8193
  FontSizeAdjustment = 8194
  FontSizeIncrement = 8194
  FontStrikeOut = 8199
  FontStyleHint = 8163
  FontStyleStrategy = 8164
  FontUnderline = 8197
  FontWeight = 8195
  FontWordSpacing = 8162
  ForegroundBrush = 2081
  FrameBorder = 16384
  FrameBorderBrush = 16393
  FrameBorderStyle = 16400
  FrameBottomMargin = 16390
  FrameFormat = 5
  FrameHeight = 16388
  FrameLeftMargin = 16391
  FrameMargin = 16385
  FramePadding = 16386
  FrameRightMargin = 16392
  FrameTopMargin = 16389
  FrameWidth = 16387
  FullWidthSelection = 24576
  ImageHeight = 20497
  ImageName = 20480
  ImageObject = 1
  ImageWidth = 20496
  InFlow = 0
  InvalidFormat = -1
  IsAnchor = 8240
  LastFontProperty = 8201
  LayoutDirection = 2049
  LineHeight = 4168
  LineHeightType = 4169
  ListFormat = 3
  ListIndent = 12289
  ListNumberPrefix = 12290
  ListNumberSuffix = 12291
  ListStyle = 12288
  NoObject = 0
  ObjectIndex = 0
  ObjectType = 12032
  OutlinePen = 2064
  PageBreakPolicy = 28672
  PageBreak_AlwaysAfter = 16
  PageBreak_AlwaysBefore = 1
  PageBreak_Auto = 0
  TabPositions = 4149
  TableCellBottomPadding = 18451
  TableCellColumnSpan = 18449
  TableCellLeftPadding = 18452
  TableCellObject = 3
  TableCellPadding = 16643
  TableCellRightPadding = 18453
  TableCellRowSpan = 18448
  TableCellSpacing = 16642
  TableCellTopPadding = 18450
  TableColumnWidthConstraints = 16641
  TableColumns = 16640
  TableFormat = 4
  TableHeaderRowCount = 16644
  TableObject = 2
  TextIndent = 4148
  TextOutline = 8226
  TextToolTip = 8228
  TextUnderlineColor = 8208
  TextUnderlineStyle = 8227
  TextVerticalAlignment = 8225
  UserFormat = 100
  UserObject = 4096
  UserProperty = 1048576

class QTextImageFormat(_Mock):
  pass
  AlignBaseline = 6
  AlignBottom = 5
  AlignMiddle = 3
  AlignNormal = 0
  AlignSubScript = 2
  AlignSuperScript = 1
  AlignTop = 4
  AnchorHref = 8241
  AnchorName = 8242
  BackgroundBrush = 2080
  BackgroundImageUrl = 2083
  BlockAlignment = 4112
  BlockBottomMargin = 4145
  BlockFormat = 1
  BlockIndent = 4160
  BlockLeftMargin = 4146
  BlockNonBreakableLines = 4176
  BlockRightMargin = 4147
  BlockTopMargin = 4144
  BlockTrailingHorizontalRulerWidth = 4192
  CharFormat = 2
  CssFloat = 2048
  DashDotDotLine = 5
  DashDotLine = 4
  DashUnderline = 2
  DotLine = 3
  FirstFontProperty = 8160
  FontCapitalization = 8160
  FontFamily = 8192
  FontFixedPitch = 8200
  FontHintingPreference = 8166
  FontItalic = 8196
  FontKerning = 8165
  FontLetterSpacing = 8161
  FontOverline = 8198
  FontPixelSize = 8201
  FontPointSize = 8193
  FontSizeAdjustment = 8194
  FontSizeIncrement = 8194
  FontStrikeOut = 8199
  FontStyleHint = 8163
  FontStyleStrategy = 8164
  FontUnderline = 8197
  FontWeight = 8195
  FontWordSpacing = 8162
  ForegroundBrush = 2081
  FrameBorder = 16384
  FrameBorderBrush = 16393
  FrameBorderStyle = 16400
  FrameBottomMargin = 16390
  FrameFormat = 5
  FrameHeight = 16388
  FrameLeftMargin = 16391
  FrameMargin = 16385
  FramePadding = 16386
  FrameRightMargin = 16392
  FrameTopMargin = 16389
  FrameWidth = 16387
  FullWidthSelection = 24576
  ImageHeight = 20497
  ImageName = 20480
  ImageObject = 1
  ImageWidth = 20496
  InvalidFormat = -1
  IsAnchor = 8240
  LastFontProperty = 8201
  LayoutDirection = 2049
  LineHeight = 4168
  LineHeightType = 4169
  ListFormat = 3
  ListIndent = 12289
  ListNumberPrefix = 12290
  ListNumberSuffix = 12291
  ListStyle = 12288
  NoObject = 0
  NoUnderline = 0
  ObjectIndex = 0
  ObjectType = 12032
  OutlinePen = 2064
  PageBreakPolicy = 28672
  PageBreak_AlwaysAfter = 16
  PageBreak_AlwaysBefore = 1
  PageBreak_Auto = 0
  SingleUnderline = 1
  SpellCheckUnderline = 7
  TabPositions = 4149
  TableCellBottomPadding = 18451
  TableCellColumnSpan = 18449
  TableCellLeftPadding = 18452
  TableCellObject = 3
  TableCellPadding = 16643
  TableCellRightPadding = 18453
  TableCellRowSpan = 18448
  TableCellSpacing = 16642
  TableCellTopPadding = 18450
  TableColumnWidthConstraints = 16641
  TableColumns = 16640
  TableFormat = 4
  TableHeaderRowCount = 16644
  TableObject = 2
  TextIndent = 4148
  TextOutline = 8226
  TextToolTip = 8228
  TextUnderlineColor = 8208
  TextUnderlineStyle = 8227
  TextVerticalAlignment = 8225
  UserFormat = 100
  UserObject = 4096
  UserProperty = 1048576
  WaveUnderline = 6

class QTextInlineObject(_Mock):
  pass


class QTextItem(_Mock):
  pass
  Overline = 16
  RightToLeft = 1
  StrikeOut = 64
  Underline = 32

class QTextLayout(_Mock):
  pass
  SkipCharacters = 0
  SkipWords = 1

class QTextLength(_Mock):
  pass
  FixedLength = 1
  PercentageLength = 2
  VariableLength = 0

class QTextLine(_Mock):
  pass
  CursorBetweenCharacters = 0
  CursorOnCharacter = 1
  Leading = 0
  Trailing = 1

class QTextList(_Mock):
  pass


class QTextListFormat(_Mock):
  pass
  AnchorHref = 8241
  AnchorName = 8242
  BackgroundBrush = 2080
  BackgroundImageUrl = 2083
  BlockAlignment = 4112
  BlockBottomMargin = 4145
  BlockFormat = 1
  BlockIndent = 4160
  BlockLeftMargin = 4146
  BlockNonBreakableLines = 4176
  BlockRightMargin = 4147
  BlockTopMargin = 4144
  BlockTrailingHorizontalRulerWidth = 4192
  CharFormat = 2
  CssFloat = 2048
  FirstFontProperty = 8160
  FontCapitalization = 8160
  FontFamily = 8192
  FontFixedPitch = 8200
  FontHintingPreference = 8166
  FontItalic = 8196
  FontKerning = 8165
  FontLetterSpacing = 8161
  FontOverline = 8198
  FontPixelSize = 8201
  FontPointSize = 8193
  FontSizeAdjustment = 8194
  FontSizeIncrement = 8194
  FontStrikeOut = 8199
  FontStyleHint = 8163
  FontStyleStrategy = 8164
  FontUnderline = 8197
  FontWeight = 8195
  FontWordSpacing = 8162
  ForegroundBrush = 2081
  FrameBorder = 16384
  FrameBorderBrush = 16393
  FrameBorderStyle = 16400
  FrameBottomMargin = 16390
  FrameFormat = 5
  FrameHeight = 16388
  FrameLeftMargin = 16391
  FrameMargin = 16385
  FramePadding = 16386
  FrameRightMargin = 16392
  FrameTopMargin = 16389
  FrameWidth = 16387
  FullWidthSelection = 24576
  ImageHeight = 20497
  ImageName = 20480
  ImageObject = 1
  ImageWidth = 20496
  InvalidFormat = -1
  IsAnchor = 8240
  LastFontProperty = 8201
  LayoutDirection = 2049
  LineHeight = 4168
  LineHeightType = 4169
  ListCircle = -2
  ListDecimal = -4
  ListDisc = -1
  ListFormat = 3
  ListIndent = 12289
  ListLowerAlpha = -5
  ListLowerRoman = -7
  ListNumberPrefix = 12290
  ListNumberSuffix = 12291
  ListSquare = -3
  ListStyle = 12288
  ListUpperAlpha = -6
  ListUpperRoman = -8
  NoObject = 0
  ObjectIndex = 0
  ObjectType = 12032
  OutlinePen = 2064
  PageBreakPolicy = 28672
  PageBreak_AlwaysAfter = 16
  PageBreak_AlwaysBefore = 1
  PageBreak_Auto = 0
  TabPositions = 4149
  TableCellBottomPadding = 18451
  TableCellColumnSpan = 18449
  TableCellLeftPadding = 18452
  TableCellObject = 3
  TableCellPadding = 16643
  TableCellRightPadding = 18453
  TableCellRowSpan = 18448
  TableCellSpacing = 16642
  TableCellTopPadding = 18450
  TableColumnWidthConstraints = 16641
  TableColumns = 16640
  TableFormat = 4
  TableHeaderRowCount = 16644
  TableObject = 2
  TextIndent = 4148
  TextOutline = 8226
  TextToolTip = 8228
  TextUnderlineColor = 8208
  TextUnderlineStyle = 8227
  TextVerticalAlignment = 8225
  UserFormat = 100
  UserObject = 4096
  UserProperty = 1048576

class QTextObject(_Mock):
  pass


class QTextObjectInterface(_Mock):
  pass


class QTextOption(_Mock):
  pass
  AddSpaceForLineAndParagraphSeparators = 4
  CenterTab = 2
  DelimiterTab = 3
  IncludeTrailingSpaces = -2147483648
  LeftTab = 0
  ManualWrap = 2
  NoWrap = 0
  RightTab = 1
  ShowLineAndParagraphSeparators = 2
  ShowTabsAndSpaces = 1
  SuppressColors = 8
  WordWrap = 1
  WrapAnywhere = 3
  WrapAtWordBoundaryOrAnywhere = 4

class QTextStream(_Mock):
  pass
  AlignAccountingStyle = 3
  AlignCenter = 2
  AlignLeft = 0
  AlignRight = 1
  FixedNotation = 1
  ForcePoint = 2
  ForceSign = 4
  Ok = 0
  ReadCorruptData = 2
  ReadPastEnd = 1
  ScientificNotation = 2
  ShowBase = 1
  SmartNotation = 0
  UppercaseBase = 8
  UppercaseDigits = 16
  WriteFailed = 3

class QTextStreamManipulator(_Mock):
  pass


class QTextTable(_Mock):
  pass


class QTextTableCell(_Mock):
  pass


class QTextTableCellFormat(_Mock):
  pass
  AlignBaseline = 6
  AlignBottom = 5
  AlignMiddle = 3
  AlignNormal = 0
  AlignSubScript = 2
  AlignSuperScript = 1
  AlignTop = 4
  AnchorHref = 8241
  AnchorName = 8242
  BackgroundBrush = 2080
  BackgroundImageUrl = 2083
  BlockAlignment = 4112
  BlockBottomMargin = 4145
  BlockFormat = 1
  BlockIndent = 4160
  BlockLeftMargin = 4146
  BlockNonBreakableLines = 4176
  BlockRightMargin = 4147
  BlockTopMargin = 4144
  BlockTrailingHorizontalRulerWidth = 4192
  CharFormat = 2
  CssFloat = 2048
  DashDotDotLine = 5
  DashDotLine = 4
  DashUnderline = 2
  DotLine = 3
  FirstFontProperty = 8160
  FontCapitalization = 8160
  FontFamily = 8192
  FontFixedPitch = 8200
  FontHintingPreference = 8166
  FontItalic = 8196
  FontKerning = 8165
  FontLetterSpacing = 8161
  FontOverline = 8198
  FontPixelSize = 8201
  FontPointSize = 8193
  FontSizeAdjustment = 8194
  FontSizeIncrement = 8194
  FontStrikeOut = 8199
  FontStyleHint = 8163
  FontStyleStrategy = 8164
  FontUnderline = 8197
  FontWeight = 8195
  FontWordSpacing = 8162
  ForegroundBrush = 2081
  FrameBorder = 16384
  FrameBorderBrush = 16393
  FrameBorderStyle = 16400
  FrameBottomMargin = 16390
  FrameFormat = 5
  FrameHeight = 16388
  FrameLeftMargin = 16391
  FrameMargin = 16385
  FramePadding = 16386
  FrameRightMargin = 16392
  FrameTopMargin = 16389
  FrameWidth = 16387
  FullWidthSelection = 24576
  ImageHeight = 20497
  ImageName = 20480
  ImageObject = 1
  ImageWidth = 20496
  InvalidFormat = -1
  IsAnchor = 8240
  LastFontProperty = 8201
  LayoutDirection = 2049
  LineHeight = 4168
  LineHeightType = 4169
  ListFormat = 3
  ListIndent = 12289
  ListNumberPrefix = 12290
  ListNumberSuffix = 12291
  ListStyle = 12288
  NoObject = 0
  NoUnderline = 0
  ObjectIndex = 0
  ObjectType = 12032
  OutlinePen = 2064
  PageBreakPolicy = 28672
  PageBreak_AlwaysAfter = 16
  PageBreak_AlwaysBefore = 1
  PageBreak_Auto = 0
  SingleUnderline = 1
  SpellCheckUnderline = 7
  TabPositions = 4149
  TableCellBottomPadding = 18451
  TableCellColumnSpan = 18449
  TableCellLeftPadding = 18452
  TableCellObject = 3
  TableCellPadding = 16643
  TableCellRightPadding = 18453
  TableCellRowSpan = 18448
  TableCellSpacing = 16642
  TableCellTopPadding = 18450
  TableColumnWidthConstraints = 16641
  TableColumns = 16640
  TableFormat = 4
  TableHeaderRowCount = 16644
  TableObject = 2
  TextIndent = 4148
  TextOutline = 8226
  TextToolTip = 8228
  TextUnderlineColor = 8208
  TextUnderlineStyle = 8227
  TextVerticalAlignment = 8225
  UserFormat = 100
  UserObject = 4096
  UserProperty = 1048576
  WaveUnderline = 6

class QTextTableFormat(_Mock):
  pass
  AnchorHref = 8241
  AnchorName = 8242
  BackgroundBrush = 2080
  BackgroundImageUrl = 2083
  BlockAlignment = 4112
  BlockBottomMargin = 4145
  BlockFormat = 1
  BlockIndent = 4160
  BlockLeftMargin = 4146
  BlockNonBreakableLines = 4176
  BlockRightMargin = 4147
  BlockTopMargin = 4144
  BlockTrailingHorizontalRulerWidth = 4192
  BorderStyle_Dashed = 2
  BorderStyle_DotDash = 5
  BorderStyle_DotDotDash = 6
  BorderStyle_Dotted = 1
  BorderStyle_Double = 4
  BorderStyle_Groove = 7
  BorderStyle_Inset = 9
  BorderStyle_None = 0
  BorderStyle_Outset = 10
  BorderStyle_Ridge = 8
  BorderStyle_Solid = 3
  CharFormat = 2
  CssFloat = 2048
  FirstFontProperty = 8160
  FloatLeft = 1
  FloatRight = 2
  FontCapitalization = 8160
  FontFamily = 8192
  FontFixedPitch = 8200
  FontHintingPreference = 8166
  FontItalic = 8196
  FontKerning = 8165
  FontLetterSpacing = 8161
  FontOverline = 8198
  FontPixelSize = 8201
  FontPointSize = 8193
  FontSizeAdjustment = 8194
  FontSizeIncrement = 8194
  FontStrikeOut = 8199
  FontStyleHint = 8163
  FontStyleStrategy = 8164
  FontUnderline = 8197
  FontWeight = 8195
  FontWordSpacing = 8162
  ForegroundBrush = 2081
  FrameBorder = 16384
  FrameBorderBrush = 16393
  FrameBorderStyle = 16400
  FrameBottomMargin = 16390
  FrameFormat = 5
  FrameHeight = 16388
  FrameLeftMargin = 16391
  FrameMargin = 16385
  FramePadding = 16386
  FrameRightMargin = 16392
  FrameTopMargin = 16389
  FrameWidth = 16387
  FullWidthSelection = 24576
  ImageHeight = 20497
  ImageName = 20480
  ImageObject = 1
  ImageWidth = 20496
  InFlow = 0
  InvalidFormat = -1
  IsAnchor = 8240
  LastFontProperty = 8201
  LayoutDirection = 2049
  LineHeight = 4168
  LineHeightType = 4169
  ListFormat = 3
  ListIndent = 12289
  ListNumberPrefix = 12290
  ListNumberSuffix = 12291
  ListStyle = 12288
  NoObject = 0
  ObjectIndex = 0
  ObjectType = 12032
  OutlinePen = 2064
  PageBreakPolicy = 28672
  PageBreak_AlwaysAfter = 16
  PageBreak_AlwaysBefore = 1
  PageBreak_Auto = 0
  TabPositions = 4149
  TableCellBottomPadding = 18451
  TableCellColumnSpan = 18449
  TableCellLeftPadding = 18452
  TableCellObject = 3
  TableCellPadding = 16643
  TableCellRightPadding = 18453
  TableCellRowSpan = 18448
  TableCellSpacing = 16642
  TableCellTopPadding = 18450
  TableColumnWidthConstraints = 16641
  TableColumns = 16640
  TableFormat = 4
  TableHeaderRowCount = 16644
  TableObject = 2
  TextIndent = 4148
  TextOutline = 8226
  TextToolTip = 8228
  TextUnderlineColor = 8208
  TextUnderlineStyle = 8227
  TextVerticalAlignment = 8225
  UserFormat = 100
  UserObject = 4096
  UserProperty = 1048576

class QThread(_Mock):
  pass
  HighPriority = 4
  HighestPriority = 5
  IdlePriority = 0
  InheritPriority = 7
  LowPriority = 2
  LowestPriority = 1
  NormalPriority = 3
  TimeCriticalPriority = 6

class QThreadPool(_Mock):
  pass


class QTime(_Mock):
  pass


class QTimeEdit(_Mock):
  pass
  AmPmSection = 1
  CorrectToNearestValue = 1
  CorrectToPreviousValue = 0
  DateSections_Mask = 1792
  DaySection = 256
  DrawChildren = 2
  DrawWindowBackground = 1
  HourSection = 16
  IgnoreMask = 4
  MSecSection = 2
  MinuteSection = 8
  MonthSection = 512
  NoButtons = 2
  NoSection = 0
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  PlusMinus = 1
  SecondSection = 4
  StepDownEnabled = 2
  StepNone = 0
  StepUpEnabled = 1
  TimeSections_Mask = 31
  UpDownArrows = 0
  YearSection = 1024

class QTimeLine(_Mock):
  pass
  Backward = 1
  CosineCurve = 5
  EaseInCurve = 0
  EaseInOutCurve = 2
  EaseOutCurve = 1
  Forward = 0
  LinearCurve = 3
  NotRunning = 0
  Paused = 1
  Running = 2
  SineCurve = 4

class QTimer(_Mock):
  pass


class QTimerEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QToolBar(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QToolBox(_Mock):
  pass
  Box = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  HLine = 4
  IgnoreMask = 4
  NoFrame = 0
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  Raised = 32
  Shadow_Mask = 240
  Shape_Mask = 15
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QToolButton(_Mock):
  pass
  DelayedPopup = 0
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  InstantPopup = 2
  MenuButtonPopup = 1
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QToolTip(_Mock):
  pass


class QTouchEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchPad = 1
  TouchScreen = 0
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QTransform(_Mock):
  pass
  TxNone = 0
  TxProject = 16
  TxRotate = 4
  TxScale = 2
  TxShear = 8
  TxTranslate = 1

class QTranslator(_Mock):
  pass


class QTreeView(_Mock):
  pass
  AboveItem = 1
  AllEditTriggers = 31
  AnimatingState = 6
  AnyKeyPressed = 16
  BelowItem = 2
  Box = 1
  CollapsingState = 5
  ContiguousSelection = 4
  CurrentChanged = 1
  DoubleClicked = 2
  DragDrop = 3
  DragOnly = 1
  DragSelectingState = 2
  DraggingState = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  DropOnly = 2
  EditKeyPressed = 8
  EditingState = 3
  EnsureVisible = 0
  ExpandingState = 4
  ExtendedSelection = 3
  HLine = 4
  IgnoreMask = 4
  InternalMove = 4
  MoveDown = 1
  MoveEnd = 5
  MoveHome = 4
  MoveLeft = 2
  MoveNext = 8
  MovePageDown = 7
  MovePageUp = 6
  MovePrevious = 9
  MoveRight = 3
  MoveUp = 0
  MultiSelection = 2
  NoDragDrop = 0
  NoEditTriggers = 0
  NoFrame = 0
  NoSelection = 0
  NoState = 0
  OnItem = 0
  OnViewport = 3
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  PositionAtBottom = 2
  PositionAtCenter = 3
  PositionAtTop = 1
  Raised = 32
  ScrollPerItem = 0
  ScrollPerPixel = 1
  SelectColumns = 2
  SelectItems = 0
  SelectRows = 1
  SelectedClicked = 4
  Shadow_Mask = 240
  Shape_Mask = 15
  SingleSelection = 1
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QTreeWidget(_Mock):
  pass
  AboveItem = 1
  AllEditTriggers = 31
  AnimatingState = 6
  AnyKeyPressed = 16
  BelowItem = 2
  Box = 1
  CollapsingState = 5
  ContiguousSelection = 4
  CurrentChanged = 1
  DoubleClicked = 2
  DragDrop = 3
  DragOnly = 1
  DragSelectingState = 2
  DraggingState = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  DropOnly = 2
  EditKeyPressed = 8
  EditingState = 3
  EnsureVisible = 0
  ExpandingState = 4
  ExtendedSelection = 3
  HLine = 4
  IgnoreMask = 4
  InternalMove = 4
  MoveDown = 1
  MoveEnd = 5
  MoveHome = 4
  MoveLeft = 2
  MoveNext = 8
  MovePageDown = 7
  MovePageUp = 6
  MovePrevious = 9
  MoveRight = 3
  MoveUp = 0
  MultiSelection = 2
  NoDragDrop = 0
  NoEditTriggers = 0
  NoFrame = 0
  NoSelection = 0
  NoState = 0
  OnItem = 0
  OnViewport = 3
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  PositionAtBottom = 2
  PositionAtCenter = 3
  PositionAtTop = 1
  Raised = 32
  ScrollPerItem = 0
  ScrollPerPixel = 1
  SelectColumns = 2
  SelectItems = 0
  SelectRows = 1
  SelectedClicked = 4
  Shadow_Mask = 240
  Shape_Mask = 15
  SingleSelection = 1
  StyledPanel = 6
  Sunken = 48
  VLine = 5
  WinPanel = 3

class QTreeWidgetItem(_Mock):
  pass
  DontShowIndicator = 1
  DontShowIndicatorWhenChildless = 2
  ShowIndicator = 0
  Type = 0
  UserType = 1000

class QTreeWidgetItemIterator(_Mock):
  pass
  All = 0
  Checked = 4096
  Disabled = 32768
  DragDisabled = 128
  DragEnabled = 64
  DropDisabled = 512
  DropEnabled = 256
  Editable = 65536
  Enabled = 16384
  HasChildren = 1024
  Hidden = 1
  NoChildren = 2048
  NotChecked = 8192
  NotEditable = 131072
  NotHidden = 2
  NotSelectable = 32
  Selectable = 16
  Selected = 4
  Unselected = 8
  UserFlag = 16777216

class QUdpSocket(_Mock):
  pass
  AddressInUseError = 8
  Append = 4
  BoundState = 4
  ClosingState = 6
  ConnectedState = 3
  ConnectingState = 2
  ConnectionRefusedError = 0
  DatagramTooLargeError = 6
  DefaultForPlatform = 0
  DontShareAddress = 2
  HostLookupState = 1
  HostNotFoundError = 2
  IPv4Protocol = 0
  IPv6Protocol = 1
  KeepAliveOption = 1
  ListeningState = 5
  LowDelayOption = 0
  MulticastLoopbackOption = 3
  MulticastTtlOption = 2
  NetworkError = 7
  NotOpen = 0
  ProxyAuthenticationRequiredError = 12
  ProxyConnectionClosedError = 15
  ProxyConnectionRefusedError = 14
  ProxyConnectionTimeoutError = 16
  ProxyNotFoundError = 17
  ProxyProtocolError = 18
  ReadOnly = 1
  ReadWrite = 3
  RemoteHostClosedError = 1
  ReuseAddressHint = 4
  ShareAddress = 1
  SocketAccessError = 3
  SocketAddressNotAvailableError = 9
  SocketResourceError = 4
  SocketTimeoutError = 5
  SslHandshakeFailedError = 13
  TcpSocket = 0
  Text = 16
  Truncate = 8
  UdpSocket = 1
  Unbuffered = 32
  UnconnectedState = 0
  UnfinishedSocketOperationError = 11
  UnknownNetworkLayerProtocol = -1
  UnknownSocketError = -1
  UnknownSocketType = -1
  UnsupportedSocketOperationError = 10
  WriteOnly = 2

class QUndoCommand(_Mock):
  pass


class QUndoGroup(_Mock):
  pass


class QUndoStack(_Mock):
  pass


class QUndoView(_Mock):
  pass
  AboveItem = 1
  Adjust = 1
  AllEditTriggers = 31
  AnimatingState = 6
  AnyKeyPressed = 16
  Batched = 1
  BelowItem = 2
  Box = 1
  CollapsingState = 5
  ContiguousSelection = 4
  CurrentChanged = 1
  DoubleClicked = 2
  DragDrop = 3
  DragOnly = 1
  DragSelectingState = 2
  DraggingState = 1
  DrawChildren = 2
  DrawWindowBackground = 1
  DropOnly = 2
  EditKeyPressed = 8
  EditingState = 3
  EnsureVisible = 0
  ExpandingState = 4
  ExtendedSelection = 3
  Fixed = 0
  Free = 1
  HLine = 4
  IconMode = 1
  IgnoreMask = 4
  InternalMove = 4
  LeftToRight = 0
  ListMode = 0
  MoveDown = 1
  MoveEnd = 5
  MoveHome = 4
  MoveLeft = 2
  MoveNext = 8
  MovePageDown = 7
  MovePageUp = 6
  MovePrevious = 9
  MoveRight = 3
  MoveUp = 0
  MultiSelection = 2
  NoDragDrop = 0
  NoEditTriggers = 0
  NoFrame = 0
  NoSelection = 0
  NoState = 0
  OnItem = 0
  OnViewport = 3
  Panel = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Plain = 16
  PositionAtBottom = 2
  PositionAtCenter = 3
  PositionAtTop = 1
  Raised = 32
  ScrollPerItem = 0
  ScrollPerPixel = 1
  SelectColumns = 2
  SelectItems = 0
  SelectRows = 1
  SelectedClicked = 4
  Shadow_Mask = 240
  Shape_Mask = 15
  SinglePass = 0
  SingleSelection = 1
  Snap = 2
  Static = 0
  StyledPanel = 6
  Sunken = 48
  TopToBottom = 1
  VLine = 5
  WinPanel = 3

class QUrl(_Mock):
  pass
  RemoveAuthority = 30
  RemoveFragment = 128
  RemovePassword = 2
  RemovePath = 32
  RemovePort = 8
  RemoveQuery = 64
  RemoveScheme = 1
  RemoveUserInfo = 6
  StrictMode = 1
  StripTrailingSlash = 65536
  TolerantMode = 0

class QUrlInfo(_Mock):
  pass
  ExeGroup = 8
  ExeOther = 1
  ExeOwner = 64
  ReadGroup = 32
  ReadOther = 4
  ReadOwner = 256
  WriteGroup = 16
  WriteOther = 2
  WriteOwner = 128

class QUuid(_Mock):
  pass
  DCE = 2
  EmbeddedPOSIX = 2
  Microsoft = 6
  NCS = 0
  Name = 3
  Random = 4
  Reserved = 7
  Time = 1
  VarUnknown = -1
  VerUnknown = -1

class QVBoxLayout(_Mock):
  pass
  BottomToTop = 3
  Down = 2
  LeftToRight = 0
  RightToLeft = 1
  SetDefaultConstraint = 0
  SetFixedSize = 3
  SetMaximumSize = 4
  SetMinAndMaxSize = 5
  SetMinimumSize = 2
  SetNoConstraint = 1
  TopToBottom = 2
  Up = 3

class QValidator(_Mock):
  pass
  Acceptable = 2
  Intermediate = 1
  Invalid = 0

class QVariant(_Mock):
  pass
  BitArray = 13
  Bitmap = 73
  Bool = 1
  Brush = 66
  ByteArray = 12
  Char = 7
  Color = 67
  Cursor = 74
  Date = 14
  DateTime = 16
  Double = 6
  EasingCurve = 29
  Font = 64
  Hash = 28
  Icon = 69
  Image = 70
  Int = 2
  Invalid = 0
  KeySequence = 76
  Line = 23
  LineF = 24
  List = 9
  Locale = 18
  LongLong = 4
  Map = 8
  Matrix = 80
  Matrix4x4 = 82
  Palette = 68
  Pen = 77
  Pixmap = 65
  Point = 25
  PointF = 26
  Polygon = 71
  Quaternion = 86
  Rect = 19
  RectF = 20
  RegExp = 27
  Region = 72
  Size = 21
  SizeF = 22
  SizePolicy = 75
  String = 10
  StringList = 11
  TextFormat = 79
  TextLength = 78
  Time = 15
  Transform = 81
  UInt = 3
  ULongLong = 5
  Url = 17
  UserType = 127
  Vector2D = 83
  Vector3D = 84
  Vector4D = 85

class QVariantAnimation(_Mock):
  pass
  Backward = 1
  DeleteWhenStopped = 1
  Forward = 0
  KeepWhenStopped = 0
  Paused = 1
  Running = 2
  Stopped = 0

class QVector2D(_Mock):
  pass


class QVector3D(_Mock):
  pass


class QVector4D(_Mock):
  pass


class QWaitCondition(_Mock):
  pass


class QWebDatabase(_Mock):
  pass


class QWebElement(_Mock):
  pass
  CascadedStyle = 1
  ComputedStyle = 2
  InlineStyle = 0

class QWebElementCollection(_Mock):
  pass


class QWebFrame(_Mock):
  pass
  AllLayers = 255
  ContentsLayer = 16
  PanIconLayer = 64
  ScrollBarLayer = 32

class QWebHistory(_Mock):
  pass


class QWebHistoryInterface(_Mock):
  pass


class QWebHistoryItem(_Mock):
  pass


class QWebHitTestResult(_Mock):
  pass


class QWebInspector(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QWebPage(_Mock):
  pass
  AlignCenter = 63
  AlignJustified = 64
  AlignLeft = 65
  AlignRight = 66
  Back = 8
  ChooseMultipleFilesExtension = 0
  Copy = 13
  CopyImageToClipboard = 7
  CopyImageUrlToClipboard = 68
  CopyLinkToClipboard = 4
  Cut = 12
  DelegateAllLinks = 2
  DelegateExternalLinks = 1
  DeleteEndOfWord = 42
  DeleteStartOfWord = 41
  DontDelegateLinks = 0
  DownloadImageToDisk = 6
  DownloadLinkToDisk = 3
  ErrorPageExtension = 1
  FindBackward = 1
  FindCaseSensitively = 2
  FindWrapsAroundDocument = 4
  Forward = 9
  Geolocation = 1
  HighlightAllOccurrences = 8
  Http = 1
  Indent = 61
  InsertLineSeparator = 51
  InsertOrderedList = 60
  InsertParagraphSeparator = 50
  InsertUnorderedList = 59
  InspectElement = 49
  MoveToEndOfBlock = 26
  MoveToEndOfDocument = 28
  MoveToEndOfLine = 24
  MoveToNextChar = 17
  MoveToNextLine = 21
  MoveToNextWord = 19
  MoveToPreviousChar = 18
  MoveToPreviousLine = 22
  MoveToPreviousWord = 20
  MoveToStartOfBlock = 25
  MoveToStartOfDocument = 27
  MoveToStartOfLine = 23
  NavigationTypeBackOrForward = 2
  NavigationTypeFormResubmitted = 4
  NavigationTypeFormSubmitted = 1
  NavigationTypeLinkClicked = 0
  NavigationTypeOther = 5
  NavigationTypeReload = 3
  NoWebAction = -1
  Notifications = 0
  OpenFrameInNewWindow = 2
  OpenImageInNewWindow = 5
  OpenLink = 0
  OpenLinkInNewWindow = 1
  Outdent = 62
  Paste = 14
  PasteAndMatchStyle = 54
  PermissionDeniedByUser = 2
  PermissionGrantedByUser = 1
  PermissionUnknown = 0
  QtNetwork = 0
  Redo = 16
  Reload = 11
  ReloadAndBypassCache = 53
  RemoveFormat = 55
  SelectAll = 52
  SelectEndOfBlock = 38
  SelectEndOfDocument = 40
  SelectEndOfLine = 36
  SelectNextChar = 29
  SelectNextLine = 33
  SelectNextWord = 31
  SelectPreviousChar = 30
  SelectPreviousLine = 34
  SelectPreviousWord = 32
  SelectStartOfBlock = 37
  SelectStartOfDocument = 39
  SelectStartOfLine = 35
  SetTextDirectionDefault = 43
  SetTextDirectionLeftToRight = 44
  SetTextDirectionRightToLeft = 45
  Stop = 10
  StopScheduledPageRefresh = 67
  ToggleBold = 46
  ToggleItalic = 47
  ToggleStrikethrough = 56
  ToggleSubscript = 57
  ToggleSuperscript = 58
  ToggleUnderline = 48
  Undo = 15
  WebBrowserWindow = 0
  WebKit = 2
  WebModalDialog = 1

class QWebPluginFactory(_Mock):
  pass


class QWebSecurityOrigin(_Mock):
  pass


class QWebSettings(_Mock):
  pass
  AcceleratedCompositingEnabled = 17
  AutoLoadImages = 0
  CursiveFont = 4
  DefaultFixedFontSize = 3
  DefaultFontSize = 2
  DefaultFrameIconGraphic = 2
  DeveloperExtrasEnabled = 7
  DnsPrefetchEnabled = 15
  FantasyFont = 5
  FixedFont = 1
  FrameFlatteningEnabled = 21
  HyperlinkAuditingEnabled = 26
  InputSpeechButtonGraphic = 5
  JavaEnabled = 2
  JavascriptCanAccessClipboard = 6
  JavascriptCanCloseWindows = 23
  JavascriptCanOpenWindows = 5
  JavascriptEnabled = 1
  LinksIncludedInFocusChain = 8
  LocalContentCanAccessFileUrls = 19
  LocalContentCanAccessRemoteUrls = 14
  LocalStorageDatabaseEnabled = 13
  LocalStorageEnabled = 13
  MinimumFontSize = 0
  MinimumLogicalFontSize = 1
  MissingImageGraphic = 0
  MissingPluginGraphic = 1
  OfflineStorageDatabaseEnabled = 11
  OfflineWebApplicationCacheEnabled = 12
  PluginsEnabled = 3
  PrintElementBackgrounds = 10
  PrivateBrowsingEnabled = 4
  SansSerifFont = 3
  SearchCancelButtonGraphic = 6
  SearchCancelButtonPressedGraphic = 7
  SerifFont = 2
  SiteSpecificQuirksEnabled = 22
  SpatialNavigationEnabled = 18
  StandardFont = 0
  TextAreaSizeGripCornerGraphic = 3
  TiledBackingStoreEnabled = 20
  WebGLEnabled = 24
  XSSAuditingEnabled = 16
  ZoomTextOnly = 9

class QWebView(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QWhatsThis(_Mock):
  pass


class QWhatsThisClickedEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QWheelEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QWidget(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QWidgetAction(_Mock):
  pass
  AboutQtRole = 3
  AboutRole = 4
  ApplicationSpecificRole = 2
  HighPriority = 256
  Hover = 1
  LowPriority = 0
  NegativeSoftKey = 2
  NoRole = 0
  NoSoftKey = 0
  NormalPriority = 128
  PositiveSoftKey = 1
  PreferencesRole = 5
  QuitRole = 6
  SelectSoftKey = 3
  TextHeuristicRole = 1
  Trigger = 0

class QWidgetItem(_Mock):
  pass


class QWindowStateChangeEvent(_Mock):
  pass
  AccessibilityDescription = 130
  AccessibilityHelp = 119
  AccessibilityPrepare = 86
  ActionAdded = 114
  ActionChanged = 113
  ActionRemoved = 115
  ActivationChange = 99
  ApplicationActivate = 121
  ApplicationActivated = 121
  ApplicationDeactivate = 122
  ApplicationDeactivated = 122
  ApplicationFontChange = 36
  ApplicationLayoutDirectionChange = 37
  ApplicationPaletteChange = 38
  ApplicationWindowIconChange = 35
  ChildAdded = 68
  ChildPolished = 69
  ChildRemoved = 71
  Clipboard = 40
  Close = 19
  CloseSoftwareInputPanel = 200
  ContextMenu = 82
  CursorChange = 183
  DeferredDelete = 52
  DragEnter = 60
  DragLeave = 62
  DragMove = 61
  Drop = 63
  DynamicPropertyChange = 170
  EnabledChange = 98
  Enter = 10
  EnterWhatsThisMode = 124
  FileOpen = 116
  FocusIn = 8
  FocusOut = 9
  FontChange = 97
  Gesture = 198
  GestureOverride = 202
  GrabKeyboard = 188
  GrabMouse = 186
  GraphicsSceneContextMenu = 159
  GraphicsSceneDragEnter = 164
  GraphicsSceneDragLeave = 166
  GraphicsSceneDragMove = 165
  GraphicsSceneDrop = 167
  GraphicsSceneHelp = 163
  GraphicsSceneHoverEnter = 160
  GraphicsSceneHoverLeave = 162
  GraphicsSceneHoverMove = 161
  GraphicsSceneMouseDoubleClick = 158
  GraphicsSceneMouseMove = 155
  GraphicsSceneMousePress = 156
  GraphicsSceneMouseRelease = 157
  GraphicsSceneMove = 182
  GraphicsSceneResize = 181
  GraphicsSceneWheel = 168
  Hide = 18
  HideToParent = 27
  HoverEnter = 127
  HoverLeave = 128
  HoverMove = 129
  IconDrag = 96
  IconTextChange = 101
  InputMethod = 83
  KeyPress = 6
  KeyRelease = 7
  KeyboardLayoutChange = 169
  LanguageChange = 89
  LayoutDirectionChange = 90
  LayoutRequest = 76
  Leave = 11
  LeaveWhatsThisMode = 125
  LocaleChange = 88
  MaxUser = 65535
  MenubarUpdated = 153
  MetaCall = 43
  ModifiedChange = 102
  MouseButtonDblClick = 4
  MouseButtonPress = 2
  MouseButtonRelease = 3
  MouseMove = 5
  MouseTrackingChange = 109
  Move = 13
  OkRequest = 94
  Paint = 12
  PaletteChange = 39
  ParentAboutToChange = 131
  ParentChange = 21
  PlatformPanel = 212
  Polish = 75
  PolishRequest = 74
  QueryWhatsThis = 123
  RequestSoftwareInputPanel = 199
  Resize = 14
  Shortcut = 117
  ShortcutOverride = 51
  Show = 17
  ShowToParent = 26
  SockAct = 50
  StateMachineSignal = 192
  StateMachineWrapped = 193
  StatusTip = 112
  StyleChange = 100
  TabletEnterProximity = 171
  TabletLeaveProximity = 172
  TabletMove = 87
  TabletPress = 92
  TabletRelease = 93
  Timer = 1
  ToolBarChange = 120
  ToolTip = 110
  ToolTipChange = 184
  TouchBegin = 194
  TouchEnd = 196
  TouchUpdate = 195
  UngrabKeyboard = 189
  UngrabMouse = 187
  UpdateLater = 78
  UpdateRequest = 77
  User = 1000
  WhatsThis = 111
  WhatsThisClicked = 118
  Wheel = 31
  WinEventAct = 132
  WinIdChange = 203
  WindowActivate = 24
  WindowBlocked = 103
  WindowDeactivate = 25
  WindowIconChange = 34
  WindowStateChange = 105
  WindowTitleChange = 33
  WindowUnblocked = 104
  ZOrderChange = 126

class QWizard(_Mock):
  pass
  Accepted = 1
  AeroStyle = 3
  BackButton = 0
  BackgroundPixmap = 3
  BannerPixmap = 2
  CancelButton = 4
  CancelButtonOnLeft = 1024
  ClassicStyle = 0
  CommitButton = 2
  CustomButton1 = 6
  CustomButton2 = 7
  CustomButton3 = 8
  DisabledBackButtonOnLastPage = 64
  DrawChildren = 2
  DrawWindowBackground = 1
  ExtendedWatermarkPixmap = 4
  FinishButton = 3
  HaveCustomButton1 = 8192
  HaveCustomButton2 = 16384
  HaveCustomButton3 = 32768
  HaveFinishButtonOnEarlyPages = 256
  HaveHelpButton = 2048
  HaveNextButtonOnLastPage = 128
  HelpButton = 5
  HelpButtonOnRight = 4096
  IgnoreMask = 4
  IgnoreSubTitles = 2
  IndependentPages = 1
  LogoPixmap = 1
  MacStyle = 2
  ModernStyle = 1
  NextButton = 1
  NoBackButtonOnLastPage = 32
  NoBackButtonOnStartPage = 16
  NoCancelButton = 512
  NoDefaultButton = 8
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Rejected = 0
  Stretch = 9
  WatermarkPixmap = 0

class QWizardPage(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3

class QWorkspace(_Mock):
  pass
  CreationOrder = 0
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  StackingOrder = 1

class QWriteLocker(_Mock):
  pass


class QX11EmbedContainer(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  Internal = 1
  InvalidWindowID = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Unknown = 0

class QX11EmbedWidget(_Mock):
  pass
  DrawChildren = 2
  DrawWindowBackground = 1
  IgnoreMask = 4
  Internal = 1
  InvalidWindowID = 2
  PdmDepth = 6
  PdmDpiX = 7
  PdmDpiY = 8
  PdmHeight = 2
  PdmHeightMM = 4
  PdmNumColors = 5
  PdmPhysicalDpiX = 9
  PdmPhysicalDpiY = 10
  PdmWidth = 1
  PdmWidthMM = 3
  Unknown = 0

class QX11Info(_Mock):
  pass


class QXmlAttributes(_Mock):
  pass


class QXmlContentHandler(_Mock):
  pass


class QXmlDTDHandler(_Mock):
  pass


class QXmlDeclHandler(_Mock):
  pass


class QXmlDefaultHandler(_Mock):
  pass


class QXmlEntityResolver(_Mock):
  pass


class QXmlErrorHandler(_Mock):
  pass


class QXmlFormatter(_Mock):
  pass


class QXmlInputSource(_Mock):
  pass
  EndOfData = 65534
  EndOfDocument = 65535

class QXmlItem(_Mock):
  pass


class QXmlLexicalHandler(_Mock):
  pass


class QXmlLocator(_Mock):
  pass


class QXmlName(_Mock):
  pass


class QXmlNamePool(_Mock):
  pass


class QXmlNamespaceSupport(_Mock):
  pass


class QXmlNodeModelIndex(_Mock):
  pass
  Attribute = 1
  Comment = 2
  Document = 4
  Element = 8
  Follows = 1
  Is = 0
  Namespace = 16
  Precedes = -1
  ProcessingInstruction = 32
  Text = 64

class QXmlParseException(_Mock):
  pass


class QXmlQuery(_Mock):
  pass
  XQuery10 = 1
  XSLT20 = 2

class QXmlReader(_Mock):
  pass


class QXmlResultItems(_Mock):
  pass


class QXmlSchema(_Mock):
  pass


class QXmlSchemaValidator(_Mock):
  pass


class QXmlSerializer(_Mock):
  pass


class QXmlSimpleReader(_Mock):
  pass


class QXmlStreamAttribute(_Mock):
  pass


class QXmlStreamAttributes(_Mock):
  pass


class QXmlStreamEntityDeclaration(_Mock):
  pass


class QXmlStreamEntityResolver(_Mock):
  pass


class QXmlStreamNamespaceDeclaration(_Mock):
  pass


class QXmlStreamNotationDeclaration(_Mock):
  pass


class QXmlStreamReader(_Mock):
  pass
  Characters = 6
  Comment = 7
  CustomError = 2
  DTD = 8
  EndDocument = 3
  EndElement = 5
  EntityReference = 9
  ErrorOnUnexpectedElement = 0
  IncludeChildElements = 1
  Invalid = 1
  NoError = 0
  NoToken = 0
  NotWellFormedError = 3
  PrematureEndOfDocumentError = 4
  ProcessingInstruction = 10
  SkipChildElements = 2
  StartDocument = 2
  StartElement = 4
  UnexpectedElementError = 1

class QXmlStreamWriter(_Mock):
  pass


class Qt(_Mock):
  pass
  AA_CaptureMultimediaKeys = 11
  AA_DontCreateNativeWidgetSiblings = 4
  AA_DontShowIconsInMenus = 2
  AA_DontUseNativeMenuBar = 6
  AA_ImmediateWidgetCreation = 0
  AA_MSWindowsUseDirect3DByDefault = 1
  AA_MacDontSwapCtrlAndMeta = 7
  AA_MacPluginApplication = 5
  AA_NativeWindows = 3
  AA_S60DisablePartialScreenInputMode = 9
  AA_S60DontConstructApplicationPanes = 8
  AA_X11InitThreads = 10
  ALT = 134217728
  AbsoluteSize = 0
  AccessibleDescriptionRole = 12
  AccessibleTextRole = 11
  ActionMask = 255
  ActionsContextMenu = 2
  ActiveWindowFocusReason = 3
  AlignAbsolute = 16
  AlignBottom = 64
  AlignCenter = 132
  AlignHCenter = 4
  AlignHorizontal_Mask = 31
  AlignJustify = 8
  AlignLeading = 1
  AlignLeft = 1
  AlignRight = 2
  AlignTop = 32
  AlignTrailing = 2
  AlignVCenter = 128
  AlignVertical_Mask = 224
  AllDockWidgetAreas = 15
  AllToolBarAreas = 15
  AltModifier = 134217728
  AnchorBottom = 5
  AnchorHorizontalCenter = 1
  AnchorHref = 1
  AnchorLeft = 0
  AnchorName = 0
  AnchorRight = 2
  AnchorTop = 3
  AnchorVerticalCenter = 4
  ApplicationModal = 2
  ApplicationShortcut = 2
  ArrowCursor = 0
  AscendingOrder = 0
  AutoColor = 0
  AutoCompatConnection = 3
  AutoConnection = 0
  AutoDither = 0
  AutoText = 2
  AvoidDither = 128
  BDiagPattern = 12
  BackgroundColorRole = 8
  BackgroundRole = 8
  BacktabFocusReason = 2
  BevelJoin = 64
  BitmapCursor = 24
  BlankCursor = 10
  BlockingQueuedConnection = 4
  BottomDockWidgetArea = 8
  BottomLeftCorner = 2
  BottomLeftSection = 8
  BottomRightCorner = 3
  BottomRightSection = 6
  BottomSection = 7
  BottomToolBarArea = 8
  BusyCursor = 16
  BypassGraphicsProxyWidget = 536870912
  CTRL = 67108864
  CaseInsensitive = 0
  CaseSensitive = 1
  CheckStateRole = 10
  Checked = 2
  ClickFocus = 2
  ClosedHandCursor = 18
  ColorOnly = 3
  ConicalGradientPattern = 17
  ContainsItemBoundingRect = 2
  ContainsItemShape = 0
  ControlModifier = 67108864
  CopyAction = 1
  CrossCursor = 2
  CrossPattern = 11
  CustomContextMenu = 3
  CustomCursor = 25
  CustomDashLine = 6
  CustomGesture = 256
  CustomizeWindowHint = 33554432
  DashDotDotLine = 5
  DashDotLine = 4
  DashLine = 2
  DecorationRole = 1
  DefaultContextMenu = 1
  DefaultLocaleLongDate = 7
  DefaultLocaleShortDate = 6
  Dense1Pattern = 2
  Dense2Pattern = 3
  Dense3Pattern = 4
  Dense4Pattern = 5
  Dense5Pattern = 6
  Dense6Pattern = 7
  Dense7Pattern = 8
  DescendingOrder = 1
  Desktop = 17
  DeviceCoordinates = 0
  DiagCrossPattern = 14
  Dialog = 3
  DiffuseAlphaDither = 8
  DiffuseDither = 0
  DirectConnection = 1
  DisplayRole = 0
  DockWidgetArea_Mask = 15
  DontStartGestureOnChildren = 1
  DotLine = 3
  DownArrow = 2
  DragCopyCursor = 19
  DragLinkCursor = 21
  DragMoveCursor = 20
  Drawer = 7
  EditRole = 2
  ElideLeft = 0
  ElideMiddle = 2
  ElideNone = 3
  ElideRight = 1
  ExactHit = 0
  FDiagPattern = 13
  FastTransformation = 0
  FlatCap = 0
  FontRole = 6
  ForbiddenCursor = 14
  ForegroundRole = 9
  FramelessWindowHint = 2048
  Friday = 5
  FuzzyHit = 1
  GestureCanceled = 4
  GestureFinished = 3
  GestureStarted = 1
  GestureUpdated = 2
  GroupSwitchModifier = 1073741824
  HighEventPriority = 1
  HorPattern = 9
  Horizontal = 1
  IBeamCursor = 4
  ISODate = 1
  IgnoreAction = 0
  IgnoreAspectRatio = 0
  IgnoredGesturesPropagateToParent = 4
  ImAnchorPosition = 6
  ImCurrentSelection = 4
  ImCursorPosition = 2
  ImFont = 1
  ImMaximumTextLength = 5
  ImMicroFocus = 0
  ImSurroundingText = 3
  ImhDialableCharactersOnly = 1048576
  ImhDigitsOnly = 65536
  ImhEmailCharactersOnly = 2097152
  ImhExclusiveInputMask = -65536
  ImhFormattedNumbersOnly = 131072
  ImhHiddenText = 1
  ImhLowercaseOnly = 524288
  ImhNoAutoUppercase = 2
  ImhNoPredictiveText = 32
  ImhNone = 0
  ImhPreferLowercase = 16
  ImhPreferNumbers = 4
  ImhPreferUppercase = 8
  ImhUppercaseOnly = 262144
  ImhUrlCharactersOnly = 4194304
  InitialSortOrderRole = 14
  IntersectClip = 2
  IntersectsItemBoundingRect = 3
  IntersectsItemShape = 1
  ItemIsDragEnabled = 4
  ItemIsDropEnabled = 8
  ItemIsEditable = 2
  ItemIsEnabled = 32
  ItemIsSelectable = 1
  ItemIsTristate = 64
  ItemIsUserCheckable = 16
  KeepAspectRatio = 1
  KeepAspectRatioByExpanding = 2
  Key_0 = 48
  Key_1 = 49
  Key_2 = 50
  Key_3 = 51
  Key_4 = 52
  Key_5 = 53
  Key_6 = 54
  Key_7 = 55
  Key_8 = 56
  Key_9 = 57
  Key_A = 65
  Key_AE = 198
  Key_Aacute = 193
  Key_Acircumflex = 194
  Key_AddFavorite = 16777408
  Key_Adiaeresis = 196
  Key_Agrave = 192
  Key_Alt = 16777251
  Key_AltGr = 16781571
  Key_Ampersand = 38
  Key_Any = 32
  Key_Apostrophe = 39
  Key_ApplicationLeft = 16777415
  Key_ApplicationRight = 16777416
  Key_Aring = 197
  Key_AsciiCircum = 94
  Key_AsciiTilde = 126
  Key_Asterisk = 42
  Key_At = 64
  Key_Atilde = 195
  Key_AudioCycleTrack = 16777478
  Key_AudioForward = 16777474
  Key_AudioRandomPlay = 16777476
  Key_AudioRepeat = 16777475
  Key_AudioRewind = 16777413
  Key_Away = 16777464
  Key_B = 66
  Key_Back = 16777313
  Key_BackForward = 16777414
  Key_Backslash = 92
  Key_Backspace = 16777219
  Key_Backtab = 16777218
  Key_Bar = 124
  Key_BassBoost = 16777331
  Key_BassDown = 16777333
  Key_BassUp = 16777332
  Key_Battery = 16777470
  Key_Bluetooth = 16777471
  Key_Book = 16777417
  Key_BraceLeft = 123
  Key_BraceRight = 125
  Key_BracketLeft = 91
  Key_BracketRight = 93
  Key_BrightnessAdjust = 16777410
  Key_C = 67
  Key_CD = 16777418
  Key_Calculator = 16777419
  Key_Calendar = 16777444
  Key_Call = 17825796
  Key_Camera = 17825824
  Key_CameraFocus = 17825825
  Key_Cancel = 16908289
  Key_CapsLock = 16777252
  Key_Ccedilla = 199
  Key_Clear = 16777227
  Key_ClearGrab = 16777421
  Key_Close = 16777422
  Key_Codeinput = 16781623
  Key_Colon = 58
  Key_Comma = 44
  Key_Community = 16777412
  Key_Context1 = 17825792
  Key_Context2 = 17825793
  Key_Context3 = 17825794
  Key_Context4 = 17825795
  Key_ContrastAdjust = 16777485
  Key_Control = 16777249
  Key_Copy = 16777423
  Key_Cut = 16777424
  Key_D = 68
  Key_DOS = 16777426
  Key_Dead_Abovedot = 16781910
  Key_Dead_Abovering = 16781912
  Key_Dead_Acute = 16781905
  Key_Dead_Belowdot = 16781920
  Key_Dead_Breve = 16781909
  Key_Dead_Caron = 16781914
  Key_Dead_Cedilla = 16781915
  Key_Dead_Circumflex = 16781906
  Key_Dead_Diaeresis = 16781911
  Key_Dead_Doubleacute = 16781913
  Key_Dead_Grave = 16781904
  Key_Dead_Hook = 16781921
  Key_Dead_Horn = 16781922
  Key_Dead_Iota = 16781917
  Key_Dead_Macron = 16781908
  Key_Dead_Ogonek = 16781916
  Key_Dead_Semivoiced_Sound = 16781919
  Key_Dead_Tilde = 16781907
  Key_Dead_Voiced_Sound = 16781918
  Key_Delete = 16777223
  Key_Direction_L = 16777305
  Key_Direction_R = 16777312
  Key_Display = 16777425
  Key_Documents = 16777427
  Key_Dollar = 36
  Key_Down = 16777237
  Key_E = 69
  Key_ETH = 208
  Key_Eacute = 201
  Key_Ecircumflex = 202
  Key_Ediaeresis = 203
  Key_Egrave = 200
  Key_Eisu_Shift = 16781615
  Key_Eisu_toggle = 16781616
  Key_Eject = 16777401
  Key_End = 16777233
  Key_Enter = 16777221
  Key_Equal = 61
  Key_Escape = 16777216
  Key_Excel = 16777428
  Key_Exclam = 33
  Key_Execute = 16908291
  Key_Explorer = 16777429
  Key_F = 70
  Key_F1 = 16777264
  Key_F10 = 16777273
  Key_F11 = 16777274
  Key_F12 = 16777275
  Key_F13 = 16777276
  Key_F14 = 16777277
  Key_F15 = 16777278
  Key_F16 = 16777279
  Key_F17 = 16777280
  Key_F18 = 16777281
  Key_F19 = 16777282
  Key_F2 = 16777265
  Key_F20 = 16777283
  Key_F21 = 16777284
  Key_F22 = 16777285
  Key_F23 = 16777286
  Key_F24 = 16777287
  Key_F25 = 16777288
  Key_F26 = 16777289
  Key_F27 = 16777290
  Key_F28 = 16777291
  Key_F29 = 16777292
  Key_F3 = 16777266
  Key_F30 = 16777293
  Key_F31 = 16777294
  Key_F32 = 16777295
  Key_F33 = 16777296
  Key_F34 = 16777297
  Key_F35 = 16777298
  Key_F4 = 16777267
  Key_F5 = 16777268
  Key_F6 = 16777269
  Key_F7 = 16777270
  Key_F8 = 16777271
  Key_F9 = 16777272
  Key_Favorites = 16777361
  Key_Finance = 16777411
  Key_Flip = 17825798
  Key_Forward = 16777314
  Key_G = 71
  Key_Game = 16777430
  Key_Go = 16777431
  Key_Greater = 62
  Key_H = 72
  Key_Hangul = 16781617
  Key_Hangul_Banja = 16781625
  Key_Hangul_End = 16781619
  Key_Hangul_Hanja = 16781620
  Key_Hangul_Jamo = 16781621
  Key_Hangul_Jeonja = 16781624
  Key_Hangul_PostHanja = 16781627
  Key_Hangul_PreHanja = 16781626
  Key_Hangul_Romaja = 16781622
  Key_Hangul_Special = 16781631
  Key_Hangul_Start = 16781618
  Key_Hangup = 17825797
  Key_Hankaku = 16781609
  Key_Help = 16777304
  Key_Henkan = 16781603
  Key_Hibernate = 16777480
  Key_Hiragana = 16781605
  Key_Hiragana_Katakana = 16781607
  Key_History = 16777407
  Key_Home = 16777232
  Key_HomePage = 16777360
  Key_HotLinks = 16777409
  Key_Hyper_L = 16777302
  Key_Hyper_R = 16777303
  Key_I = 73
  Key_Iacute = 205
  Key_Icircumflex = 206
  Key_Idiaeresis = 207
  Key_Igrave = 204
  Key_Insert = 16777222
  Key_J = 74
  Key_K = 75
  Key_Kana_Lock = 16781613
  Key_Kana_Shift = 16781614
  Key_Kanji = 16781601
  Key_Katakana = 16781606
  Key_KeyboardBrightnessDown = 16777398
  Key_KeyboardBrightnessUp = 16777397
  Key_KeyboardLightOnOff = 16777396
  Key_L = 76
  Key_LastNumberRedial = 17825801
  Key_Launch0 = 16777378
  Key_Launch1 = 16777379
  Key_Launch2 = 16777380
  Key_Launch3 = 16777381
  Key_Launch4 = 16777382
  Key_Launch5 = 16777383
  Key_Launch6 = 16777384
  Key_Launch7 = 16777385
  Key_Launch8 = 16777386
  Key_Launch9 = 16777387
  Key_LaunchA = 16777388
  Key_LaunchB = 16777389
  Key_LaunchC = 16777390
  Key_LaunchD = 16777391
  Key_LaunchE = 16777392
  Key_LaunchF = 16777393
  Key_LaunchG = 16777486
  Key_LaunchH = 16777487
  Key_LaunchMail = 16777376
  Key_LaunchMedia = 16777377
  Key_Left = 16777234
  Key_Less = 60
  Key_LightBulb = 16777405
  Key_LogOff = 16777433
  Key_M = 77
  Key_MailForward = 16777467
  Key_Market = 16777434
  Key_Massyo = 16781612
  Key_MediaLast = 16842751
  Key_MediaNext = 16777347
  Key_MediaPause = 16777349
  Key_MediaPlay = 16777344
  Key_MediaPrevious = 16777346
  Key_MediaRecord = 16777348
  Key_MediaStop = 16777345
  Key_MediaTogglePlayPause = 16777350
  Key_Meeting = 16777435
  Key_Memo = 16777404
  Key_Menu = 16777301
  Key_MenuKB = 16777436
  Key_MenuPB = 16777437
  Key_Messenger = 16777465
  Key_Meta = 16777250
  Key_Minus = 45
  Key_Mode_switch = 16781694
  Key_MonBrightnessDown = 16777395
  Key_MonBrightnessUp = 16777394
  Key_Muhenkan = 16781602
  Key_Multi_key = 16781600
  Key_MultipleCandidate = 16781629
  Key_Music = 16777469
  Key_MySites = 16777438
  Key_N = 78
  Key_News = 16777439
  Key_No = 16842754
  Key_Ntilde = 209
  Key_NumLock = 16777253
  Key_NumberSign = 35
  Key_O = 79
  Key_Oacute = 211
  Key_Ocircumflex = 212
  Key_Odiaeresis = 214
  Key_OfficeHome = 16777440
  Key_Ograve = 210
  Key_Ooblique = 216
  Key_OpenUrl = 16777364
  Key_Option = 16777441
  Key_Otilde = 213
  Key_P = 80
  Key_PageDown = 16777239
  Key_PageUp = 16777238
  Key_ParenLeft = 40
  Key_ParenRight = 41
  Key_Paste = 16777442
  Key_Pause = 16777224
  Key_Percent = 37
  Key_Period = 46
  Key_Phone = 16777443
  Key_Pictures = 16777468
  Key_Play = 16908293
  Key_Plus = 43
  Key_PowerDown = 16777483
  Key_PowerOff = 16777399
  Key_PreviousCandidate = 16781630
  Key_Print = 16777225
  Key_Printer = 16908290
  Key_Q = 81
  Key_Question = 63
  Key_QuoteDbl = 34
  Key_QuoteLeft = 96
  Key_R = 82
  Key_Refresh = 16777316
  Key_Reload = 16777446
  Key_Reply = 16777445
  Key_Return = 16777220
  Key_Right = 16777236
  Key_Romaji = 16781604
  Key_RotateWindows = 16777447
  Key_RotationKB = 16777449
  Key_RotationPB = 16777448
  Key_S = 83
  Key_Save = 16777450
  Key_ScreenSaver = 16777402
  Key_ScrollLock = 16777254
  Key_Search = 16777362
  Key_Select = 16842752
  Key_Semicolon = 59
  Key_Send = 16777451
  Key_Shift = 16777248
  Key_Shop = 16777406
  Key_SingleCandidate = 16781628
  Key_Slash = 47
  Key_Sleep = 16908292
  Key_Space = 32
  Key_Spell = 16777452
  Key_SplitScreen = 16777453
  Key_Standby = 16777363
  Key_Stop = 16777315
  Key_Subtitle = 16777477
  Key_Super_L = 16777299
  Key_Super_R = 16777300
  Key_Support = 16777454
  Key_Suspend = 16777484
  Key_SysReq = 16777226
  Key_T = 84
  Key_THORN = 222
  Key_Tab = 16777217
  Key_TaskPane = 16777455
  Key_Terminal = 16777456
  Key_Time = 16777479
  Key_ToDoList = 16777420
  Key_ToggleCallHangup = 17825799
  Key_Tools = 16777457
  Key_TopMenu = 16777482
  Key_Touroku = 16781611
  Key_Travel = 16777458
  Key_TrebleDown = 16777335
  Key_TrebleUp = 16777334
  Key_U = 85
  Key_UWB = 16777473
  Key_Uacute = 218
  Key_Ucircumflex = 219
  Key_Udiaeresis = 220
  Key_Ugrave = 217
  Key_Underscore = 95
  Key_Up = 16777235
  Key_V = 86
  Key_Video = 16777459
  Key_View = 16777481
  Key_VoiceDial = 17825800
  Key_VolumeDown = 16777328
  Key_VolumeMute = 16777329
  Key_VolumeUp = 16777330
  Key_W = 87
  Key_WLAN = 16777472
  Key_WWW = 16777403
  Key_WakeUp = 16777400
  Key_WebCam = 16777466
  Key_Word = 16777460
  Key_X = 88
  Key_Xfer = 16777461
  Key_Y = 89
  Key_Yacute = 221
  Key_Yes = 16842753
  Key_Z = 90
  Key_Zenkaku = 16781608
  Key_Zenkaku_Hankaku = 16781610
  Key_Zoom = 16908294
  Key_ZoomIn = 16777462
  Key_ZoomOut = 16777463
  Key_acute = 180
  Key_brokenbar = 166
  Key_cedilla = 184
  Key_cent = 162
  Key_copyright = 169
  Key_currency = 164
  Key_degree = 176
  Key_diaeresis = 168
  Key_division = 247
  Key_exclamdown = 161
  Key_guillemotleft = 171
  Key_guillemotright = 187
  Key_hyphen = 173
  Key_iTouch = 16777432
  Key_macron = 175
  Key_masculine = 186
  Key_mu = 181
  Key_multiply = 215
  Key_nobreakspace = 160
  Key_notsign = 172
  Key_onehalf = 189
  Key_onequarter = 188
  Key_onesuperior = 185
  Key_ordfeminine = 170
  Key_paragraph = 182
  Key_periodcentered = 183
  Key_plusminus = 177
  Key_questiondown = 191
  Key_registered = 174
  Key_section = 167
  Key_ssharp = 223
  Key_sterling = 163
  Key_threequarters = 190
  Key_threesuperior = 179
  Key_twosuperior = 178
  Key_unknown = 33554431
  Key_ydiaeresis = 255
  Key_yen = 165
  KeyboardModifierMask = -33554432
  KeypadModifier = 536870912
  LastCursor = 21
  LayoutDirectionAuto = 2
  LeftArrow = 3
  LeftButton = 1
  LeftDockWidgetArea = 1
  LeftSection = 1
  LeftToRight = 0
  LeftToolBarArea = 1
  LinearGradientPattern = 15
  LinkAction = 4
  LinksAccessibleByKeyboard = 8
  LinksAccessibleByMouse = 4
  LocalDate = 2
  LocalTime = 0
  LocaleDate = 3
  LogText = 3
  LogicalCoordinates = 1
  LogicalMoveStyle = 0
  LowEventPriority = -1
  META = 268435456
  MODIFIER_MASK = -33554432
  MPenCapStyle = 48
  MPenJoinStyle = 448
  MPenStyle = 15
  MSWindowsFixedSizeDialogHint = 256
  MSWindowsOwnDC = 512
  MacWindowToolBarButtonHint = 268435456
  MaskInColor = 0
  MaskOutColor = 1
  MatchCaseSensitive = 16
  MatchContains = 1
  MatchEndsWith = 3
  MatchExactly = 0
  MatchFixedString = 8
  MatchRecursive = 64
  MatchRegExp = 4
  MatchStartsWith = 2
  MatchWildcard = 5
  MatchWrap = 32
  MaximumSize = 2
  MenuBarFocusReason = 6
  MetaModifier = 268435456
  MidButton = 4
  MiddleButton = 4
  MinimumDescent = 3
  MinimumSize = 0
  MiterJoin = 0
  Monday = 1
  MonoOnly = 2
  MouseFocusReason = 0
  MoveAction = 2
  NavigationModeCursorAuto = 3
  NavigationModeCursorForceVisible = 4
  NavigationModeKeypadDirectional = 2
  NavigationModeKeypadTabOrder = 1
  NavigationModeNone = 0
  NoArrow = 0
  NoBrush = 0
  NoButton = 0
  NoClip = 0
  NoContextMenu = 0
  NoDockWidgetArea = 0
  NoFocus = 0
  NoFocusReason = 8
  NoItemFlags = 0
  NoModifier = 0
  NoPen = 0
  NoSection = 0
  NoTextInteraction = 0
  NoToolBarArea = 0
  NonModal = 0
  NormalEventPriority = 0
  OddEvenFill = 0
  OffsetFromUTC = 2
  OpaqueMode = 1
  OpenHandCursor = 17
  OrderedAlphaDither = 4
  OrderedDither = 16
  OtherFocusReason = 7
  PanGesture = 3
  PartiallyChecked = 1
  PinchGesture = 4
  PlainText = 0
  PointingHandCursor = 13
  Popup = 9
  PopupFocusReason = 4
  PreferDither = 64
  PreferredSize = 1
  PreventContextMenu = 4
  QueuedConnection = 2
  RadialGradientPattern = 16
  ReceivePartialGestures = 2
  RelativeSize = 1
  RepeatTile = 1
  ReplaceClip = 1
  RichText = 1
  RightArrow = 4
  RightButton = 2
  RightDockWidgetArea = 2
  RightSection = 5
  RightToLeft = 1
  RightToolBarArea = 2
  RoundCap = 32
  RoundJoin = 128
  RoundTile = 2
  SHIFT = 33554432
  Saturday = 6
  ScrollBarAlwaysOff = 1
  ScrollBarAlwaysOn = 2
  ScrollBarAsNeeded = 0
  Sheet = 5
  ShiftModifier = 33554432
  ShortcutFocusReason = 5
  SizeAllCursor = 9
  SizeBDiagCursor = 7
  SizeFDiagCursor = 8
  SizeHintRole = 13
  SizeHorCursor = 6
  SizeVerCursor = 5
  SmoothTransformation = 1
  SolidLine = 1
  SolidPattern = 1
  SplashScreen = 15
  SplitHCursor = 12
  SplitVCursor = 11
  SquareCap = 16
  StatusTipRole = 4
  StretchTile = 0
  StrongFocus = 11
  SubWindow = 18
  Sunday = 7
  SvgMiterJoin = 256
  SwipeGesture = 5
  SystemLocaleDate = 2
  SystemLocaleLongDate = 5
  SystemLocaleShortDate = 4
  TabFocus = 1
  TabFocusReason = 1
  TapAndHoldGesture = 2
  TapGesture = 1
  TargetMoveAction = 32770
  TextAlignmentRole = 7
  TextBrowserInteraction = 13
  TextColorRole = 9
  TextDate = 0
  TextDontClip = 512
  TextDontPrint = 16384
  TextEditable = 16
  TextEditorInteraction = 19
  TextExpandTabs = 1024
  TextHideMnemonic = 32768
  TextIncludeTrailingSpaces = 134217728
  TextJustificationForced = 65536
  TextSelectableByKeyboard = 2
  TextSelectableByMouse = 1
  TextShowMnemonic = 2048
  TextSingleLine = 256
  TextWordWrap = 4096
  TextWrapAnywhere = 8192
  TexturePattern = 24
  ThresholdAlphaDither = 0
  ThresholdDither = 32
  Thursday = 4
  TitleBarArea = 9
  Tool = 11
  ToolBarArea_Mask = 15
  ToolButtonFollowStyle = 4
  ToolButtonIconOnly = 0
  ToolButtonTextBesideIcon = 2
  ToolButtonTextOnly = 1
  ToolButtonTextUnderIcon = 3
  ToolTip = 13
  ToolTipRole = 3
  TopDockWidgetArea = 4
  TopLeftCorner = 0
  TopLeftSection = 2
  TopRightCorner = 1
  TopRightSection = 4
  TopSection = 3
  TopToolBarArea = 4
  TouchPointMoved = 2
  TouchPointPressed = 1
  TouchPointReleased = 8
  TouchPointStationary = 4
  TransparentMode = 0
  Tuesday = 2
  UI_AnimateCombo = 3
  UI_AnimateMenu = 1
  UI_AnimateToolBox = 6
  UI_AnimateTooltip = 4
  UI_FadeMenu = 2
  UI_FadeTooltip = 5
  UI_General = 0
  UNICODE_ACCEL = 0
  UTC = 1
  Unchecked = 0
  UniqueConnection = 128
  UniteClip = 3
  UpArrow = 1
  UpArrowCursor = 1
  UserRole = 32
  VerPattern = 10
  Vertical = 2
  VisualMoveStyle = 1
  WA_AcceptDrops = 78
  WA_AcceptTouchEvents = 121
  WA_AlwaysShowToolTips = 84
  WA_AttributeCount = 135
  WA_AutoOrientation = 130
  WA_CustomWhatsThis = 47
  WA_DeleteOnClose = 55
  WA_Disabled = 0
  WA_DontCreateNativeAncestors = 101
  WA_ForceDisabled = 32
  WA_ForceUpdatesDisabled = 59
  WA_GrabbedShortcut = 50
  WA_GroupLeader = 72
  WA_Hover = 74
  WA_InputMethodEnabled = 14
  WA_InputMethodTransparent = 75
  WA_InvalidSize = 45
  WA_KeyCompression = 33
  WA_KeyboardFocusChange = 77
  WA_LaidOut = 7
  WA_LayoutOnEntireRect = 48
  WA_LayoutUsesWidgetRect = 92
  WA_LockLandscapeOrientation = 129
  WA_LockPortraitOrientation = 128
  WA_MSWindowsUseDirect3D = 94
  WA_MacAlwaysShowToolWindow = 96
  WA_MacBrushedMetal = 46
  WA_MacFrameworkScaled = 117
  WA_MacMetalStyle = 46
  WA_MacMiniSize = 91
  WA_MacNoClickThrough = 12
  WA_MacNoShadow = 134
  WA_MacNormalSize = 89
  WA_MacOpaqueSizeGrip = 85
  WA_MacShowFocusRect = 88
  WA_MacSmallSize = 90
  WA_MacVariableSize = 102
  WA_Mapped = 11
  WA_MergeSoftkeys = 124
  WA_MergeSoftkeysRecursively = 125
  WA_MouseNoMask = 71
  WA_MouseTracking = 2
  WA_Moved = 43
  WA_NativeWindow = 100
  WA_NoChildEventsForParent = 58
  WA_NoChildEventsFromChildren = 39
  WA_NoMousePropagation = 73
  WA_NoMouseReplay = 54
  WA_NoSystemBackground = 9
  WA_NoX11EventCompression = 81
  WA_OpaquePaintEvent = 4
  WA_OutsideWSRange = 49
  WA_PaintOnScreen = 8
  WA_PaintOutsidePaintEvent = 13
  WA_PaintUnclipped = 52
  WA_PendingMoveEvent = 34
  WA_PendingResizeEvent = 35
  WA_PendingUpdate = 44
  WA_QuitOnClose = 76
  WA_Resized = 42
  WA_RightToLeft = 56
  WA_SetCursor = 38
  WA_SetFont = 37
  WA_SetLayoutDirection = 57
  WA_SetLocale = 87
  WA_SetPalette = 36
  WA_SetStyle = 86
  WA_SetWindowIcon = 53
  WA_ShowWithoutActivating = 98
  WA_StaticContents = 5
  WA_StyleSheet = 97
  WA_StyledBackground = 93
  WA_TintedBackground = 82
  WA_TouchPadAcceptSingleTouchEvents = 123
  WA_TranslucentBackground = 120
  WA_TransparentForMouseEvents = 51
  WA_UnderMouse = 1
  WA_UpdatesDisabled = 10
  WA_WState_CompressKeys = 61
  WA_WState_ConfigPending = 64
  WA_WState_Created = 60
  WA_WState_ExplicitShowHide = 69
  WA_WState_Hidden = 16
  WA_WState_InPaintEvent = 62
  WA_WState_OwnSizePolicy = 68
  WA_WState_Polished = 66
  WA_WState_Reparented = 63
  WA_WState_Visible = 15
  WA_WindowModified = 41
  WA_WindowPropagation = 80
  WA_X11DoNotAcceptFocus = 132
  WA_X11NetWmWindowTypeCombo = 115
  WA_X11NetWmWindowTypeDND = 116
  WA_X11NetWmWindowTypeDesktop = 104
  WA_X11NetWmWindowTypeDialog = 110
  WA_X11NetWmWindowTypeDock = 105
  WA_X11NetWmWindowTypeDropDownMenu = 111
  WA_X11NetWmWindowTypeMenu = 107
  WA_X11NetWmWindowTypeNotification = 114
  WA_X11NetWmWindowTypePopupMenu = 112
  WA_X11NetWmWindowTypeSplash = 109
  WA_X11NetWmWindowTypeToolBar = 106
  WA_X11NetWmWindowTypeToolTip = 113
  WA_X11NetWmWindowTypeUtility = 108
  WA_X11OpenGLOverlay = 83
  WDestructiveClose = 'TO BE DONE'
  WaitCursor = 3
  Wednesday = 3
  WhatsThisCursor = 15
  WhatsThisRole = 5
  WheelFocus = 15
  WhiteSpaceModeUndefined = -1
  WhiteSpaceNoWrap = 2
  WhiteSpaceNormal = 0
  WhiteSpacePre = 1
  Widget = 0
  WidgetShortcut = 0
  WidgetWithChildrenShortcut = 3
  WindingFill = 1
  Window = 1
  WindowActive = 8
  WindowCancelButtonHint = 1048576
  WindowCloseButtonHint = 134217728
  WindowContextHelpButtonHint = 65536
  WindowFullScreen = 4
  WindowMaximizeButtonHint = 32768
  WindowMaximized = 2
  WindowMinMaxButtonsHint = 49152
  WindowMinimizeButtonHint = 16384
  WindowMinimized = 1
  WindowModal = 1
  WindowNoState = 0
  WindowOkButtonHint = 524288
  WindowShadeButtonHint = 131072
  WindowShortcut = 1
  WindowSoftkeysRespondHint = -2147483648
  WindowSoftkeysVisibleHint = 1073741824
  WindowStaysOnBottomHint = 67108864
  WindowStaysOnTopHint = 262144
  WindowSystemMenuHint = 8192
  WindowTitleHint = 4096
  WindowType_Mask = 255
  X11BypassWindowManagerHint = 1024
  XAxis = 0
  XButton1 = 8
  XButton2 = 16
  YAxis = 1
  ZAxis = 2
  black = 2
  blue = 9
  color0 = 0
  color1 = 1
  cyan = 10
  darkBlue = 15
  darkCyan = 16
  darkGray = 4
  darkGreen = 14
  darkMagenta = 17
  darkRed = 13
  darkYellow = 18
  gray = 5
  green = 8
  lightGray = 6
  magenta = 11
  red = 7
  transparent = 19
  white = 3
  yellow = 12

class QtMsgType(_Mock):
  pass


class Signal(_Mock):
  pass


class pyqtBoundSignal(_Mock):
  pass


class pyqtProperty(_Mock):
  pass


class pyqtSignal(_Mock):
  pass


class pyqtWrapperType(_Mock):
  pass


